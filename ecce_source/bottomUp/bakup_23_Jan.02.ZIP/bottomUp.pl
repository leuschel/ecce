% ######################################################################
% Rough Regular Type Approximation Bottom Up Specialisation for one Atom
% ######################################################################

:- module(bottomUp, [bottomUp/1, bottomUp/2, bottomUp/3]).
:- use_module(johnsTool, 'johnsTool.pl', [td/3]).

% ######################################################################
% Writes the analysis result out into a per-default or user-defined file 
% ######################################################################


bottomUp(Atom) :- /* Default I/O-Paths */
	!,
	bottomUp(Atom,
		 '~/CVS/ecce/ecce_source/bottomUp/inp.pl',
		 '~/CVS/ecce/ecce_source/bottomUp/tmp.pl').

bottomUp(Atom, InputPath) :- /* Default O-Path */
	!,
	bottomUp(Atom,
		 InputPath,
		 '~/CVS/ecce/ecce_source/bottomUp/tmp.pl').

bottomUp(Atom, InputPath, OutputPath) :-
	!,
	check(Atom),
	
	td(Atom, InputPath, OutputPath).

check(Atom) :-

	Atom =.. [P|A],
	functor(P,P,0),
	P \== ',',
	!.

check(Error) :-

	nl,
	print('# BottomUp INPUT ERROR:'),
	nl,
	print('# '),
	print(Error),
	print(' is no proper atom!'),
	nl,
	!,
	fail.

% ################################# END ################################
