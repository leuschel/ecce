% ######################################################################
% Rough Regular Type Approximation Bottom Up Specialisation for one Atom
% ######################################################################

%:- module(scanBUfile, [scanBUprog/2, scanBUprog/3, quickSort/2]).

:- use_module(library(lists)).
:- use_module(library(terms)).

% #####################################################################
% Reads the Bottom-Up-Result from a file and produces an according RCD.
% As the Program produced by John's Bottom-Up-Analysis is rather chaos
% than order a lot of tedious syntactic post-processing has to be done
% by this module. Nevertheless ATTENTION: The produced RCD could still
% contain some dead code (un-used clauses) and should therefore be com-
% pressed with the appropriate methods (provided by the RUL package of
% the ECCE system) for the sake of efficient data! QuickSort is public
% because of its general usefulness. ATTENTION2: WW ASSUME that in the
% to-be-scanned file all clause head variables appear in the same order
% as the according clause tail variables, e.g. p(X,Y,Z):-r(X),s(Y),t(Z)
% but not p(X,Y,Z):-s(Y),t(Z),r(X). ###################################


%-------- PUBLIC -------
scanBUprog(QueryPredAtom,
	   InputFileName,
	   RULconstraint) :-
	
	seeing(Dummy),
	see(InputFileName),
	clauseList(BUprog),
	seen,
	see(Dummy),
	!,
	construct(QueryPredAtom,
		  BUprog,
		  RULconstraint),
	nl,
	print('>> A raw Rul Constraint Declaration has been constructed.'),
	nl,
	print('>> Please rul:compress/2 the result for best performance.'),
	nl.

%-------- PUBLIC -------
scanBUprog(QueryPredAtom,
	   RULconstraint) :-
	
	scanBUprog(QueryPredAtom,
		   '~/CVS/ecce/ecce_source/bottomUp/tmp.pl', /* Default */
		   RULconstraint).

%=======================================================================

clauseList([Clause|List]) :-

	read(Clause),
	Clause \== end_of_file,
	clauseList(List).

clauseList([]).

%=======================================================================

construct(QueryPredAtom, BUprog, RCD) :-

	discardLeftRight(BUprog, State1),
	
	discardNotAsked(QueryPredAtom,   
			State1, State2),
	
	remove_duplicates(State2, State3),
	
	quickSort(State3, State4),       
	
	buildRCD(QueryPredAtom, State4, RCD).

%=======================================================================

buildRCD(ReferencePred, ClauseList,
	 rul__constraint__declaration(Constraints,
				      RULprogram)) :-

	cutReference(ReferencePred,
		     ClauseList,
		     ReferenceClause,
		     RestList),
	
	makeConstraints(ReferenceClause,
			PreConstraints),

	adoptVariables(ReferencePred, /* We assume ordered Variables! */
		       PreConstraints,
		       Constraints),
	
	makeProgram(RestList, RULprogram).

%=======================================================================

adoptVariables(Atom, OldConstr, NewConstr) :-

	Atom =.. [_|Variables],
	!,
	replaceVariables(Variables,
			 OldConstr,
			 NewConstr).

%-----------------------------------------------------------------------

replaceVariables([],[],[]).

replaceVariables([V|Vars], [OldC|OldConstr], [NewC|NewConstr]) :-

	/* We assume ordered Variables, */
	/* otherwise results are wrong! */

	OldC =.. [Name,_],
	NewC =.. [Name,V],
	!,
	replaceVariables(Vars, OldConstr, NewConstr).

%=======================================================================

makeProgram(Clauses, RULprogram) :-

	identifyDefinitions(Clauses, Definitions),
	
	addConcreteSyntax(Definitions, RULprogram).

%=======================================================================

identifyDefinitions([],[]).

identifyDefinitions([OnlyOne], [[OnlyOne]]).

identifyDefinitions(Clauses, Definitions) :-

	insertSeparators(Clauses, Result),
	
	buildGroups(Result, Definitions).
	
%=======================================================================
	
buildGroups(SeparatedClauses, [Def|Definitions]) :-

	stopScan(SeparatedClauses, Def, RestList),

	buildGroups(RestList, Definitions).

buildGroups([],[]).

%-----------------------------------------------------------------------

stopScan(InputList, Definition, Postfix) :-

	append(Prefix, Postfix, InputList),

	append(Definition, [stop], Prefix),

	non_member(stop, Definition).

%=======================================================================

insertSeparators([(P1:-G1),(P2:-G2)|Clauses],
		 [(P1:-G1),stop,(P2:-G2)|SepClauses]) :-

        P1 =.. [ThisName,_],
	P2 =.. [ThatName,_],
	
	ThisName \== ThatName, /* Begin of New Def */
	!,
	insertSeparators([(P2:-G2)|Clauses],
			 [(P2:-G2)|SepClauses]).

insertSeparators([C1,C2|Clauses],
		 [C1,C2|SepClauses]) :-

	insertSeparators([C2|Clauses],
			 [C2|SepClauses]).

insertSeparators([C],[C,stop]).

%=======================================================================

addConcreteSyntax([[(Pred:-Tail)|PClauses]|Definitions],
		  [proc(P/1, [(Pred:-Tail)|PClauses])|RULprog]) :-

        Pred =.. [P,_], /* Unary RUL Heads */
	
	addConcreteSyntax(Definitions, RULprog).

addConcreteSyntax([],[]).

%=======================================================================

makeConstraints((_:-Tail), Constraints) :-

        commaToList(Tail, Constraints).

%-----------------------------------------------------------------------

commaToList((P,Goals), [P|Preds]) :-

	commaToList(Goals, Preds).

commaToList(Predicate, [Predicate]) :-

	Predicate \= (_,_).

%=======================================================================

cutReference(Atom, ClauseList, RefClause, RestList) :-

	Atom =.. [Name|_],
	
	name(Name, NameCode),
	
	name('_ans',AnsCode),
	
	append(NameCode, AnsCode, SearchCode),
	
	name(Pattern, SearchCode),
	
	searchPattern(Pattern, ClauseList, RefClause),

	RefClause \== notFound,
	!,
	delete(ClauseList, RefClause, RestList).

%-----------------------------------------------------------------------

searchPattern(Name, [(Atom:-Tail)|_], (Atom:-Tail)) :-

        Atom =.. [Name|_],
	!.

searchPattern(Name, [_|Clauses], Result) :-

	searchPattern(Name, Clauses, Result),
	!.

searchPattern(_, [], notFound). /* This case should not occur! */

%=======================================================================

discardNotAsked(_,[],[]) :- !.

discardNotAsked(AskedAtom, [(Discard:-_)|Input], Output) :-

        /* Case: Wrong Name_ans */

        AskedAtom =.. [AskedName|_],
	
	Discard =.. [WrongName|_],
	
	name(WrongName, Code),
	
	name('_ans', Suffix),
	
	append(Prefix, Suffix, Code),
	
	name(NotAsked, Prefix),
	
	NotAsked \== AskedName,
	!,
	discardNotAsked(AskedAtom, Input, Output).

discardNotAsked(AskedAtom, [(Discard:-_)|Input], Output) :-

        /* Case: Proper Name_ans, but Wrong Arity */

        AskedAtom =.. [Name|AskedArguments],
	
	Discard =.. [DiName|WrongArguments],
	
	name(DiName, Code),
	
	name('_ans', Suffix),
	
	append(Prefix, Suffix, Code),
	
	name(Name, Prefix),
	
	AskedArguments \= WrongArguments, /* No Match */
	!,
	discardNotAsked(AskedAtom, Input, Output).

discardNotAsked(AskedAtom, [OK|Input], [OK|Output]) :-

	discardNotAsked(AskedAtom, Input, Output).

%=======================================================================

discardLeftRight([],[]).

discardLeftRight([(Discard:-_)|List], Output) :-

       Discard =.. [Name|_],
       
       name(Name, Code),
       
       matchLeftRight(Code),
       !,
       discardLeftRight(List, Output).

discardLeftRight([OK|Input], [OK|Output]) :-

	discardLeftRight(Input, Output).

%-----------------------------------------------------------------------

matchLeftRight(Code) :-

	name('_left_', Pattern),
	
	append(String, _, Code),
	
	append(_, Pattern, String).

matchLeftRight(Code) :-

	name('_right_', Pattern),
	
	append(String, _, Code),
	
	append(_, Pattern, String).

%=======================================================================

% --- PUBLIC ---
quickSort([],[]).

quickSort([Element|Input], Output) :-

	partition(Element, Input, Part1, Part2),

	quickSort(Part1, Result1),

	quickSort(Part2, Result2),

	append(Result1, [Element|Result2], Output).

%-----------------------------------------------------------------------

partition(_,[],[],[]).

partition(E, [A|Xs], [A|Ys], Zs) :-

	E @< A, /* lecical order */
	!,
	partition(E, Xs, Ys, Zs).

partition(E, [A|Xs], Ys, [A|Zs]) :-

	partition(E, Xs, Ys, Zs).

%=======================================================================
%################################## END ################################
%=======================================================================
