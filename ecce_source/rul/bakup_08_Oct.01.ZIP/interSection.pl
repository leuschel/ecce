%###############################################################
%################## MODULE: TYPE INTERSECTION ##################
%###############################################################
%###### Derived and modified from John Gallagher's Tool ########
%###############################################################

:- module(interSection, [interSection/7]).

:- use_module(library(lists)).

:- use_module(prePostCon,
	      '~/CVS/ecce/ecce_source/rul/prePostCon.pl',
	      [isType/1, isRULprog/1, isDefinition/1, isOrdered/1]).

%:- use_module(prePostCon, 'prePostCon.pl',
%	      [isType/1, isRULprog/1, isDefinition/1, isOrdered/1]).

:- use_module(subType,
	      '~/CVS/ecce/ecce_source/rul/subType.pl', [subType/3]).

%:- use_module(subType, 'subType.pl', [subType/3]).

:- use_module(auxil,
	      '~/CVS/ecce/ecce_source/rul/auxil.pl',
              [wellDefined/3, newName/2, removeClause/4,
               prepareTriple/10, orderSubGoals/2]).

%:- use_module(auxil, 'auxil.pl',
%              [wellDefined/3, newName/2, removeClause/4,
%	        prepareTriple/10, orderSubGoals/2]).
%##################################################################


% (PUBLIC) INTERSECTION: ==========================================
% Given two input type names and an according RUL program (which is
% defining the input types), we check if there exists a non-trivial
% intersection type. If the two input types are in subtype relation,
% the subtype is also the intersection type. Otherwise, we have to
% compute the new intersection type - which will be empty in case
% that the two input types have no common ground instance. A (num-
% ber) input index is necessary for the generation of the new name
% of the intersection type. Another numerical output index (which
% we don't really need) indicates how many subdefinitions have been
% generated in order to define the new intersection type. I/O-Usage
% is thus (+,+,-,-,+,+,-). Please note the similarity between this
% procedure and the upperBound procedure in the upperBound module!
% =================================================================

interSection(ThisType, any, ThisType, [], _, _, _) :- !.

interSection(any, ThisType, ThisType, [], _, _, _) :- !.

interSection(ThisType, SuperType, ThisType, [], RULprog, _,_) :-

	/* PRECONDITIONS */
	isType(ThisType),
	isType(SuperType),
	isRULprog(RULprog),

	subType(ThisType, SuperType, RULprog),
	 !.

interSection(SuperType, ThisType, ThisType, [], RULprog, _,_) :-

	/* PRECONDITIONS */
	isType(ThisType),
	isType(SuperType),
	isRULprog(RULprog),

	subType(ThisType, SuperType, RULprog),
	!.	

interSection(TypeName1, TypeName2, InterSectionName,
	     [proc(InterSectionName/1, InterSectionDef)|SubDefs],
	     InputProgram, InputIndex, OutputIndex) :-

	/* PRECONDITIONS */
	isType(TypeName1),
	isType(TypeName2),
	isRULprog(InputProgram),

	orderSubGoals(InputProgram, RULprogram),

	wellDefined(TypeName1, TypeDef1, RULprogram),
        wellDefined(TypeName2, TypeDef2, RULprogram),
      
        newName(InputIndex, NewName),

	name(NewName, NameCode),

	name(is_, FlagCode), /* Flag indicating interSection */

	append(FlagCode, NameCode, IdentCode),
	
        name(InterSectionName, IdentCode),
	
        NextIndex is InputIndex + 1,
      
        lowerType(TypeDef1, TypeDef2, InterSectionDef,
		  InterSectionName, TypeName1, TypeName2,
		  InterSectionName, WorkTriples, ReferenceTriples,
		  NextIndex, NewIndex, RULprogram),

        InterSectionDef = [(_:-_)|_], /* Non-Empty Definition! */

        make_IS_def(ReferenceTriples, TypeName1, TypeName2,
		    InterSectionName, WorkTriples, SubDefs,
		    NewIndex, OutputIndex, RULprogram),

	isDefinition(SubDefs),
	!.

interSection(Name1, Name2, _,_,_,_,_) :-
	nl,
	nl,
	print('* INTERSECTION ERROR: '),
	nl,
	print('* Types '),
	print(Name1),
	print(' and '),
	print(Name2),
	nl,
	print('* have no common instance!'),
	nl,
	nl,
	!,
	fail.
	
%-----------------------------------------------------------------

lowerType([], _, [], _,_,_,_,_,_, FinalIndex, FinalIndex, _) :- !.

lowerType(_, [], [], _,_,_,_,_,_, FinalIndex, FinalIndex, _) :- !.

lowerType([(Head1:-Goals1)|Clauses1], TypeDef2,
	  [(IHead:-IGoals)|IClauses], NameIS,
	  TName1, TName2, NameLT, WorkTriples,
	  ReferenceTriples, OldIndex, NewIndex,
	  RULprog) :-

	/* PRECONDITION */
	isOrdered((Head1:-Goals1)),
	allOrdered(TypeDef2),

      removeClause(Head1, RmvGoals2,
		   TypeDef2, ResClauses2),
      !,

      Head1=..[_,      SameFunctor],
      IHead=..[NameIS, SameFunctor],

      interSectBody(Goals1, RmvGoals2, IGoals, TName1, TName2,
		    NameLT, WorkTriples, ReferenceTriples,
		    OldIndex, NextIndex, RULprog),

      lowerType(Clauses1, ResClauses2, IClauses, NameIS, TName1,
		TName2, NameLT, WorkTriples, ReferenceTriples,
		NextIndex, NewIndex, RULprog).

lowerType([_|TDef1], TDef2, IDef, IName, Name1, Name2, LName,
	  WTriples, RTriples, OldIndex, NewIndex, RULprogram) :-
	
	lowerType(TDef1, TDef2, IDef, IName, Name1, Name2, LName,
		  WTriples, RTriples, OldIndex, NewIndex, RULprogram).

%---------------------------------------------------------------------

make_IS_def([], _,_,_,_, [], FinalIndex, FinalIndex, _) :- !.

make_IS_def(ReferenceTriples, TName1, TName2,
	    NameIS, WorkTriples, SubDefsIS,
	    InIndex, OutIndex, RULprog) :- 

      eachInterSect(ReferenceTriples, FirstDefPart, NewTriples,
		    TName1, TName2, NameIS, WorkTriples,
		    InIndex, NewIndex, RULprog),

      make_IS_def(NewTriples, TName1, TName2, NameIS,
		  WorkTriples, SecondDefPart, NewIndex,
		  OutIndex, RULprog),

      append(FirstDefPart, SecondDefPart, SubDefsIS).

%----------------------------------------------------------

interSectBody(true,true,true,_,_,_,_,_,
	      FinalIndex, FinalIndex,_ ) :- !.

interSectBody((X1,X2),(X3,X4),(X5,X6),X7,X8,X9,X10,X11,X12,X13,X14) :- 
      !,
      interSectAtom(X1,X3,X5,X7,X8,X9,X10,X11,X12,X15,X14),
      
      interSectBody(X2,X4,X6,X7,X8,X9,X10,X11,X15,X13,X14).

interSectBody(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10,X11) :-
	
      interSectAtom(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10,X11).

%------------------------------------------------------------
eachInterSect([],[],X1,X2,X3,X4,X5,X6,X6,X7) :- 
      !.
eachInterSect([(X1,X2,X3)|X4],
	      [proc(X3/1,X5)|X6],X7,X8,X9,X10,X11,X12,X13,X14) :- 
      wellDefined(X1,X15,X14),
      wellDefined(X2,X16,X14),
      X17 is X12+1,
      !,
      lowerType(X15,X16,X5,X3,X8,X9,X10,X11,X7,X17,X18,X14),
      eachInterSect(X4,X6,X7,X8,X9,X10,X11,X18,X13,X14).

%--------------------------------------------------
 
interSectAtom(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10,X11) :- 
      X1=..[X12,X13],
      X2=..[X14,X13],
      nextInterSect(X12,X14,X15,X4,X5,X6,X7,X8,X9,X10,X11),
      X3=..[X15,X13].

%-----------------------------------------------------
nextInterSect(X1,X2,X1,X3,X4,X5,X6,X7,X8,X8,X9) :- 
      subType(X1,X2,X9),
      !.
nextInterSect(X1,X2,X2,X3,X4,X5,X6,X7,X8,X8,X9) :- 
      subType(X2,X1,X9),
      !.
nextInterSect(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10,X11) :- 
      prepareTriple(X1,X2,X3,X4,X5,X6,X7,X8,X9,X10).

%-----------------------------------------------------

allOrdered([]).

allOrdered([C|Clauses]) :-

	isOrdered(C),

	allOrdered(Clauses).

%###############################################################
%############################# END #############################
%###############################################################

%------------------------- TEST ----------------------

data([proc(u/1, [(u(a):-true),
		 (u(c):-true)]),
      proc(v/1, [(v(b):-true),
		 (v(d):-true)])]).

names(x_t0, y_t6).

prog1([proc(any/1,
	   [(any(_1228):-true)]),
      proc(x_t0/1,
	   [(x_t0(s(_1214)):-x_t2(_1214))]),
      proc(x_t2/1,
	   [(x_t2(0):-true)]),
      proc(any/1,
	   [(any(_1204):-true)]),
      proc(y_t0/1,
	   [(y_t0(s(_1190)):-y_t2(_1190))]),
      proc(y_t2/1,
	   [(y_t2(0):-true)]),
      proc(y_t6/1,
	   [(y_t6(s(_1176)):-y_t8(_1176))]),
      proc(y_t8/1,
	   [(y_t8(s(_1162)):-any(_1162))])]).

prog2([proc(any/1,
	   [(any(_1228):-true)]),
      proc(x_t0/1,
	   [(x_t0(s(_1214)):-x_t2(_1214))]),
      proc(x_t2/1,
	   [(x_t2(0):-true)]),
      proc(y_t6/1,
	   [(y_t6(s(_1176)):-y_t8(_1176))]),
      proc(y_t8/1,
	   [(y_t8(s(_1162)):-any(_1162))])]).

