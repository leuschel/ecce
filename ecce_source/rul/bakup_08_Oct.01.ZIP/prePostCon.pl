%###############################################################
%############# MODULE: Pre- and Post Conditions ################
%###############################################################

:- module(prePostCon, [isRULprog/1, isTransformation/1, isName/1,
		       isType/1, isValue/1, isRCD/1, isRULhead/1,
		       isRULtail/1, isRULclause/1, isConstraint/1,
		       rulHead/2, isSimple/1, isNormal/1, isOrdered/1,
		       isRULgoal/1, isConstrDecl/1, isDefinition/1,
		       isRULified/1, isPrimitive/1, isConsistent/1]).

% ============================================================
% PURPOSE: We specify some pre- and post conditions which must
% be true at certain points of an ECCE run. The points where
% these conditions shall hold true, must be declared in the
% source code of those modules which are supported by this
% module. The ECCE system allows for switching the condition
% checks on and off, such that the user can decide on the top
% level if an ECCE run shall be fast (with condition checking
% switched off) or safe (with condition checking switched on).
% As far as style is concerned, we follow the O.O.-Convention
% for unary boolean functions (a.k.a. tests): they all begin
% with the word "is" (or "has"). Proc "rulHead/2" is exported
% for "traditional" reason (otherwise I would have to change
% too much code in other modules). ATTENTION: With the intro-
% duction of this module, the old module "rul.pl" has become
% obsolete and can/will be discarded as soon as possible. We
% store the date of some failed tests in the history database
% for the sake of debugging. To keep the database as concise
% as possible, we only store Failures of non-recursive tests.
% ===========================================================

:- use_module(auxil, '~/CVS/ecce/ecce_source/rul/auxil.pl',
              [combinePairs/2, listToGoal/2, wellDefined/3]).

%:- use_module(auxil, 'auxil.pl',
%	      [combinePairs/2, listToGoal/2, wellDefined/3]).

:- use_module(historyDB, '~/CVS/ecce/ecce_source/rul/historyDB.pl',
	       [markEvent/2, storeData/2]).

%:- use_module(historyDB, 'historyDB.pl',
%	      [markEvent/2, storeData/2]).

:- use_module(library(lists)).
:- use_module(library(terms)).

%###############################################################
%---------------------------------------------------------------

databaseSwitch(off). /* Switch history recording on or off */

%---------------------------------------------------------------

isPrimitive(Term) :- /* form: p(X1,...,Xn) */

	isValue(Term),
	
	Term =.. [Pred|Args],

	isName(Pred),
	
	term_variables(Term, Vars),

	varPermutation(Args, Vars),
	!.

isPrimitive(Fail) :-
	
	databaseSwitch(on),
	
	markEvent(not_Primitive, Ref),
	storeData(Ref, Fail),
	!,
	fail.

%---------------------------------------------------------------

isRULified([Term]) :-

	isPrimitive(Term),
	!.

isRULified([]) :- !, fail.

isRULified([T|Terms]) :-
	
	isPrimitive(T),
	
	isRULified(Terms).

%---------------------------------------------------------------

isValue(Parameter) :-

	nonvar(Parameter).

isName(Name) :-

	isValue(Name),

	functor(Name, Name, 0).

isType(Type) :- isName(Type).

%--------------------------------------------------------------

isTransformation(Transformation) :-

	isValue(Transformation),

	Transformation =.. [Name, StateS, StateT],

	isName(Name),

	isValue(StateS),
	
	isValue(StateT),

	StateS \== StateT,
	!.

isTransformation(Fail) :-

	databaseSwitch(on),

	markEvent(no_Transformation, Ref),
	storeData(Ref, Fail),
	!,
	fail.

%--------------------------------------------------------------
% Check whether an input program is RUL w.r.t. the well-known
% definition of RUL.

isRULprog([]) :- !.

isRULprog(Program) :-

	is_list(Program), /* SICSTUS built-in */

	rul(Program,
	    Program),
	!.

isRULprog(Fail) :-

	databaseSwitch(on),

	markEvent(not_RUL, Ref),
	storeData(Ref, Fail),
	!,
	fail.

%--------------------------------------------------------------

rul([proc(any/1,                  /* ignore any */
	  [(any(V):-true)])|Definitions], Program) :-
	!,
	var(V),
	
	is_list(Program),
	
	rul(Definitions, Program).

rul([proc(ProcName/1, Def)|Definitions], Program) :-

	isType(ProcName),

	is_list(Program),

	unique(ProcName, Program),

	deterministicDef(ProcName, Def),

	rul(Definitions, Program).

rul([],_).

%--------------------------------------------------------------

unique(any, _) :- !. /* ignore any */

unique(ProcName, Program) :-

	extractProcNames(Program, Names),

	findOnlyOnce(ProcName, Names).

%--------------------------------------------------------------

extractProcNames([proc(any/1,_)|Prog], ProcNames) :-

	/* ignore any */
	!,
	extractProcNames(Prog, ProcNames).

extractProcNames([proc(N/1,_)|Program], [N|ProcNames]) :-

	extractProcNames(Program, ProcNames).

extractProcNames([],[]).

%--------------------------------------------------------------

findOnlyOnce(N, [N]) :-
        !,
	isValue(N).

findOnlyOnce(N, [M|Names]) :-

	isValue(N),
	
	isValue(M),
	
	N \== M,
	!,
	findOnlyOnce(N, Names).

findOnlyOnce(N, [N|Names]) :-

	isValue(N),
	
	non_member(N, Names).

%--------------------------------------------------------------

deterministicDef(_, []) :-
	!,
	fail. /* No empty definitions! */

deterministicDef(Name, Clauses) :-

	isDefinition(Clauses),

	extractHeads(Clauses, HeadList),
	
	combinePairs(HeadList, HeadPairs),
	
	unificationTest(Name, HeadPairs).

%--------------------------------------------------------------

extractHeads([(any(_):-_)], []) :- !. /* ignore any */

extractHeads([(P:-_)], [P]) :-

        isValue(P),
	!.

extractHeads([(P:-_)|Clauses], [P|HeadList]) :-

        isValue(P),
	
        extractHeads(Clauses, HeadList).

%--------------------------------------------------------------

unificationTest(Name, [(P,Q)|HeadPairs]) :-

	isValue(Name),

	isValue(P),
	
	isValue(Q),

	P =.. [Name, ArgP],
	
	Q =.. [Name, ArgQ],

	isValue(ArgP),
	
	isValue(ArgQ),

	ArgP \= ArgQ,
	
	unificationTest(Name, HeadPairs).

unificationTest(_,[]). /* OK */

%==============================================================

isDefinition([C]) :- /* must not be empty! */

	isRULclause(C), !.

isDefinition([D|Definition]) :-

	isRULclause(D),
	!,
	isDefinition(Definition).

%==============================================================

isRULclause((any(V):-true)) :- !, var(V). /* Any-Fact */

isRULclause((Fact:-true)) :-         /* Ordinary Fact */
        !,
	isValue(Fact),

	Fact =.. [Pred,Arg1],

	isType(Pred),
	
	isName(Arg1).

isRULclause((Head:-Tail)) :-  /* Genuine Clause, Head not Fact */

        isRULhead(Head),
	
	isRULtail(Tail),

	variableCondition(Head, Tail),
	!.

isRULclause(Fail) :-

	databaseSwitch(on),

	markEvent(weird_Clause, Ref),
	storeData(Ref, Fail),
	!,
	fail.

%--------------------------------------------------------------

variableCondition(Head, Tail) :-

	term_variables(Head,
		       HeadVariables),
	
	term_variables(Tail,
		       TailVariables),

	/* isOrdered not required! */

	varPermutation(HeadVariables,
		       TailVariables).

%--------------------------------------------------------------

varPermutation([],[]).

varPermutation([X|VarsX], [Y|VarsY]) :-

	var(X),

	var(Y),

	X == Y,
	!,
	varPermutation(VarsX, VarsY).

varPermutation([X|Vars], VarsY) :-

	varMember(X, VarsY),
	!,
	append(Vars, [X], VarsX),

	varPermutation(VarsX, VarsY).

%--------------------------------------------------------------

varMember(X, [Y|_]) :-

	var(X),

	var(Y),

	X == Y,
	!.

varMember(X, [_|VarsY]) :-

	varMember(X, VarsY).

%==============================================================

isRULhead(Pred) :-

	term_variables(Pred, Variables),

	Variables \== [], /* New, BugFix [SG:5.10.2001] */

	isValue(Pred),

	Pred =.. [NameP, Functor],

	isName(NameP),

	isValue(Functor),

	Functor =.. [NameF|Arguments],

	isName(NameF),

	/* no double variables */

	varPermutation(Arguments,
		       Variables),
	!.

isRULhead(Fail) :-

	databaseSwitch(on),

	markEvent(wrong_Head, Ref),
	storeData(Ref, Fail),
	!,
	fail.

%==============================================================

isRULtail(SubGoals) :-

	isValue(SubGoals),

	listToGoal(GoalList, SubGoals),

	allGoals(GoalList),
	!.

isRULtail(Fail) :-

	databaseSwitch(on),
	
	markEvent(strange_SubGoals, Ref),
	storeData(Ref, Fail),
	!,
	fail.

%--------------------------------------------------------------

allGoals([]) :- !, fail.

allGoals(Goals) :-

	/* goals: non-empty AND simple */

	isSimple(Goals).

%==============================================================

isRULgoal(any(V)) :- var(V), !.

isRULgoal(Pred) :-

	isValue(Pred),

	Pred =.. [Name,Var],

	isType(Name),

	var(Var),
	!.

isRULgoal(Fail) :-

	databaseSwitch(on),
	
	markEvent(weird_Goal, Ref),
	storeData(Ref, Fail),
	!,
	fail.

%--------------------------------------------------------------

% (PUBLIC)
rulHead(Name, Predicate) :-

	/* obsolete but still exported */
	/* for reasons of legacy code. */
	/* Body code modified in terms */
	/* of new procedures of above. */
                                                       
	Predicate =.. [Name,_],

	isRULhead(Predicate).

%==============================================================

isSimple([]) :- !. /* difference between  */
                   /* Simple and allGoals */

isSimple([C|ComposedConstraint]) :-

	isRULgoal(C),

	isSimple(ComposedConstraint).

%==============================================================

isNormal(CompConstr) :-

	isSimple(CompConstr),
	
	/* simple AND no double variables */

	term_variables(CompConstr, Vars),

	same_length(CompConstr, Vars),
	!.

isNormal(Fail) :-

	databaseSwitch(on),

	markEvent(not_normal, Ref),
	storeData(Ref, Fail),
	!,
	fail.

%==============================================================

isConstrDecl([]).
isConstrDecl([C|Constr]) :-

	isConstraint(C),
	isConstrDecl(Constr).

% ### Some Constraint Declaration Laws: ###
% isConstrDecl(Constr) <== isSimple(Constr).
% isConstrDecl(Constr) <== allGoals(Constr).
% isConstrDecl(Constr) <== isNormal(Constr).
% isSimple(Constr)     <== isNormal(Constr).
% isSimple(Constr)     <== allGoals(Constr).
% isConstraint(C)      <==     isRULgoal(C).

%==============================================================

isOrdered((_:-true)) :- !.

isOrdered((Head:-Tail)) :-

        isRULhead(Head),

	isRULtail(Tail),
	!,
	Head =.. [_,Functor],

	Functor =.. [_|Variables],

	listToGoal(GList, Tail),
	
        /* if this test fails, then apply */
        /* auxil:orderSubGoals/2 onto the */
        /* RUL program of that clause.    */

	testOrder(Variables, GList),
	!.

isOrdered(Fail) :-

	databaseSwitch(on),

	markEvent(not_ordered, Ref),
	storeData(Ref, Fail),
	!,
	fail.

%--------------------------------------------------------------

testOrder([V|Vars], [G|List]) :-

	var(V),

	isValue(G),

	G =.. [_,X],

	var(X),

	X == V,

	testOrder(Vars, List).

testOrder([],[]).


% CONSTRAINTDATASTRUCTURE:========================================
% Here we define the data structure "rul__constraint__declaration"
% which will be used by ECCE internally. Double underscores ensure
% that no name clash with any user-defined data structures occurs,
% as ECCE does not allow the user to use the double underscore __.
% You can add this predicate into your code wherever you want to
% ensure that an input RCD is really a RUL constraint declaration.
% ================================================================

isRCD(rul__constraint__declaration([],[])) :- !.

isRCD(rul__constraint__declaration(ConstraintDeclaration,
				   ConstraintDefinition)) :-
	
	isConstrDecl(ConstraintDeclaration),

	isRULprog(ConstraintDefinition),

	allDefined(ConstraintDeclaration,
		   ConstraintDefinition),
	!.

isRCD(rul__constraint__declaration(Fail1, Fail2)) :-

	databaseSwitch(on),
	!,
	markEvent(no_RCD, Ref),
	storeData(Ref, Fail1),
	storeData(Ref, Fail2),
	fail.

isRCD(Fail) :-

	databaseSwitch(on),

	markEvent(no_RCD, Ref),
	storeData(Ref, Fail),
	!,
	fail.

%--------------------------------------------------------------

allDefined([C|Constraints], RULprogram) :-

	isConstraint(C),

	C =.. [Name,_],
	
	wellDefined(Name, CDef, RULprogram),

%%%	isDefinition(CDef), /* redundant */
	
	allDefined(Constraints, RULprogram).

allDefined([],_).

%==============================================================

% isConstraint(C) :- isRULgoal(C), !. /* redundant */

isConstraint(C) :- /* unary */

	isValue(C),

	C =.. [Name,_],

	isType(Name),
	!.

isConstraint(Fail) :-

	databaseSwitch(on),

	markEvent(weird_Constraint, Ref),
	storeData(Ref, Fail),
	!,
	fail.

%==============================================================

isConsistent(Prog) :- /* all subgoals must have definitions */

	collectGoalNames(Prog, GN),
	collectProcNames(Prog, PN),

	remove_duplicates(GN, GoalNames),
	remove_duplicates(PN, ProcNames),

	subSet(GoalNames, ProcNames),
	!.

isConsistent(Fail) :-

	databaseSwitch(on),

	markEvent(inconsistent_Prog, Ref),
	storeData(Ref, Fail),
	!,
	fail.

%--------------------------------------------------------------

collectProcNames([proc(P/1,_)|Procs], [P|Names]) :-

	collectProcNames(Procs, Names).

collectProcNames([],[]).

%--------------------------------------------------------------

collectGoalNames([proc(_/1, Def)|Procs], GoalNames) :-

	scanClauses(Def, Names),

	collectGoalNames(Procs, MoreNames),

	append(Names, MoreNames, GoalNames).

collectGoalNames([],[]).

%--------------------------------------------------------------

scanClauses([(_:-SubGoals)|Clauses], GoalNames) :-

        listToGoal(GoalList, SubGoals),

	browseSubGoals(GoalList, Names),

	scanClauses(Clauses, MoreNames),

	append(Names, MoreNames, GoalNames).

scanClauses([],[]).

%--------------------------------------------------------------

browseSubGoals([true|Goals], Names) :-
	!,
	browseSubGoals(Goals, Names).

browseSubGoals([G|Goals], [P|Names]) :-

	G =.. [P,_],

	browseSubGoals(Goals, Names).

browseSubGoals([],[]).

%##############################################################
%############################# END ############################
%##############################################################

%------------isRULprog---Test---(OK)---------------------------

/* isRUL test must succeed */
testprogram1([proc(any/1, [(any(X):-true)]),
	      proc(p/1, [(p(a):-true),
			 (p(f(X,Y)):-r(X),s(Y))]),
	      proc(q/1, [(q(b):-true),
			 (q(g(X,Y,Z)):-u(Z),v(Y),w(X))])]).

/* isRUL test must fail: non-determinism */
testprogram2([proc(any/1, [(any(X):-true)]),
	      proc(p/1, [(p(f(U,V)):-d(U),h(V)), /* here */
			 (p(f(X,Y)):-r(X),s(Y))]),
	      proc(q/1, [(q(b):-true),
			 (q(g(X,Y,Z)):-u(Z),v(Y),w(X))])]).

/* isRUL test must fail: double variables */
testprogram3([proc(any/1, [(any(X):-true)]),
	      proc(p/1, [(p(e(U,U)):-d(U),h(U)), /* here */
			 (p(f(X,Y)):-r(X),s(Y))]),
	      proc(q/1, [(q(b):-true),
			 (q(g(X,Y,Z)):-u(Z),v(Y),w(X))])]).

/* isRUL test must fail: wrong variables */
testprogram4([proc(any/1, [(any(X):-true)]),
	      proc(p/1, [(p(e(A,B)):-d(C),h(D)), /* here */
			 (p(f(c)):-true)]),
	      proc(q/1, [(q(b):-true),
			 (q(g(X,Y,Z)):-u(Z),v(Y),w(X))])]).

/* isRUL test must fail: wrong subgoals */
testprogram5([proc(any/1, [(any(X):-true)]),
	      proc(p/1, [(p(e(A,B)):-d(B),h(A)),
			 (p(f(c)):-true)]),
	      proc(q/1, [(q(b):-true),
			 (q(g(X,Y,Z)):-u(Z),v(a),w(X))])]). /* here */

/* isRUL test must fail: wrong subgoals */
testprogram6([proc(any/1, [(any(X):-true)]),
	      proc(p/1, [(p(e(A,B)):-d(B),h(A)),
			 (p(f(c)):-true)]),
	      proc(q/1, [(q(b):-true),
			 (q(g(X,Y,Z)):-u(Z),v(X,Y),w(X))])]). /* here */

/* isRUL test must fail: wrong subgoals */
testprogram7([proc(any/1, [(any(X):-true)]),
	      proc(p/1, [(p(e(A,B)):-d(B),h(A)),
			 (p(f(c)):-true)]),
	      proc(q/1, [(q(b):-true),
			 (q(g(X,Y,Z)):-u(Z),v(A),w(X))])]). /* here */

/* isRUL test must fail: wrong fact */
testprogram8([proc(any/1, [(any(X):-true)]),
	      proc(p/1, [(p(e(A,B)):-d(B),h(A)),
			 (p(F):-true)]),           /* here */
	      proc(q/1, [(q(a):-true),
			 (q(g(X,Y,Z)):-u(Z),v(Y),w(X))])]).

/* isRUL test must fail: wrong clause */
testprogram9([proc(any/1, [(any(X):-true)]),
	      proc(p/1, [(p(e(A,B)):-d(B),h(A)),
			 (p(f(X)):-true)]),           /* here */
	      proc(q/1, [(q(a):-true),
			 (q(g(X,Y,Z)):-u(Z),v(Y),w(X))])]).

/* isRUL test must fail: wrong head */
testprogram0([proc(any/1, [(any(X):-true)]),
	      proc(p/1, [(p(e(h(A,m(B)))):-d(B),h(A)), /* here */
			 (p(x):-true)]),
	      proc(q/1, [(q(a):-true),
			 (q(g(X,Y,Z)):-u(Z),v(Y),w(X))])]).

/* isRUL test must fail: name inconsistency */
testprogramA([proc(any/1, [(any(X):-true)]),
	      proc(p/1, [(p(e(A,B)):-d(B),h(A)),
			 (x(a):-true)]),           /* here */
	      proc(q/1, [(q(a):-true),
			 (q(g(X,Y,Z)):-u(Z),v(Y),w(X))])]).










