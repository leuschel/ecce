%##############################################################
%### CONSTRAINTS PROJECTION, SIMPLIFICATION, NORMALISATION ####
%##############################################################
%---(C)-Stefan-Gruner-University-of-Southampton-England-2001---

:- module(proSiNo, [simplify/2, goalRULification/4, normal/1,
		    constraintProjection/3, normalisation/2,
		    satisfiable/3, l_goalRULification/4]).

:- use_module(library(terms)).
:- use_module(library(lists)).
:- use_module(self_check).

%:-['debug.pl']. /* Local in Stefan's Environment */

:- use_module(gensym2,
	      '~/CVS/ecce/ecce_source/rul/gensym2.pl', [seed/1]).

%:- use_module(gensym2, 'gensym2.pl', [seed/1]).

:- use_module(interSection,
	      '~/CVS/ecce/ecce_source/rul/interSection.pl',
              [interSection/7]).

%:- use_module(interSection, 'interSection.pl', [interSection/7]).

:- use_module(auxil,
	      '~/CVS/ecce/ecce_source/rul/auxil.pl',
	      [newName/2, onlyVariables/1, pruneRCD/2,
	       wellDefined/3, listToGoal/2, fillUpWithANY/3]).

%:- use_module(auxil, 'auxil.pl',
%               [newName/2, onlyVariables/1, pruneRCD/2,
%	        wellDefined/3, listToGoal/2, fillUpWithANY/3]).

:- use_module(prePostCon,
	      '~/CVS/ecce/ecce_source/rul/prePostCon.pl',
	      [isRCD/1, isRULgoal/1, isName/1, isPrimitive/1,
              isSimple/1, isNormal/1, isRULgoal/1, rulHead/2]).

%:- use_module(prePostCon, 'prePostCon.pl',
%	      [isRCD/1, isRULgoal/1, isName/1, isPrimitive/1,
%	       isSimple/1, isNormal/1, isRULgoal/1, rulHead/2]).
%#################################################################


% (PUBLIC) SIMPLIFICATION: =======================================
% During the unfolding of a constraint program it may be the case
% that some variable constraint c(X) evaluates to c(t) where t is
% some term (but not a variable). In this case we have to test if
% c(t) is satisfiable w.r.t. the given RCD definition. If c(t) is
% indeed satisfiable we simplify it by concretisation (inlining)
% and rewriting. For example, if we have some clauses {c(X):-a(t),
% a(X):-b(s)} in our RCD, then c(t) is satisfiable and it will be
% replaced by b(s) and so on. We stop the satisfiability recursion
% as soon we reach a fact or another variable form, eg. d(Y). Note
% that satisfiability is a decidable property in RUL programs, and
% that the length of the constraint list may grow during the trans-
% formation as some conditions may vanish whilst others may appear.
% With the "true" entry in simplification case2 we ensure that the
% simplification result will be a proper list (and never something
% undefined). Afterwards we use "removeTrivials" to get rid of the
% unnecessary "true" terms in the constraint list. To avoid unwan-
% ted dependencies we return a fresh copy of the original program
% (which is done in the removeTrivials part of the whole procedure)
% ================================================================

simplify(OldRCD, NewRCD) :-

	/* PRECONDITION */
	isRCD(OldRCD),

	simplification(OldRCD, IntermediateRCD),
	removeTrivials(IntermediateRCD, NewRCD),

	/* POSTCONDITION */
	isRCD(NewRCD),
	!.

simplify(_,_) :-

	user:debug_nl,
	user:debug_print('* SIMPLIFICATION FAILED'),
	user:debug_nl,
	!,
	fail.

%---------------------------------------------------------------

removeTrivials(rul__constraint__declaration(OldConstr, OrigDef),
	       rul__constraint__declaration(NewConstr, CopyDef)) :-

	copy_term(OrigDef, CopyDef),

	delete(OldConstr, true, NewConstr).

%---------------------------------------------------------------

simplification(rul__constraint__declaration([C|OldConstr], D),
	       rul__constraint__declaration([C|NewConstr], D)) :-

	/* no transformation in this case: */
	
	isRULgoal(C),
	!,
	simplification(rul__constraint__declaration(OldConstr, D),
		       rul__constraint__declaration(NewConstr, D)).

simplification(rul__constraint__declaration([OldC|OldConstr], D),
	       rul__constraint__declaration([true|NewConstr], D)) :-

	copy_term(D, WorkDef),

	/* Fact found: condition vanishes */
	
	satisfiable(OldC, WorkDef, fact),
	!,
	simplification(rul__constraint__declaration(OldConstr, D),
	               rul__constraint__declaration(NewConstr, D)).

simplification(rul__constraint__declaration([OldC|OldConstr], D),
	       rul__constraint__declaration(ResultConstraint, D)) :-

	copy_term(D, WorkDef),

	satisfiable(OldC, WorkDef, SatResult),
	!,
	simplification(rul__constraint__declaration(SatResult,D),
	               rul__constraint__declaration(FixPoint, D)),
	
	         /* FixPoint replaces the first constraint OldC */
	
	append(FixPoint, NewConstr, ResultConstraint),

	simplification(rul__constraint__declaration(OldConstr, D),
		       rul__constraint__declaration(NewConstr, D)).

simplification(rul__constraint__declaration([], Definition),
	       rul__constraint__declaration([], Definition)) :- !.
                                             /* base case */

simplification(rul__constraint__declaration([BadGoal|_],_),_) :-
	
	user:debug_print('* Sub-Goal {'),
	user:debug_print(BadGoal),
	user:debug_print('} cannot be satisfied.'),
	user:debug_nl,
	!,
	fail.

%--------------------------------------------------------------

/* PUBLIC */
satisfiable(Goal, [proc(Pred/1,Clauses)|_], SatResult) :-

	Goal =.. [Pred,_],
	!,
	unify(Goal, Clauses, SatResult).

satisfiable(Goal, [_|RULprogram], SatResult) :-

	satisfiable(Goal, RULprogram, SatResult).


unify(Goal, [(Fact:-true)|_], fact) :-

        Fact = Goal,
	!.

unify(Goal, [(Head:-SubGoals)|_], SatResult) :-

        Head = Goal, /* desired side-effect on SubGoals! */
        !,
	listToGoal(SatResult, SubGoals).

unify(Goal, [_|Clauses], SatResult) :-

	unify(Goal, Clauses, SatResult).


% (PUBLIC) GOALRULIFICATION: ====================================
% "goalRULification" is an artificial word which shall have the
% following meaning. Let g(term_1, term_2, ..., term_n) be a goal
% in the body of a clause. Then we replace the goal by a new goal
% g(VAR_1, VAR_2, ..., VAR_n) such that VAR_i (i=1,...,n) are new
% variables. Further, we introduce new RUL constraints c_1, c_2,
% ..., c_n such that the logical properties of each term_i (with
% i=1,...,n) are sufficiently described (and preserved) by terms
% c_i(VAR_i). goalRULification(OldGoal, NewGoal, OldRCD, NewRCD),
% thus (+,?,+,?), is the intended I/O-Usage of this predicate.
% To avoid un-intended unifications, we destroy possible variable
% sharings between the goals and the constraint definitions by
% creating a fresh copy of the constraint definitions  ==========

% (PUBLIC) --- added by Michael --- --- --- --- --- --- ---
l_goalRULification(Goal, NewGoal, RulConstr, NewRulConstr2) :-
        
        mnf(proSiNo:normalisation(RulConstr,RulConstr2)),

	l_goalRULification2(Goal, NewGoal, RulConstr2, NewRulConstr),
	
	term_variables(NewGoal, GoalVars),
	
	constraintProjection(GoalVars, NewRulConstr, NewRulConstr2).

l_goalRULification2([], [], RCD, FinalRCD2) :-
	
        user:debug_print(call(simplify(RCD, SRCD))),
	user:debug_nl,
	
	proSiNo:simplify(RCD, SRCD),

        user:debug_print(call(normalisation(SRCD, FinalRCD))),
	user:debug_nl,
	
	mnf(proSiNo:normalisation(SRCD, FinalRCD)),

	user:debug_print(res_l_goalRULification([],[],RCD,FinalRCD)),
	user:debug_nl.

l_goalRULification2([Call|T], [NewCall|RT], RCD, NewRCD) :-
	
        user:debug_print(goalRULification(Call,NewCall,RCD,IntRCD)),
	user:debug_nl,
	
	pp_mnf(proSiNo:goalRULification(Call,NewCall,RCD,IntRCD)),
	!,
	user:debug_print('>>> Goal Rulification: transform the resulting'),
	user:debug_nl,
	user:debug_print('>>> program with compress/2 '),
	user:debug_print('to eliminate redundant defs.'), 
	user:debug_nl,
	
	l_goalRULification2(T,RT,IntRCD,NewRCD).

%-------------------------------------------------------------------------

:- assert_pre(proSiNo:goalRULification(_G1, _G2, R1, _R2),
              prePostCon:isRCD(R1)).

:- assert_post(proSiNo:goalRULification(_G1, _G2, _R1, R2),
              prePostCon:isRCD(R2)).

goalRULification(ThisGoal, ThisGoal, ThisRCD, ThisRCD) :-

	/* PRECONDITION */
	isRCD(ThisRCD),

	isName(ThisGoal),
	!.

goalRULification(ThisGoal, ThisGoal,
		 rul__constraint__declaration(OldC, OldProg),
		 rul__constraint__declaration(NewC, NewProg)) :-

	/* PRECONDITION */
	isRCD(rul__constraint__declaration(OldC, OldProg)),

	isPrimitive(ThisGoal),
	!,
	fillUpWithANY([ThisGoal], OldC, NewC),

	addAnyType(OldProg, NewProg),

	/* POSTCONDITION */
	isRCD(rul__constraint__declaration(NewC, NewProg)),
	!.


goalRULification(OldTerm, NewTerm,
		 rul__constraint__declaration(OldC, OldDef),
		 rul__constraint__declaration(OutC, OutDef)) :-

	/* PRECONDITION */
	isRCD(rul__constraint__declaration(OldC, OldDef)),

	/* PRECONDITION */
	isNormal(OldC),

	copy_term(OldDef, DefCopy),

	addAnyType(DefCopy, WorkDef),

	fillUpWithANY([OldTerm], OldC, BasisConstr),

	OldTerm =.. [Name|OldArguments],
	
	/* OldArguments may contain variables! */

	length(OldArguments, TermLength),

	makeFreshVariables(TermLength, FreshVariables),

	crossOver(OldArguments,
		  FreshVariables,
		  NewArguments,
		  NotReplacedVars),

	       /* NewArguments: all variables! */

	NewTerm =.. [Name|NewArguments],

	seed(SeedNumber),

	makeNewConstraints(SeedNumber,
			   NotReplacedVars,
			   NewArguments,
			   DummyConstraints),

	delete(DummyConstraints, none, Constraints),

	append(BasisConstr, Constraints, OutC),

	makeIntermediateFacts(DummyConstraints,
			      OldArguments,
			      IntermediateFacts,
			      BasisConstr),

	append(WorkDef,
	       IntermediateFacts,
	       IntermediateDef),

	iFactExpansion(IntermediateDef, RegularDef, BasisConstr),

	copy_term(RegularDef, OutDef),

	/* POSTCONDITION */
	isRCD(rul__constraint__declaration(OutC, OutDef)),
	!.

%---------------------------------------------------------------

makeFreshVariables(1, [_]) :- !.

makeFreshVariables(Counter, [_|Variables]) :-

	Counter > 1,

	CounterMinusOne is Counter - 1,

	makeFreshVariables(CounterMinusOne,
			   Variables).

%---------------------------------------------------------------

crossOver([], [], [], []).

% if an old Argument is already a variable, we don't need
% to replace it by a fresh variable. By not replacing the
% variable Arguments we are possibly able to preserve some 
% of the original inter-variable dependencies within the
% goals - though not all of them!

crossOver([Var|OldArgs], [_|FreshVars],
	  [Var|NewArgs], [Var|NotReplacedVars]) :-

	var(Var),
	!,
	crossOver(OldArgs, FreshVars,
		  NewArgs, NotReplacedVars).

crossOver([_|OldArgs], [FrVr|FreshVars],
	  [FrVr|NewArgs], NotReplacedVars) :-

	crossOver(OldArgs, FreshVars,
		  NewArgs, NotReplacedVars).

%---------------------------------------------------------------

makeNewConstraints(SeedNumber,
		   OldVariables,
		   [V|Variables],
		   [none|Constraints]) :-

	find(V, OldVariables),
	!,   /* OldVariables need no new Constraint! */

	makeNewConstraints(SeedNumber,
			   OldVariables,
			   Variables,
			   Constraints).

makeNewConstraints(SeedNumber,
		   OldVariables,
		   [V|Variables],
		   [C|Constraints]) :-

	newName(SeedNumber, NewName),

	name(NewName, NameCode),

	name(ge_, FlagCode), /* Flag indicating goalExpansion */

	append(FlagCode, NameCode, IdentCode),
	
        name(ExpansionName, IdentCode),

	C =.. [ExpansionName, V],

	seed(NewSeed),

	makeNewConstraints(NewSeed,
			   OldVariables,
			   Variables,
			   Constraints).

makeNewConstraints(_, _, [], []).

%---------------------------------------------------------------

find(V, [X|_]) :-

	V == X,
	!.

find(V, [_|List]) :-

	find(V, List).

%---------------------------------------------------------------

makeIntermediateFacts([], [], [], _).

/* ReferenceConstraints necessary because of long-range call-chain.*/

makeIntermediateFacts([C|Constraints], [ArgT|ArgumentTerms],
		      [iFact(TypeName/1, [(Fact:-true)])|InterFacts],
		      ReferenceConstraints) :-

        C    =.. [TypeName, _],
	Fact =.. [TypeName, ArgT],
	
	nonvar(ArgT),
        !,
	makeIntermediateFacts(Constraints,
			      ArgumentTerms,
			      InterFacts,
			      ReferenceConstraints).

/* For Existing Variables we do not need a new Constraint */
/* Definition, because they have their Constraint already */

makeIntermediateFacts([none|Constraints], [Var|ArgumentTerms],
		      InterFacts,
		      ReferenceConstraints) :-
	var(Var),
        !,
	makeIntermediateFacts(Constraints,
			      ArgumentTerms,
			      InterFacts,
			      ReferenceConstraints).

%---------------------------------------------------------------

iFactExpansion(IntermediateDef, RULprogram, ReferenceConstr) :-

	seed(StartIndex),

	goalExpansion(StartIndex, ReferenceConstr,
		      IntermediateDef, IntermediateProgram),

	addAnyType(IntermediateProgram, RULprogram).

%---------------------------------------------------------------

/* base case: expansion done */

goalExpansion(_, _, [], []) :- !.

/* trivial case: nothing to do */

goalExpansion(Seed, RefConstr,
	      [proc(N/1,Def)|OldProg],
	      [proc(N/1,Def)|NewProg]) :-
	!,	
	goalExpansion(Seed, RefConstr,
		      OldProg, NewProg).

/* case: RUL head of the form t(f(VAR,...,VAR)) */

goalExpansion(Seed, RefConstr,
	      [iFact(Name/1, [(RULtype:-true)])|OldProg],
	       [proc(Name/1, [(RULtype:-Goal)])|NewProg]) :-

        rulHead(Name, RULtype), /* RUL Syntax achieved */
	!,
	term_variables(RULtype, TermVariables),
	
        createCall(TermVariables, RefConstr, Goal),

	goalExpansion(Seed, RefConstr, OldProg, NewProg).

/* case: constant pseudo RUL head of the form t(a) */

goalExpansion(Seed, RefConstr,
	      [iFact(Name/1, [(RULconstant:-true)])|OldProg],
	       [proc(Name/1, [(RULconstant:-true)])|NewProg]) :-

        RULconstant =.. [Name, A],

	functor(A, A, 0), /* RUL Syntax achieved */
	!,
	goalExpansion(Seed, RefConstr, OldProg, NewProg).

/* case Non-RUL head without variables */

goalExpansion(Seed, RefConstr,
	      [iFact(Name/1, [(OldPred:-true)])|OldProg],
	       [proc(Name/1, [(NewPred:-Goal)])|NewProg]) :-

        term_variables(OldPred, []), /* constant */
	
        OldPred =.. [PredName, OldTerm],

	functor(OldTerm, FuncName, Arity),

	Arity > 0, /* Not yet RUL */
	!,
	makeFreshVariables(Arity, FreshVars),

	OldTerm =.. [FuncName|OldArgs],

	crossOver(OldArgs, FreshVars,
		  NewArgs, []),

	NewTerm =.. [FuncName|NewArgs],
	
	                   /* NewArgs: all variables. */

	NewPred =.. [PredName,NewTerm],

	makeNewConstraints(Seed, [],
			   NewArgs, DummyPredicates),

	delete(DummyPredicates, none, Predicates),
	
	listToGoal(Predicates, Goal),

	makeIntermediateFacts(DummyPredicates, OldArgs,
			      InterFacts, RefConstr),

	append(OldProg, InterFacts, IntermediateProg),

	seed(NewSeed), /* for further type names */

	goalExpansion(NewSeed, RefConstr,
		      IntermediateProg, NewProg).

/* case: Non-RUL head with Top-Level Variables */

goalExpansion(Seed, RefConstr,
	      [iFact(Name/1, [(OldPred:-true)])|OldProg],
	       [proc(Name/1, [(NewPred:-Goal)])|NewProg]) :-

        term_variables(OldPred, [_|_]), /* variables exist */
	
        OldPred =.. [PredName, OldTerm],

	functor(OldTerm, FuncName, Arity),

	Arity > 0, /* Not yet RUL */
	
	makeFreshVariables(Arity, FreshVars),

	OldTerm =.. [FuncName|OldArgs],

	crossOver(OldArgs, FreshVars,
		  NewArgs, NotReplacedVars),

	NotReplacedVars \== [], /* Top Level Variables exist! */
	!,
	createCall(NotReplacedVars, RefConstr, SubGoal1),

	NewTerm =.. [FuncName|NewArgs],

	NewPred =.. [PredName,NewTerm],

	makeNewConstraints(Seed, NotReplacedVars,
			   NewArgs, DummyPredicates),

	delete(DummyPredicates, none, Predicates),

	listToGoal(SubGList, SubGoal1),

	append(SubGList, Predicates, SubGoal2),
	
	listToGoal(SubGoal2, Goal),

	makeIntermediateFacts(DummyPredicates, OldArgs,
			      InterFacts, RefConstr),

	append(OldProg, InterFacts, IntermediateProg),

	seed(NewSeed),

	goalExpansion(NewSeed, RefConstr,
		      IntermediateProg, NewProg).


/* case: Non-RUL head with Non-Top-Level Variables */

goalExpansion(Seed, RefConstr,
	      [iFact(Name/1, [(OldPred:-true)])|OldProg],
	       [proc(Name/1, [(NewPred:-Goal)])|NewProg]) :-

        term_variables(OldPred, [_|_]), /* variables exist */
	
        OldPred =.. [PredName, OldTerm],

	functor(OldTerm, FuncName, Arity),

	Arity > 0, /* Not yet RUL */
	
	makeFreshVariables(Arity, FreshVars),

	OldTerm =.. [FuncName|OldArgs],

	crossOver(OldArgs, FreshVars,
		  NewArgs, []), /* Variables in Lower Levels */
	!,

	NewTerm =.. [FuncName|NewArgs],

	NewPred =.. [PredName,NewTerm],

	makeNewConstraints(Seed, [],
			   NewArgs, DummyPredicates),

	delete(DummyPredicates, none, Predicates),
	
	listToGoal(Predicates, Goal),

	makeIntermediateFacts(DummyPredicates, OldArgs,
			      InterFacts, RefConstr),

	append(OldProg, InterFacts, IntermediateProg),

	seed(NewSeed),

	goalExpansion(NewSeed, RefConstr,
		      IntermediateProg, NewProg).

%----------------------------------------------------------

createCall(Variables, ReferenceConstraints, Goals) :-

	attachTypes(ReferenceConstraints,
		    Variables, Result),

	listToGoal(Result, Goals). 

attachTypes(RefConstr, [V|Vars], [G|Output]) :-

	makeGoal(RefConstr, V, G),
	
	attachTypes(RefConstr, Vars, Output).

attachTypes(_, [], []).

makeGoal([RefC|_], Var, RefC) :-

	RefC =.. [_,V],
	Var == V,
	!.

makeGoal([_|RefConstr], Var, Output) :-

	makeGoal(RefConstr, Var, Output).

makeGoal([], Var, any(Var)).

%-------------------------------------------------------------------

addAnyType([proc(any/1, ANY)|Defs], [proc(any/1, ANY)|Defs]) :- !.

addAnyType(Program, [proc(any/1, [(any(_):-true)])|Program]). 


% (PUBLIC) CONSTRAINTPROJECTION: =========================================
% Given a list of variables and an RCD, the constraint part of the RCD is
% projected/filtered according to the input variables. The definition part
% of the RCD is not changed. For reasons of efficiency we do not check the
% syntax of the input constraint declaration here: instead we assume that
% such a check is done elsewhere and that the input constraint declaration
% is syntactically correct at this point. ATTENTION the constraint must be
% in simplified form (see simplification procedure above) before this pro-
% jection is applied (otherwise stupid results!) =========================

constraintProjection([],
		     rul__constraint__declaration(_,_),
		     rul__constraint__declaration([],[])) :- !.
	
constraintProjection(InputVarNames,
		     rul__constraint__declaration(InConstr,  InDef),
		     rul__constraint__declaration(OutConstr,OutDef)) :-

	/* PRECONDITION */
	isSimple(InConstr),

	/* PRECONDITION */
	isRCD(rul__constraint__declaration(InConstr, InDef)),

	/* PRECONDITION */
	onlyVariables(InputVarNames),
	
	filterConstraints(InputVarNames, InConstr, OutConstr),

	pruneRCD(rul__constraint__declaration(OutConstr, InDef),
		 rul__constraint__declaration(OutConstr,OutDef)).

%---------------------------------------------------------------------
		
filterConstraints([Name], InputConstr, OutputConstr) :-
	!,
	var(Name),
	
	projection(Name, InputConstr, OutputConstr).

filterConstraints([Name|VarNames], InputConstr, OutputConstr) :-

	var(Name),

	projection(Name, InputConstr, ResultConstr),
	
	filterConstraints(VarNames, InputConstr, InterConstr),
	
	append(ResultConstr, InterConstr, OutputConstr).

%-------------------------------------------------------------------

projection(VarName, [Constr|Input], [Constr|Output]) :-

	Constr =.. [_, Argument],

	Argument == VarName,
	!,
	projection(VarName, Input, Output).

projection(VarName, [_|Input], Output) :-
	!,
	projection(VarName, Input, Output).

projection(_, [], []).


% (PUBLIC) NORMALISATION: ======================================
% When a constraint contains more than one type condition on the
% same variable X, for example t1(X) AND t2(X), then we compute
% the intersection (t1 > t < t2) and replace the doubleconstraint
% t1(X) AND t2(X) by the more special constraint t(X). We repeat
% this procedure until no more situation t1(X) AND t2(X) can be
% found such that the number of different constraint names (e.g.
% t1, t2, t3) is not bigger than the number of different variable
% names (e.g. X1, X2, X3) in the end. The definition of the inter-
% section type t is added to the definition part of RCD. Note that
% normal constraints are also simple (see simplification), but not
% vice versa. To avoid unintended variable dependencies between
% the goals and the constraint definitions we create fresh copy.
% ==============================================================

normalisation(rul__constraint__declaration([],[]),C) :-
      /* MICHAEL added another base case (redundant) */
      !,
      C = rul__constraint__declaration([],[]).

normalisation(rul__constraint__declaration(ThisConstr, OrigDef),
	      rul__constraint__declaration(ThisConstr, CopyDef)) :-

	/* PRECONDITION */
	isRCD(rul__constraint__declaration(ThisConstr, OrigDef)),
	
	isNormal(ThisConstr),
	!,
	copy_term(OrigDef, CopyDef).


normalisation(rul__constraint__declaration(OldConstr,OldDef),
	      rul__constraint__declaration(NewConstr,NewDef)) :-

	/* PRECONDITION */
	isSimple(OldConstr),

	/* PRECONDITION */
	isRCD(rul__constraint__declaration(OldConstr, OldDef)),

	copy_term(OldDef, WorkDef),
	
	getDoubleCondition(OldConstr, Cond1, Cond2),

	Cond1 =.. [TypeName1, Variable], 
	Cond2 =.. [TypeName2, _],

	seed(SeedIndex),

	interSection(TypeName1, TypeName2, NameUB,
		     DefUB, WorkDef, SeedIndex, _),

	CondUB =.. [NameUB, Variable],

	normaliseConstraint(CondUB, Cond1, Cond2,
			    OldConstr, ResultConstr),

	append(WorkDef, DefUB, ResultDef),

	normalisation(rul__constraint__declaration(ResultConstr,
						   ResultDef),
		      rul__constraint__declaration(NewConstr,
						   NewDef)).

%-----------------------------------------------------------------------

varTest(X) :- var(X), !.

varTest(A) :-
	nl,
	print('* NORMALISATION ERROR: NON-VARIABLE CONSTRAINT ARGUMENT! *'),
	nl,
	print('* '),
	print(A),
	nl,
	print('* Solution: apply procedure proSiNo:simplification. *'),
	nl,
	fail.

%-----------------------------------------------------------------------

getDoubleCondition([Cond1,Cond2|_], Cond1, Cond2) :-
	
/* must succeed iff "normal" (see above) fails. */
	
	Cond1 =.. [_, Var1],
	Cond2 =.. [_, Var2],

	varTest(Var1),
	varTest(Var2),

	Var1 == Var2,
	!.

getDoubleCondition([Cond1, _|Constr], C1, C2) :-
	
/* fetch the first found double constraint */
	
	getDoubleCondition([Cond1|Constr], C1, C2),
	!.

getDoubleCondition([_, Cond2|Constr], C1, C2) :-

	getDoubleCondition([Cond2|Constr], C1, C2),
	!.

normaliseConstraint(CondUB, Cond1, Cond2,
		    OldConstr, [CondUB|WithoutC2]) :-

	deleteConstr(OldConstr, Cond1, WithoutC1),
	
	deleteConstr(WithoutC1, Cond2, WithoutC2).

deleteConstr([Constr|CList], C, Output) :-

	isRULgoal(C),

	C == Constr,
	!,
	deleteConstr(CList, C, Output).

deleteConstr([D|CList], C, [D|Output]) :-

	C \== D,
	!,
	deleteConstr(CList, C, Output).

deleteConstr([],_,[]).

%#################################################################
%############################## END ##############################
%#################################################################

grTest(unsafe(par(agent(p),agent(p))),
     _31694,
     rul__constraint__declaration([],[]),
     _31685).

