%##############################################################
%###### FOLDING ANALYSIS SUPPORTING THE GOAL-RULIFICATION #####
%##############################################################
%---(C)-Stefan-Gruner-University-of-Southampton-England-2001---

:- module(analyticFold, [goalFolding/4]).

/* MOTIVATION: In our old goalRULification procedure we had too
   many cases in which goal-internal subterm-relationsships had
   been lost in the RULification process. For example, take the
   goal g(f(X),f(X)) with constraint c(X). It has been trans-
   formed into g(Y,Z) with constraints s(Y),t(Z) which were de-
   fined as t(f(U)):-c(U) and s(f(V)):-c(V). Thus: we have only
   preserved the relation c(X), but in the RULified (or folded)
   goal g(Y,Z) itself we have lost the information that Y == Z.
   With this module, we now bring back some of the lost equiva-
   lence information! As g's old subterms f(X),f(X) have been
   the same, their generated type definitions t(f(U)):-c(U) and
   s(f(V)):-c(V) are equivalent and can therefore be compressed
   to r(f(W)):-c(W). Thus we may replace the new-generated con-
   straint s(Y) by r(Y) and t(Z) by r(Z), and this possibility
   is a safe indicator that Y and Z have been equivalent before
   the transformation. We can thus eventually transform g(Y,Z)
   with r(Y) and r(Z) into the final form g(A,A) with the con-
   straint r(A). This achieved by the procedure in this module.
   However, there is a PRINCIPLE source of un-precision in RUL-
   ification (goal folding) which we cannot overcome at all: it
   is the occurrance of identical variables in different terms.
   Example: g(X,f(X)). Because variables are the FixPoint of
   the folding procedure, we cannot replace them by variables
   as we would do it with the terms. Thus, in our example we
   will definitly produce g(X,Y) -- and without any other means
   of relational information than our RUL constraint definition
   (which is the basis of our calculus) we will certainly loose
   the old information that X is somehow within Y. The same is
   true for similar situations, for example g(f(X),h(f(X))) or
   g(f(X),h(X)). Nevertheless, better to have only one precision
   improvement than no one at all! :) From now on it is strongly
   recommended to use the goalFolding/4 procedure instead of the
   less sophisticated old goalRULification/4.
*/

:- use_module(library(terms)).
:- use_module(library(lists)).

:- use_module(self_check).

:- use_module(gensym2, 'gensym2.pl', [seed/1]).

:- use_module(prePostCon, 'prePostCon.pl', [isGoals/1, isRCD/1]).

:- use_module(proSiNo, 'proSiNo.pl', [goalRULification/4,
				      constraintProjection/3]).

:- use_module(auxil, 'auxil.pl', [replaceAllOccurrences/4,
	                          pruneRCD/2]).

%##############################################################
                                               % roughly tested

:- assert_pre(analyticFold:goalFolding(In1, In2, _,_),
	      (prePostCon:isGoals([In1]),
		  prePostCon:isRCD(In2))).

:- assert_post(analyticFold:goalFolding(_,_, Out1, Out2),
	       (prePostCon:isGoals([Out1]),
		   prePostCon:isRCD(Out2))).

goalFolding(InputGoal, InputRCD, OutputGoal, OutputRCD) :-

	/* case: precision can be improved */
	
	findMultipleArgs(InputGoal, Multiples),
	!,
	pruneRCD(InputRCD, WorkingRCD),
	!,
	goalRULification(InputGoal, /* test: error in goalRULification */ 
			 ResultGoal,
			 WorkingRCD,
			 ResultRCD),
	!,
	compressFacts(ResultRCD, NextRCD),

	identifyVariables(Multiples,
			  ResultGoal,
			  OutputGoal),

	cutConstraints(NextRCD, OutputRCD).


goalFolding(InputGoal, InputRCD, OutputGoal, OutputRCD) :-

	/* case: precision cannot be improved */

	pruneRCD(InputRCD, WorkingRCD),
	!,
	goalRULification(InputGoal,
			 OutputGoal,
			 WorkingRCD,
			 ResultRCD),
	!,
	compressFacts(ResultRCD, OutputRCD).

%------------------------------------------------------------

cutConstraints(rul__constraint__declaration(InpC, Prog),
	       rul__constraint__declaration(CutC, Prog)) :-

	remove_duplicates(InpC, CutC).

%------------------------------------------------------------

identifyVariables(Multiples, InputGoal, OutputGoal) :-

	InputGoal =.. [Pred|InputVars],

	length(InputVars, Length),

	unification(Length, Multiples,
		    InputVars, OutputVars),

	OutputGoal =.. [Pred|OutputVars].

%------------------------------------------------------------
                                             % roughly tested

unification(InputNumber, [RefList|MultiList],
	    InputVariables, OutputVariables) :-

	unify(InputNumber, RefList,
	      InputVariables, ResultVars),

	unification(InputNumber, MultiList,
		    ResultVars, OutputVariables).

unification(_, [], Vars, Vars).

%------------------------------------------------------------
                                             % roughly tested

unify(InputNumber, [Num1,Num2], InVars, OutVars) :-

	Nth is InputNumber - Num1,
	Mth is InputNumber - Num2,

	nth(Nth, InVars, U),
	nth(Mth, InVars, V),

	U = V,

	OutVars = InVars,
	!.

unify(InputNumber, [Num1,Num2|RefList], InVars, OutVars) :-

	Nth is InputNumber - Num1,
	Mth is InputNumber - Num2,

	nth(Nth, InVars, U),
	nth(Mth, InVars, V),

	U = V,
	!,
	unify(InputNumber, [Num2|RefList], InVars, OutVars).

%------------------------------------------------------------
% findMultipleArgs: Variables will not be taken into account,
% as they will not be replaced by procedure goalRULification.
%------------------------------------------------------------
                                             % roughly tested
findMultipleArgs(InputGoal,_) :-
	
	InputGoal =.. [_|Arguments],
	
	no_doubles(Arguments),
	!,
	fail.

findMultipleArgs(InputGoal, Multiples) :-
	
	InputGoal =.. [_|Arguments],

	attachPositions(Arguments, PosArg),

	discardVariables(PosArg, PosTerms),
	
	searchMultiples(PosTerms, Multiples).

%--------------------------------------------------------------

discardVariables([[V,_]|OldPosArgs], NewPosArgs) :-

	var(V),
	!,
	discardVariables(OldPosArgs, NewPosArgs).

discardVariables([[A,P]|OldPosArgs], [[A,P]|NewPosArgs]) :-

	discardVariables(OldPosArgs, NewPosArgs).

discardVariables([],[]).

%--------------------------------------------------------------

searchMultiples([[E,Pos]|Elements], MultiplePositions) :-

	sameElement(E, Elements, PositionsE),

	PositionsE \== [],
	!,
	removeTreatedPositions(PositionsE,
			       Elements,
			       RestList),

	searchMultiples(RestList, RestPositions),

	append([[Pos|PositionsE]],
	       RestPositions,
	       MultiplePositions).

searchMultiples([_|Elements], MultiPositions) :-

	searchMultiples(Elements, MultiPositions).

searchMultiples([],[]).

%--------------------------------------------------------------

removeTreatedPositions([Pos|Positions],
		       [[E,Pos]|Elements], Output) :-
	!,
	removeTreatedPositions(Positions,
			       Elements, Output).

removeTreatedPositions([], List, List) :- !.

removeTreatedPositions(Positions, [E|Elements], Output) :-

	append(Elements, [E], Permutation),

	removeTreatedPositions(Positions, Permutation, Output).

%--------------------------------------------------------------

sameElement(E, [[ELEM,P]|Elements], [P|Positions]) :-

	ELEM == E,
	!,
	sameElement(E, Elements, Positions).

sameElement(E, [_|Elements], Positions) :-

	sameElement(E, Elements, Positions).

sameElement(_,[],[]).

%--------------------------------------------------------------

attachPositions([],[]).

attachPositions([E|Elements], [[E,Pos]|PosElements]) :-

	length(Elements, Pos),

	attachPositions(Elements, PosElements).

%##########################################################
%==========================================================
% This is a primitive Compressor which Eliminates Redundant
% Single Fact Definitions (only). =========================
%##########################################################

compressFacts(rul__constraint__declaration(OldCon, OldProg),
	      rul__constraint__declaration(NewCon, NewProg)) :-

	collectFacts(OldProg, FactList, Arguments),
	!,
	remove_duplicates(Arguments, Domains),
	!,
	groupByDomain(Domains, FactList, DomGroups),
	!,
	rewriteConstr(DomGroups, OldCon, NewCon),
	!,
	rewriteProgrm(DomGroups, OldProg, NewProg).

rewriteProgrm(DomGroups, OldProg, NewProg) :-

	cutAndReplace(DomGroups, OldProg, State1),
	!,
	rewriteCalls(DomGroups, State1, NewProg).

rewriteCalls([(New,_,[Old|Names])|DomGroups], InProg, OutProg) :-

	replaceInProgram(InProg, New, Old, Result),
	!,
	rewriteCalls([(New,_,Names)|DomGroups], Result, OutProg).

rewriteCalls([(_,_,[])|DomGroups], InProg, OutProg) :-

	rewriteCalls(DomGroups, InProg, OutProg).

rewriteCalls([],FIX,FIX).

replaceInProgram([proc(N/1, OldDef)|OldProcs],
		 NewName,
		 OldName,
		 [proc(N/1, NewDef)|NewProcs]) :-

	replaceAllOccurrences(NewName,
			      OldName,
			      OldDef,
			      NewDef),
        !,
	replaceInProgram(OldProcs, NewName,
			 OldName, NewProcs).

replaceInProgram([],_,_,[]).


cutAndReplace([(Name,Dom,OldNames)|DomGroups], OldProg,
	      [proc(Name/1,[(Pred:-true)])|NewProg]) :-

        Pred =.. [Name,Dom],
	!,
	discard(Dom, OldNames, OldProg, State1),
	!,
	cutAndReplace(DomGroups, State1, NewProg).

cutAndReplace([], FIX, FIX).

discard(Dom, [Old|Names], InProg, OutProg) :-

	Pred =.. [Old,Dom],
	
	delete(InProg,
	       proc(Old/1,[(Pred:-true)]),
	       Result),
	!,
	discard(Dom, Names, Result, OutProg).

discard(_,[],FIX,FIX).

	
rewriteConstr(DomGroups, [OC|Old], [NC|New]) :-

	OC =.. [OldName, Var],
	
	detect(OldName, DomGroups, NewName),
	!,
	NC =.. [NewName, Var],
	
	rewriteConstr(DomGroups, Old, New).

rewriteConstr(Dom, [Same|Old], [Same|New]) :-

	rewriteConstr(Dom, Old, New).

rewriteConstr(_,[],[]).

detect(OldName, [(NewName,_,NameList)|_], NewName) :-

	memberchk(OldName, NameList),
	!.

detect(OldName, [_|DomainGroups], NewName) :-

	detect(OldName, DomainGroups, NewName).

detect(_,[],_) :- !, fail.

groupByDomain([D|Domains], FactList, [(F,D,Group)|DomGroups]) :-

	newFactName(F),
	!,
	oneGroup(D, FactList, Group),
	!,
	groupByDomain(Domains, FactList, DomGroups).

groupByDomain([],_,[]).

oneGroup(D, [F|Facts], [T|Types]) :-

	F =.. [T,D],
	!,
	oneGroup(D, Facts, Types).

oneGroup(D, [_|Facts], Types) :-

	oneGroup(D, Facts, Types).

oneGroup(_,[],[]).


collectFacts([],[],[]) :- !.

collectFacts([proc(F/1, [(Fact:-true)])|Procs],
	     [Fact|FactList], [Arg|ArgList]) :-

	F \= any,
	Fact =.. [F,Arg],
	ground(Arg),
	!,
	collectFacts(Procs, FactList, ArgList).

collectFacts([_|Procs], Facts, Args) :-
	!,
	collectFacts(Procs, Facts, Args).


newFactName(NewName) :-

	seed(Number),
	!,
	name(Number, NumCode),
	!,
	name(fact_, FactCode),
	!,
	append(FactCode, NumCode, NameCode),
	!,
	name(NewName, NameCode).


%############################### END ###############################
%###################################################################

test(match1([a,a,b],
	    [_73670|_73671],
	    [a,a,b],
	    [_73670|_73671]),
     rul__constraint__declaration([any(_66940),
				   any(_66941),
				   any(_73670),
				   any(_73671)],
				  [proc(ex_t13901/1,
					[(ex_t13901([_100487|_100485]):-ex_t13906(_100487),
					  ex_t13907(_100485))]),
				   proc(ex_t13902/1,
					[(ex_t13902([_100379|_100377]):-any(_100379),
					  any(_100377))]),
				   proc(ex_t13903/1,
					[(ex_t13903([_100455|_100453]):-ex_t13909(_100455),
					  ex_t13910(_100453))]),
				   proc(ex_t13904/1,
					[(ex_t13904([_100436|_100434]):-ex_t13912(_100436),
					  ex_t13913(_100434))]),
				   proc(ex_t13906/1,
					[(ex_t13906(a):-true)]),
				   proc(ex_t13907/1,
					[(ex_t13907([_100417|_100415]):-ex_t13915(_100417),
					  ex_t13916(_100415))]),
				   proc(ex_t13909/1,
					[(ex_t13909(a):-true)]),
				   proc(ex_t13910/1,
					[(ex_t13910([_100398|_100396]):-ex_t13918(_100398),
					  ex_t13919(_100396))]),
				   proc(ex_t13912/1,
					[(ex_t13912(a):-true)]),
				   proc(ex_t13913/1,
					[(ex_t13913([_100379|_100377]):-any(_100379),
					  any(_100377))]),
				   proc(ex_t13915/1,
					[(ex_t13915(b):-true)]),
				   proc(ex_t13916/1,
					[(ex_t13916([]):-true)]),
				   proc(ex_t13918/1,
					[(ex_t13918(a):-true)]),
				   proc(ex_t13919/1,
					[(ex_t13919([_100360|_100358]):-ex_t13921(_100360),
					  ex_t13922(_100358))]),
				   proc(ex_t13921/1,
					[(ex_t13921(b):-true)]),
				   proc(ex_t13922/1,
					[(ex_t13922([]):-true)]),
				   proc(any/1,
					[(any(_100345):-true)])]),
     _100653,
     _100644).


