%##############################################################
%##################### MODULE: SHORTENING #####################
%##############################################################
%---(C)-Stefan-Gruner-University-of-Southampton-England-2001---

:- module(shorten, [shortenToFixPoint/4, allDependants/2]).

:- use_module(library(lists)).

:- use_module(self_check).

%:- ['debug2.pl']. /* Local: only in Stefan's Environment */

:- use_module(prePostCon, 'prePostCon.pl', [isRULprog/1]).

:- use_module(subType, 'subType.pl', [subType/3]).

:- use_module(upperBound, 'upperBound.pl', [upperBound/7]).

:- use_module(auxil, 'auxil.pl', [combinePairs/2, progSize/3,
	     difference/3, sameSet/2, attachID/4, deleteID/2,
             replaceAllOccurrences/4, globalDepends/3]).

%#######################################################

:- assert_pre(shorten:shorten(In,_),
	      prePostCon:isRULprog(In)).

:- assert_pre(shorten:shortenToFixPoint(In,_),
	      prePostCon:isRULprog(In)).

:- assert_post(shorten:shorten(_,Out),
	       prePostCon:isRULprog(Out)).

:- assert_post(shorten:shortenToFixPoint(_,Out),
	       prePostCon:isRULprog(Out)).

% SHORTEN: ============================================
% See Definition 3.7., page 602, in J.P. Gallagher and 
% D.A.deWaal, "Fast and Precise Regular Approximations 
% of Logic Programs" Proc. 11th Internat. Conf. on Logic  
% Programming, MIT Press 1994. It takes a RUL program as  
% input and outputs a shortened version of it. A program
% is shortened by eliminating certain call-dependencies.
% This is done by replacing certain predicates. (Shorte-
% ning is related to Widening as some predicates are re-
% placed by their upper bounds, which is a kind of Wide-
% ning.) For reasons of recursion (see shortenToFixPoint
% below) we maintain a history of predicate replacements.
% Note that shortening never changes clause heads, only
% clause tails. ========================================
% [NOW OBSOLETE! SG:22.01.2002]
/*
shorten(InputProgram, OutputProgram) :-

	% PRECONDITION
	isRULprog(InputProgram),
                                                       
	allDependants(InputProgram, DPredPairs),
	!,
	short(InputProgram, DPredPairs, OutputProgram, _).

short(RULprogram, [], RULprogram, []) :- !.

short(InputProgram, [(P,Q)|Pairs], OutputProgram,
      [ReplacementInfo|ReplacementHistory]) :-   
                                  
	determineCase(P, Q, InputProgram, Case),
	!,
	%user:debug_nl,
	%user:debug_print(Case),
	%user:debug_nl,
	                                       
	treatCase(Case, P, Q, InputProgram,
		  ResultProgram, ReplacementInfo),
	!,
	short(ResultProgram, Pairs, OutputProgram,
	      ReplacementHistory).
*/


% =====================================================
% [New:22.01.2002.SG] OneStepShortening to avoid double
% recursion when called from ShortenToFixPoint! Can re-
% place the above short/4 procedure when called by proc
% shortenToFixPoint. [VERY NEW:22.01.2002] Having chan-
% ged the treatCase(case3,.,.,.,.,.) such that both the
% base types of the freshly constructed upperBound, the
% above (recursive) short/4 procedure is not applicable
% any more. ===========================================

oneStepShortening(RULprogram, [], /* 23.01.2002: */
		  RULprogram, [], /* New Arity 6 */
		  Constraints,
		  Constraints) :- !.

oneStepShortening(InputProgram, [(P,Q)|_],
		  OutputProgram,
		  [ReplacementInfo],
		  InputConstraints,
		  OutputConstraints) :-   
                                  
	determineCase(P, Q, InputProgram, Case),
	!,                         
	treatCase(Case, P, Q,
		  InputProgram,
		  OutputProgram,
		  ReplacementInfo,
		  InputConstraints,
		  OutputConstraints).    

% DOMAINDEPENDENCE: ===================================
% domainDependence: See Definition 3.6 page 602 in J.P.
% Gallagher and D.A. deWaal, "Fast and Precise Regular 
% Approximations of Logic Programs" Proc 11th Internat 
% Conf on Logic Programming, MIT Press 1994. We take 2 
% predicates check if their names can be found in call 
% chain and check if they're defined over the same set 
% of function symbols. P and Q must be syntactically   
% different, otherwise the relation would be trivially 
% true.(The relation is called D in Gallagher's paper.)
% Please note that the input program must be in RUL!
% =====================================================

domainDependence(P, Q, RULprogram) :-                  
                                                       
	P \== Q,                                       
	                                               
	globalDepends(P, Q, RULprogram), /* imported */           
	                                               
	domain(P, RULprogram, DomainP),
	
	domain(Q, RULprogram, DomainQ),                
                                                       
	sameSet(DomainP, DomainQ).


domain(P, [proc(P/1, Definition)|_], Domain) :-        
	                                               
	analyseHeads(P, Definition, [], Domain).       
                                                       
domain(P, [_|ProgrRepr], Domain) :-	               
                                                       
	domain(P, ProgrRepr, Domain).                  

/* multi case: there are RUL clauses to be examined */

analyseHeads(any, [(_:-true)], _, []) :-

        /* exceptional case: any(X) */
        !.

analyseHeads(P, [(Pred:-_)|Definitions],               
	     Accumulator, Domain) :-                   
                                                       
        /* case: p(f(X1...Xn)) where f is a function */
	
	Pred =.. [P, Functor],
	
	Functor =..[FunctSymbol|_],                    
	!,                                             
	analyseHeads(P, Definitions,                   
		     [FunctSymbol|Accumulator], Domain).

                                                       
analyseHeads(P, [(Pred:-_)|Definitions],               
	     Accumulator, Domain) :-                   
                                                       
        /* case: p(c) where c is constant */
	
	Pred =.. [P, ConstSymbol],
	
	functor(ConstSymbol, ConstSymbol, 0),          
	!,                                             
	analyseHeads(P, Definitions,                   
		     [ConstSymbol|Accumulator], Domain).

                                                       
analyseHeads(P, [(P:-_)|Definitions],                  
	     Accumulator, Domain) :-                   

        /* case: p is a nullary proposition */
	
        functor(P, P, 0),                              
	!,                                             
	analyseHeads(P, Definitions,                   
		     Accumulator, Domain).             
                                                       
% exit case: nothing to examine

analyseHeads(_, [], AccuOutput, AccuOutput).           


% SUCCESSINCLUSION: ==================================
% successInclusion: See Definition 3.2 page 601 in J.P
% Gallagher and D.A.deWaal, "Fast and Precise Regular  
% Approximations of Logic Programs" Proc 11th Internat 
% Conf on Logic Programming, MIT Press 1994. We'll use 
% the "subType" predicate of above for expressing this
% relation. Thus successInclusion is only an interface
% which we use just for terminological reasons. Inten-
% ded I/O-Usage is check-only, thus (+,+,+). =========
  
successInclusion(UnaryPred1, UnaryPred2, RULprogram) :-

	 subType(UnaryPred1, UnaryPred2, RULprogram).   

                                              
% (PUBLIC) ALLDEPENDANTS: ============================
% allDependants: Preliminary to Def.3.7 on page 602 in 
% J.P. Gallagher and D.A.deWaal, "Fast and Precise Re- 
% gular	Approximations of Logic Programs", Proc 11th   
% Internat Conf on Logic Programming, MIT Press 1994.  
% We compute a complete list of pairs (P,Q) such that  
% domainDependence(P,Q,RULprogram) holds for each pair 
% in that list. We will use that list later to compute 
% the shortened version of the RUL program, which must 
% contain at least two definitions (otherwise failure).
% =====================================================

allDependants(RULprogram, OutputPairs) :-              
                                                       
	extractCandidatePairs(RULprogram,              
			      IntermediatePairs),      
                                                       
	filterDependPairs(IntermediatePairs,           
	                  RULprogram, OutputPairs).

extractCandidatePairs(RULprogram, PairList) :-         
                                                       
	extractNames(RULprogram, NameList),
	
	combinePairs(NameList, PairList).

extractNames([proc(P/1,_)], [P]).                      
                                                       
extractNames([proc(P/1,_)|ProcDefs], [P|Names]) :-     
                                                       
	extractNames(ProcDefs, Names).                 
                                     
filterDependPairs([], _, []).                          
                                                       
filterDependPairs([(P,Q)|InputPairs], RULprogram,      
		  [(P,Q)|OutputPairs]) :-             
                                                      
	domainDependence(P, Q, RULprogram),
	!,                         
	filterDependPairs(InputPairs, RULprogram,      
			  OutputPairs).                
                                                       
filterDependPairs([_|InputPairs], RULprogram,          
		  OutputPairs) :-                      
                                                       
	filterDependPairs(InputPairs, RULprogram,      
			  OutputPairs).

% DETERMINECASE: =====================================
% determineCase checks which one of the three cases of
% Def.3.7 page 602 in Gallagher's above-mentioned 1994
% paper applies. Precondition for a proper application
% is that "domainDependence(P,Q,.)" holds true for the
% given program: otherwise case3 would be chosen with-
% out any proper justification! case X (nothing to do)
% must be checked BEFORE the application of the case 3
% procedure! Please note the logical relation between
% all these four cases. ==============================
 
determineCase(P, Q, RULprogram, case1) :-              
                                                       
	successInclusion(P, Q, RULprogram),
	successInclusion(Q, P, RULprogram),            
	!.                                             
                                                       
determineCase(P, Q, RULprogram, case2) :-              
                                               
	successInclusion(Q, P, RULprogram),
	/* order is crucial: first Q then P */ 
	!.

determineCase(_, _, _, case3).


% CASE1: ==============================================
% In the clause tails (goals) of the given program, we
% have to replace all predicate names Q by name P such
% that each Q(X) becomes P(X). The treated program must
% be in RUL. I/O-Usage (+,+,+,+,-). The term (Q,P) is
% for the recorded replacement history, see below. NEW
% [22.01.2002]: After rewriting Q by P, the definition
% of Q is obsolete and will be deleted from the program
% (Shortening!) =======================================

treatCase(case1, P, Q,                                 
	  [proc(Name/1, InputProcDef)|InputProgram],
	  [proc(Name/1, ResultProcDef)|ResultProgram],
	  (Q,P),
	  InputConstraints,       /* 23.01.2002: */
	  OutputConstraints) :-   /* New Arity 8 */

	Name \== Q, /* New:22.01.2002 */
	!,
	rewrite_Constraints(P, Q, 
			    InputConstraints,
			    OutputConstraints),
	!,
	replaceAllOccurrences(P, Q,                    
			      InputProcDef,            
			      ResultProcDef),
	treatCase(case1, P, Q,                         
		  InputProgram,
		  ResultProgram,_,_,_).


treatCase(case1, P, Q, /* New case: 22.01.2002 */
	  [proc(Q/1,_)|InputProgram],
	  ResultProgram, (Q,P),
	  InputConstraints,
	  OutputConstraints) :-
	!,
	rewrite_Constraints(P, Q,
			    InputConstraints,
			    OutputConstraints),
	!,
	treatCase(case1, P, Q,                         
		  InputProgram,
		  ResultProgram,_,_,_).
        
treatCase(case1, _, _, [], [], _, Constr, Constr).                        
      
% CASE2: ==================================================
% We have to identify certain occurrences of Q-goals, so we
% compute an intermediate program where each goal carries a
% unique identifier. Then we rename those Q-goals which are
% identified to be renamed by P. Finally, we delete all the
% identifiers as we don't need them any more. (Q,P) keeps
% information for the replacement history (see fix point).
% =========================================================
    
treatCase(case2, P, Q,
	  InputProgram,
	  ResultProgram,
	  (Q,P),
	  UnchangedConstraints,      /* 23.01.2002: */
	  UnchangedConstraints) :-   /* New Arity 8 */
                                                       
	attachID(0, InputProgram, IDprogram, _),

	/* first Q, then P, this is crucial here! */
	determinePlaces(Q, P, IDprogram, ListOfQIDs),
	                                               
	treat2(P, Q, ListOfQIDs, IDprogram, TreatedIDprogram),
	                                               
	deleteID(TreatedIDprogram, ResultProgram).       

% CASE3: ============================================
% We have to compute the upper bound of P and Q. Then
% we have to replace P by the computed upper bound in
% all clause tail occurrences (which is then the same
% situation as in case1). We feed the upperBound call
% with an input index obtained by the progSize call,
% such that we are sure that the computed upper bound
% name is unique and not in conflict with the already
% existing names in the input program. As a result of
% case 3, we also return the upper bound information.
% ===================================================
                                            
treatCase(case3, P, Q, InputProgram,             /* 23.01.2002: */
	  ResultProgram, (P,Q,UName),            /* New Arity 8 */
	  OldConstraints, NewConstraints) :-
                                                    
	progSize(0, InputProgram, StartIndex),
                                                  
	upperBound(P, Q, UName, UDef,
		   InputProgram, StartIndex, _),
	
	treatCase(case1, UName, P, InputProgram,
		  PReplacedProgram, _,
		  OldConstraints, ResultConstr),
	
	treatCase(case1, UName, Q, PReplacedProgram,
		  PQReplacedProg, _,
		  ResultConstr, NewConstraints),
                                                 
	append(PQReplacedProg, UDef, ResultProgram).

% ---------------------------------------------------------
% New Procedure: 23.01.2002

rewrite_Constraints(_,_,[],[]) :- !.

rewrite_Constraints(NewName, OldName, 
		    [C|InputConstraints],
	            [C|OutputConstraints]) :-

	C =.. [OtherName,_],
	OtherName \== OldName,
	!,
	rewrite_Constraints(NewName, OldName,
			    InputConstraints,
			    OutputConstraints),
	!.

rewrite_Constraints(NewName, OldName, 
		    [O|InputConstraints],
	            [N|OutputConstraints]) :-

	O =.. [OldName, Argument],
	N =.. [NewName, Argument],
	!,
	rewrite_Constraints(NewName, OldName,
			    InputConstraints,
			    OutputConstraints).

% DETERMINEPLACES: ========================================
% We take a RUL program attached with unique predicate IDs
% and two predicate names X and Y which occur in the input
% program. We search an output list of XIDs such that: (i)
% each predicate name belonging to the output identifiers 
% is X. (ii) There exist clause head predicates with name 
% Y such that these Y-heads depend on at least one of the 
% X-Goals the IDs of which appear in the output list. (iii)
% No clause head predicate named X depends on at least one
% of the X-goals the IDs of which appear in the output list.
% Conditions (i),(ii),(iii) must all hold. Intended I/O-Use
% is (+,+,+,-), and the empty output list [] is returned in
% case that the search was not successful. As a consequence
% from the above specification, the output list must be the
% empty list for logical reasons if both X and Y represent
% the same predicate name. For reasons of efficiency, this
% case is made explicit below, but of course it would also
% turn out as a result of the ID-search. ==================

determinePlaces(SameName, SameName, _, []) :- !.

determinePlaces(PredNameX, PredNameY, IDprog, OutputXIDs) :-

	headList(PredNameX, IDprog, HeadXIDs),
	
	headList(PredNameY, IDprog, HeadYIDs),
        
	goalList(PredNameX, IDprog, GoalXIDs),             
                                                       
	filterPlaces(HeadXIDs, HeadYIDs, GoalXIDs,
		     OutputXIDs, IDprog). 


% HEADLIST: ===========================================
% I/O-Usage(+,+,-). Returns the identifiers of clause 
% heads with predicate name Pred in a numbered program.
% =====================================================
                                                       
headList(Pred, [proc(Pred/1, Defs)|_], Identifiers) :- 
	!,                                             
	readHeads(Defs, Identifiers).

                                                                      
headList(Pred, [_|NumProcs], Identifiers) :-           
        !,                                             
	headList(Pred, NumProcs, Identifiers).

                                               
headList(Pred, [], _) :-
	
	nl,                                 
	print('* ERROR: UNDEFINED PREDICATE '),               
	print(Pred),                                   
	print(' *'),
	fail.                                          

readHeads([([_,ID]:-_)|IdClauses], [ID|Identifiers]) :- 
        !,                                             
        readHeads(IdClauses, Identifiers).              
                                                       
readHeads([], []).                                      


% GOALLIST: =============================================
% goalList takes a predicate name and an identifiertagged
% RUL program. Returns a list of the identifiers of those
% predicates whose name is the same as the input name and
% which are goals (not heads) in the clauses of the input
% program. ==============================================

goalList(Pred, [proc(_/1, Defs)|Procs], IdList) :-    
                                                      
	readGoals(Pred, Defs, FirstIds),               
	                                               
	goalList(Pred, Procs, RestIds),                
                                                       
	append(FirstIds, RestIds, IdList).
                                                       
goalList(_, [], []).                                   
                                                       
                                                       
readGoals(Pred, [(_:-Goals)|Defs], OutputIds) :-        
                                                       
        analyse(Pred, Goals, FirstIds),                
	                                               
	readGoals(Pred, Defs, RestIds),                
                                                       
	append(FirstIds, RestIds, OutputIds).
                                          
readGoals(_, [], []).                                   
                                                       

analyse(P, ([Pred,ID], MoreGoals), [ID|MoreIds]) :- 
                                                       
	Pred =.. [P,_],                                
	!,                                             
	analyse(P, MoreGoals, MoreIds).
                                                    
analyse(P, (_, MoreGoals), Ids) :-                     
	!,                                             
	analyse(P, MoreGoals, Ids).

                                                       
analyse(P, [Pred,ID], [ID]) :-  Pred =.. [P,_], !.

                                                       
analyse(_, _, []).


% FILTERPLACES: ======================================
% An input list of goal-IDs (from a numbered input RUL
% program) is filtered according to certain relations 
% with head-IDs in that program. I/O-Usage(+,+,+,-,+).
% Because "qDependsOn" and "pIndependentOf" logically 
% exclude each other on the same input, we can write  
% the first case of "filterPlaces" as an abbreviation.
% ====================================================
                                                  
filterPlaces(SameInput, SameInput, _, [], _) :- !.          
				
filterPlaces(_, _, [], [], _) :- !.

                                                       
filterPlaces(HeadPlacesP, HeadPlacesQ, [PID|GoalPlacesP],
	     [PID|OutputPlaceList], IDprog) :- 
                                                       
	qDependsOn(PID, HeadPlacesQ, IDprog),         
                                                       
	pIndependentOf(PID, HeadPlacesP, IDprog),     
	!,                                             
	filterPlaces(HeadPlacesP, HeadPlacesQ,         
		     GoalPlacesP, OutputPlaceList,
		     IDprog). 

filterPlaces(HeadPlacesP, HeadPlacesQ, [_|GoalPlacesP],
	     OutputPlaceList, IDprog) :-   
                                                       
	filterPlaces(HeadPlacesP, HeadPlacesQ,         
		     GoalPlacesP, OutputPlaceList,
		     IDprog).

                                        
% QDEPENDSON: ========================================
% A list of head identifiers represents all the clause
% heads of a predicate Q. A single identifier stands
% for the occurrence of one certain predicate P in a 
% certain clause body of the program. We check if the
% predicate Q (represented by the list of head identi-
% fiers) depends on that special occurrence of P which
% is the case when we can find a call chain from one
% of the Q-heads to that occurrence of P. TailPID is 
% the P-identifier. "QID" is any of the head-Q-identi- 
% fiers. Intended I/O-Usage: check-only, thus (+,+,+).
% ====================================================
                                                     
qDependsOn(TailPID, [QID|_], IDprog) :-               
                                                       
	callChainID([_,QID], [_,TailPID],              
		    _, IDprog, [QID]),                
	!.                                             


qDependsOn(TailPID, [_|MoreQIDs], IDprog) :-          
                                                       
	qDependsOn(TailPID, MoreQIDs, IDprog).        


qDependsOn(_, [], _) :- !, fail.                       


% PINDEPENDENTOF: ====================================
% The opposite of "qDependsOn". A list of identifiers
% represents some clause heads. One single identifier
% represents a special occurrence of some goal. If we
% can find a call chain from one of those heads to the
% identified goal, we have detected that the heads set
% is not independent of this goal which leads to fail.
% Intended I/O-Usage is (+,+,+) for check-only. ======

pIndependentOf(TailPID, [PID|_], IDprog) :-           
                                                      
	callChainID([_,PID], [_,TailPID],              
		    _, IDprog, [PID]),                
	!,                                             
	fail.

                                                       
pIndependentOf(TailPID, [_|MorePIDs], IDprog) :-      
                                                       
	pIndependentOf(TailPID, MorePIDs, IDprog).

                                                      
pIndependentOf(_, [], _) :- !.


% TREAT2: ===========================================
% supports case 2 of the above shortening definition.
% ===================================================
                                                     
treat2(P, Q, PlaceListQIDs,                          
       [proc(X/1, InputProcDef)|InputIDprogram],     
       [proc(X/1, InterProcDef)|InterIDprogram]) :-  
                                                       
	replaceSpecialOccurrences(P, Q, PlaceListQIDs,
			          InputProcDef,       
			          InterProcDef),
                     
	treat2(P, Q, PlaceListQIDs,                   
	       InputIDprogram, InterIDprogram).
                                                   
treat2(_, _, _, [], []).                          


replaceSpecialOccurrences(P, Q, PlaceListQIDs,         
			  [(Head:-GoalsQ)|InputDefs],  
			  [(Head:-GoalsP)|InterDefs]) :-
                                                       
         substitute(P, Q, PlaceListQIDs, GoalsQ, GoalsP),
               
	 replaceSpecialOccurrences(P, Q, PlaceListQIDs,
				   InputDefs, InterDefs).
                                                       
replaceSpecialOccurrences(_, _, _, [], []).            
                                                       

/* first double case: multiple goals */        
/* a) Q to be replaced by P here    */

substitute(P, Q, PlaceListQIDs,                         
	   ([PredQ,ID], MoreGoalsQ),               
	   ([PredP,ID], MoreGoalsP)) :-        
                                               
	memberchk(ID, PlaceListQIDs),
	
	PredP =.. [P, SameArgument],
	
	PredQ =.. [Q, SameArgument],
	!,                                        
	substitute(P, Q, PlaceListQIDs,           
		   MoreGoalsQ, MoreGoalsP).        
                                                   
/* b) nothing to replace here */

substitute(P, Q, PlaceListQIDs,                  
	   (SameGoal, MoreGoalsQ),
	   (SameGoal, MoreGoalsP)) :-       
        !,                                       
	substitute(P, Q, PlaceListQIDs,        
		   MoreGoalsQ, MoreGoalsP).     
                                                 
/* second double case: single goals */           
/* a) Q to be replaced by P here   */

substitute(P, Q, PlaceListQIDs, [PredQ,ID], [PredP,ID]) :-
                                                       
	memberchk(ID, PlaceListQIDs),
	
	PredP =.. [P, SameArgument],
	
	PredQ =.. [Q, SameArgument],
	!.                          
                               
/* b) nothing to replace */       
                                   
substitute(_, _, _, Goal, Goal).


% CALLCHAINID: =============================================
% callChainID is a variant of auxil:callChain. It works for
% programs with uniquely numbered predicates. BE SURE THAT
% YOU CALL THIS TRICKY PREDICATE WITH THE PROPER INPUT PARA-
% METERS !!! "non_member" is SICSTUS built-in. =============
                                                       
callChainID([P,IDP], [Q,IDQ], [IDP,IDQ], NumProg, _) :-	
                                                       
	callsID([P,IDP], [Q,IDQ], NumProg).	       
                                                       
                                                       
callChainID([P,IDP], [Q,IDQ],                          
	    [IDP,IDR,SomeID|IDchain],                   
	    NumProg, [IDP|VisitedIDs]) :-              
                                                       
	callsID([P,IDP], [R,IDR], NumProg),
	
	non_member(IDR, [IDP|VisitedIDs]),             
	                                               
	callsID([R,SomeID], _, NumProg),
	
	non_member(SomeID, [IDP|VisitedIDs]),           
	                                               
	callChainID([R,SomeID], [Q,IDQ],                
		    [SomeID|IDchain], NumProg,          
		    [IDP,IDR,SomeID|VisitedIDs]).       
                                                       
                                                       
callsID([P,PID], [Q,QID], [proc(P/1, DefinitionP)|_]) :-   
	                                               
	inClauseID([P,PID], [Q,QID], DefinitionP),
	
	PID < QID. /* redundant: just for security */  
                                                      
                                                       
callsID([P,PID], [Q,QID], [_|NumberedProgram]) :- 
	                                               
	callsID([P,PID], [Q,QID], NumberedProgram).    
                                                       
                                                       
inClauseID([P,PID], [Q,QID], [([Predicate,PID]:-Goals)|_]) :-
                                                       
        Predicate =.. [P|_],
	
        checkBodyID([Q,QID], Goals).                   
	                                               
                                                       
inClauseID([P,PID], [Q,QID], [_|NumClauses]) :-        
                                                       
	inClauseID([P,PID], [Q,QID], NumClauses).      
	                                               
                                                       
checkBodyID([Q,QID], ([FirstGoal,QID], _)) :-          
                                                       
	FirstGoal =.. [Q|_],
	
	Q \== true.                                    

checkBodyID([Q,QID], (_, NextGoals)) :-                
                                                       
	checkBodyID([Q,QID], NextGoals).               
                                                       
checkBodyID([Q,QID], [OnlyOnePredicate,QID]) :-        
                                                       
	OnlyOnePredicate =.. [Q|_],
	
	Q \== true.                                    

% (PUBLIC) SHORTENTOFIXPOINT =========================
% shortenToFixPoint: according to Definition 3.8, page
% 602 in J.P Gallagher & D.A.deWaal, "Fast and Precise
% Regular Approximations of Logic Programs", Proc 11th
% Internat Conf on Logic Programming, MIT Press 1994. 
% The Fixpoint is reached as soon as allDependants re-
% sults in empty list []. Until we have better theore-
% tical insight I use the following HEURISTICS to pre-
% vent possible nondetermination caused by shortening:
% Let D(t,s) hold and let r be an upper bound for t or
% s. After shortening we might now have D(t,r), and so
% on. For this reason, we keep track of the shortening
% history and we exclude all cases D(t,r) from the re-
% cursion where the insertion of r to the program is a
% result from a previous shortening step caused by the
% D(t,s) relation. ===================================

shortenToFixPoint(InputProgram, OutputProgram,   /* 23.01.2002: */
		  InputConstr,  OutputConstr) :- /* New Arity 4 */
	
	/* PRECONDITION */
	isRULprog(InputProgram),

	%user:debug_nl,
	%user:debug_print('SHORTEN'),
	%user:debug_nl,
	
	shortenLoop(loop, [],
		    InputProgram, OutputProgram,
		    InputConstr,  OutputConstr).


shortenLoop(loop, ForbiddenPairs,            /* 23.01.2002: */
	    InputProgram, OutputProgram,     /* New Arity 6 */
	    InputConstr,  OutputConstr) :-

	/* Note that the history record and the
	   record of forbidden pair are obsolete
	   now because we now delete the treated
	   procedures immediately such that re-
	   shortening of them can't be tried any
	   more. The obsolete history procedures
	   will be deleted in one of the coming
	   versions of this module. (very soon) */
	   
	allDependants(InputProgram, DPredPairs),

	difference(ForbiddenPairs, DPredPairs,
		   AllowedPairs),

	exitTest(AllowedPairs, ExitDecision),
                                             
	%short(InputProgram,
	%      AllowedPairs,
	%      IntermediateProgram,
	%      ReplacementHistory),

	/* New alternative to short/4! */
	oneStepShortening(InputProgram,
			  AllowedPairs,
			  IntermediateProgram,
			  ReplacementHistory,
			  InputConstr,
			  ResultConstr),
	!,
	analyseHistory(ReplacementHistory, ResultList),

	append(ResultList, ForbiddenPairs, NewForbidden),
	!,
        shortenLoop(ExitDecision, NewForbidden,
		    IntermediateProgram, OutputProgram,
		    ResultConstr, OutputConstr).

shortenLoop(exit, _,
	    FixpointProgram,
	    FixpointProgram,
	    FixpointConstr,
	    FixpointConstr).

	%user:debug_print('EXIT LOOP'),
	%user:debug_nl.

exitTest([], exit) :- !.

exitTest(Pairs, loop) :- Pairs \== [].


% ANALYSEHISTORY: ===================================
% We construct forbidden pairs from found upper type
% information stemming from previous shortening cases
% (see above). I/O-Usage is (+,-). ==================

analyseHistory([],[]).

analyseHistory([(P,Q,U)|ReplacementHistory],
	       [(P,U),(Q,U)|ForbiddenPairs]) :-
	!,
	analyseHistory(ReplacementHistory, ForbiddenPairs).

analyseHistory([(P,U)|ReplacementHistory],
	       [(P,U)|ForbiddenPairs]) :-
	!,
	analyseHistory(ReplacementHistory, ForbiddenPairs).

analyseHistory([_|ReplacementHistory], ForbiddenPairs) :-

	analyseHistory(ReplacementHistory, ForbiddenPairs).

% -------------------------------------------------------------
% This is a work-around to the non-termination problem reported
% in communication ./ErrorReports/33.txt! Due to lack of theory
% we forbid not only the re-shortening with a fresh upperbound,
% but also the re-shortening with fresh sub-goals of that upper
% bound. ATTENTION: It may be that this kind of emergency break
% could prevent complete shortening. Some unshortened parts may
% then persist in the treated program. We don't know yet if the
% definition of a "completely" shortened program not containing
% dependencies any more is finitely computable! ---------------
/*
adHoc33(P,Q, [proc(_/1,_)|NewDefs], Pairs) :- %(obsolete) 

	fresh(NewDefs,NewTypes),
	makeTuples(P, NewTypes, PTuples),
	makeTuples(Q, NewTypes, QTuples),
	append(PTuples, QTuples, Pairs).

fresh([],[]).
fresh([proc(T/1,_)|Defs], [T|Types]) :-

	fresh(Defs, Types).

makeTuples(_,[],[]).
makeTuples(X, [Y|Zs], [(X,Y)|Tuples]) :-

	makeTuples(X, Zs, Tuples).
*/
% -------------------------------------------------------------

%##############################################################
%############################ END #############################
%##############################################################
/*
differenceList(L1,L2,OUT) :-
	
	append(L1,L2,L3),
	remove_duplicates(L3,L4),
	cutDifference(L1,L2,L4,OUT).

cutDifference([E|L1],L2,L4,OUT) :-

	memberchk(E,L2),
	!,
	delete(L4,E,L5),
	cutDifference(L1,L2,L5,OUT).

cutDifference([_|L1],L2,L4,OUT) :-

	cutDifference(L1,L2,L4,OUT).

cutDifference([],_,FIX,FIX).
*/

%---------------------------------------------------------------

test2([proc(y_fact_51/1,[(y_fact_51(0):-true)]),
       proc(y_ex_t25/1,[(y_ex_t25(member(_219392,_219390)):-any(_219392),
			 y_ex_t27(_219390))]),
       proc(y_ex_t27/1,[(y_ex_t27([_219373|_219371]):-any(_219373),
			 any(_219371))]),
       proc(y_ex_t48/1,[(y_ex_t48(s(_219298)):-any(_219298))]),
       proc(ub_t40/1,[(ub_t40(s(_219213)):-t41(_219213))]),
       proc(t41/1,[(t41(s(_219199)):-t43(_219199))]),
       proc(t43/1,[(t43(s(_219185)):-t45(_219185))]),
       proc(t45/1,[(t45(0):-true),(t45(s(_219312)):-y_fact_51(_219312))]),
       proc(any/1,[(any(_287265):-true)])],
      PROGOUT,
      [t41(A),ub_t40(B),t43(C),t45(D)],
      CONSTROUT).





 % vermutlich kein Fehler sondern nur zu gross %

test([proc(x_ex_t34758/1,[(x_ex_t34758(clause):-true)]),
      proc(x_ex_t34780/1,[(x_ex_t34780([_3432|_3431]):-x_ex_t34794(_3432),
			   x_ex_t34795(_3431))]),
      proc(x_ex_t34782/1,[(x_ex_t34782(term(_3427,_3426)):-x_ex_t34797(_3427),
			   x_ex_t34780(_3426))]),
      proc(x_ex_t34791/1,[(x_ex_t34791(term(_3405,_3404)):-x_ex_t34758(_3405),
			   x_ex_t34813(_3404))]),
      proc(x_ex_t34792/1,[(x_ex_t34792([]):-true)]),
      proc(x_ex_t34794/1,[(x_ex_t34794(var(_3401)):-x_ex_t34815(_3401))]),
      proc(x_ex_t34795/1,[(x_ex_t34795([_3398|_3397]):-x_ex_t34817(_3398),
			   x_ex_t34792(_3397))]),
      proc(x_ex_t34797/1,[(x_ex_t34797(parent):-true)]),
      proc(x_ex_t34807/1,[(x_ex_t34807([_3389|_3388]):-x_ex_t34832(_3389),
			   x_ex_t34792(_3388))]),
      proc(x_ex_t34813/1,[(x_ex_t34813([_3380|_3379]):-x_ex_t34838(_3380),
			   x_ex_t34792(_3379))]),
      proc(x_ex_t34815/1,[(x_ex_t34815(x):-true)]),
      proc(x_ex_t34817/1,[(x_ex_t34817(var(_3376)):-x_ex_t34841(_3376))]),
      proc(x_ex_t34823/1,[(x_ex_t34823(male):-true)]),
      proc(x_ex_t34824/1,[(x_ex_t34824([_3373|_3372]):-x_ex_t34794(_3373),
			   x_ex_t34792(_3372))]),
      proc(x_ex_t34832/1,[(x_ex_t34832(term(_3368,_3367)):-x_ex_t34859(_3368),
			   x_ex_t34824(_3367))]),
      proc(x_ex_t34838/1,[(x_ex_t34838(term(_3359,_3358)):-x_ex_t34823(_3359),
			   x_ex_t34866(_3358))]),
      proc(x_ex_t34841/1,[(x_ex_t34841(y):-true)]),
      proc(x_ex_t34859/1,[(x_ex_t34859(female):-true)]),
      proc(x_ex_t34862/1,[(x_ex_t34862(term(_3354,_3353)):-x_ex_t34882(_3354),
			   x_ex_t34792(_3353))]),
      proc(x_ex_t34866/1,[(x_ex_t34866([_3346|_3345]):-x_ex_t34862(_3346),
			   x_ex_t34792(_3345))]),
      proc(x_ex_t34882/1,[(x_ex_t34882(a):-true)]),
      proc(x_ex_t34885/1,[(x_ex_t34885(term(_3341,_3340)):-x_ex_t34895(_3341),
			   x_ex_t34792(_3340))]),
      proc(x_ex_t34895/1,[(x_ex_t34895(b):-true)]),
      proc(y_ex_t37896/1,[(y_ex_t37896(term(_3612,_3611)):-x_ex_t34758(_3612),
			   y_ex_t37900(_3611))]),
      proc(y_ex_t37900/1,[(y_ex_t37900([_3604|_3603]):-any(_3604),any(_3603))]),
      proc(ub_t233/1,[(ub_t233([_3484|_3483]):-t234(_3484),t235(_3483))]),
      proc(t234/1,[(t234(term(_3475,_3474)):-x_ex_t34758(_3475),t237(_3474))]),
      proc(t235/1,[(t235([_3471|_3470]):-t239(_3471),t240(_3470))]),
      proc(t237/1,[(t237([_3467|_3466]):-t242(_3467),t243(_3466))]),
      proc(t239/1,[(t239(term(_3462,_3461)):-x_ex_t34758(_3462),t245(_3461))]),
      proc(t240/1,[(t240([_3458|_3457]):-t247(_3458),t248(_3457))]),
      proc(t242/1,[(t242(term(_3453,_3452)):-t250(_3453),x_ex_t34780(_3452))]),
      proc(t243/1,[(t243([_3449|_3448]):-x_ex_t34782(_3449),t252(_3448))]),
      proc(t245/1,[(t245([_3445|_3444]):-t254(_3445),t255(_3444))]),
      proc(t247/1,[(t247(term(_3440,_3439)):-x_ex_t34758(_3440),t257(_3439))]),
      proc(t248/1,[(t248([_3436|_3435]):-x_ex_t34791(_3436),
		    x_ex_t34792(_3435)),(t248([]):-true)]),
      proc(t250/1,[(t250(father):-true),(t250(mother):-true)]),
      proc(t252/1,[(t252([_3423|_3422]):-t261(_3423),x_ex_t34792(_3422))]),
      proc(t254/1,[(t254(term(_3418,_3417)):-t263(_3418),t264(_3417))]),
      proc(t255/1,[(t255([_3414|_3413]):-x_ex_t34782(_3414),
		    x_ex_t34807(_3413)),(t255([]):-true)]),
      proc(t257/1,[(t257([_3410|_3409]):-t267(_3410),x_ex_t34792(_3409))]),
      proc(t261/1,[(t261(term(_3393,_3392)):-t269(_3393),x_ex_t34824(_3392))]),
      proc(t263/1,[(t263(mother):-true),(t263(parent):-true)]),
      proc(t264/1,[(t264([_3432|_3431]):-t272(_3432),t273(_3431))]),
      proc(t267/1,[(t267(term(_3384,_3383)):-t275(_3384),t276(_3383))]),
      proc(t269/1,[(t269(male):-true),(t269(female):-true)]),
      proc(t272/1,[(t272(var(_3401)):-x_ex_t34815(_3401)),
		   (t272(term(_3509,_3508)):-x_ex_t34882(_3509),
		       x_ex_t34792(_3508))]),
      proc(t273/1,[(t273([_3398|_3397]):-t280(_3398),x_ex_t34792(_3397))]),
      proc(t275/1,[(t275(parent):-true),(t275(male):-true)]),
      proc(t276/1,[(t276([_3364|_3363]):-x_ex_t34862(_3364),t283(_3363))]),
      proc(t280/1,[(t280(var(_3376)):-x_ex_t34841(_3376)),
		   (t280(term(_3496,_3495)):-x_ex_t34895(_3496),
		       x_ex_t34792(_3495))]),
      proc(t283/1,[(t283([_3350|_3349]):-x_ex_t34885(_3350),
		    x_ex_t34792(_3349)),(t283([]):-true)]),
      proc(any/1,[(any(_6052):-true)])]).
