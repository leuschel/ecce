%#################################################################
%####################### MODULE: COMPRESSION #####################
%#################################################################

:- module(compressor, [compress/2, fetchProcedure/3]).

:- use_module(library(lists)).
:- use_module(library(terms)).
:- use_module(self_check).

:- use_module(subType, 'subType.pl', [subType/3]).

:- use_module(prePostCon, 'prePostCon.pl', [isRCD/1,
					    isNormal/1]).

:- use_module(auxil, 'auxil.pl', [replaceAllOccurrences/4,
				  pruneRCD/2]).

%#########################################################
%(PUBLIC) COMPRESS: ======================================
% Isn't it ridiculous what a stupid monkeyDonkey I am! Had
% I written a clumsy lenghty buggy compressor from scratch,
% instead of simply re-using all the bits and pieces which
% are already at hand! Well, eventually I got the idea and
% here is a new and more elegant compressor version. Later
% I might write a more efficient one according to Ullman's
% automaton minimisation but for now this'll be sufficient.
% Export fetchProcedure/3, though not used in this module
% any more, is still exported as long as I don't know who
% is importing it :) ====================================

:- assert_pre(compressor:compress(In,_),
	      (prePostCon:isRCD(In),
		  In = rul__constraint__declaration(InC,_),
		  prePostCon:isNormal(InC))).

:- assert_post(compressor:compress(_,Out),
	       (prePostCon:isRCD(Out),
		   Out = rul__constraint__declaration(OutC,_),
		   prePostCon:isNormal(OutC))).

%############################################################
%------------------------------------------------------------

allTypes([proc(T/1,_)|RULprog], [T|TypeList]) :-
	!,
	allTypes(RULprog, TypeList).

allTypes([],[]).

%------------------------------------------------------------

equivalentType(any, any, _) :- !.

equivalentType(SameT, SameT, _) :-

	atom(SameT),
	!.

equivalentType(TX, TY, RULprog) :-

	subType(TX, TY, RULprog),
	!,
	subType(TY, TX, RULprog),
	!.

equivalentType(_,_,_) :- !, fail.

%------------------------------------------------------------

equivalenceClasses([T|TypeList], [ClassT|Classes], RULprog) :-

	findClass(T, [T|TypeList], ClassT, RestList, RULprog),
	!,
	equivalenceClasses(RestList, Classes, RULprog).

equivalenceClasses([],[],_).

%------------------------------------------------------------

findClass(T, [TY|TypeList], [TY|Class], RestList, RULprog) :-

	equivalentType(T, TY, RULprog),
	!,
	delete(TypeList, TY, SmallerList),
	!,
	findClass(T, SmallerList, Class, RestList, RULprog).

findClass(T, [NE|TypeList], Class, [NE|RestList], RULprog) :-

	/* case: Not Equivalent */

	delete(TypeList, NE, SmallerList),
	!,
	findClass(T, SmallerList, Class, RestList, RULprog).

findClass(_,[],[],[],_).

%============================================================
%[PUBLIC]

compress(FatRCD, SlimRCD) :-

	pruneRCD(FatRCD, BaseRCD),
	!,
	shrinkRCD(BaseRCD, SlimRCD),
	!,
	showResult(FatRCD, SlimRCD).

%============================================================

showResult(rul__constraint__declaration(_,Fat),
	   rul__constraint__declaration(_,Slim)) :-

	length(Fat, Long),
	length(Slim, Short),
	!,
	nl,
	print('<<< Compr.Result: Factor '),
	print(Short),
	print('/'),
	print(Long),
	print(' in #Proc.Definitions >>>'),
	nl.

%------------------------------------------------------------

shrinkRCD(rul__constraint__declaration(OldC,OldP),
	  rul__constraint__declaration(NewC,NewP)) :-

	allTypes(OldP, Types),
	!,
	equivalenceClasses(Types, Classes, OldP),
	!,
	rewriteConstr(Classes, OldC, NewC),
	!,
	rewriteProgrm(Classes, OldP, NewP).

%------------------------------------------------------------

rewriteConstr(Classes, [OC|Old], [NC|New]) :-

	OC =.. [OldName, Var],
	
	identify(OldName, Classes, NewName),
	!,
	NC =.. [NewName, Var],
	
	rewriteConstr(Classes, Old, New).

rewriteConstr(Classes, [Same|Old], [Same|New]) :-

	rewriteConstr(Classes, Old, New).

rewriteConstr(_,[],[]).

%------------------------------------------------------------

identify(OldName, [[NewName|EquiTypes]|_], NewName) :-

	memberchk(OldName, EquiTypes),
	!.

identify(OldName, [_|EquiClasses], NewName) :-

	identify(OldName, EquiClasses, NewName).

identify(_,[],_) :- !, fail.

%------------------------------------------------------------

rewriteProgrm(EqClasses, OldProg, NewProg) :-

	cutEquivalents(EqClasses, OldProg, Result),
	!,
	rewriteCalls(EqClasses, Result, NewProg).

%------------------------------------------------------------

cutEquivalents([[T|EqTypes]|EqClasses], InProg, OutProg) :-

	discardProcs(EqTypes, InProg, Result),
	!,
	cutEquivalents(EqClasses, Result, OutProg).

cutEquivalents([], FIX, FIX).

%------------------------------------------------------------

discardProcs([T|Obsolete], InProg, OutProg) :-

	memberchk(proc(T/1,Def), InProg),
	!,
	delete(InProg, proc(T/1,Def), Result),
	!,
	discardProcs(Obsolete, Result, OutProg).

discardProcs([_|Obsolete], InProg, OutProg) :-

	/* This case should not occur! (LifeGuard) */
	nl,
	print('ALARM(1)!'),
	nl,

	discardProcs(Obsolete, InProg, OutProg).

discardProcs([], FIX, FIX).

%------------------------------------------------------------

rewriteCalls([[T,ET|EqTypes]|EqClasses], InProg, OutProg) :-
	!,
	replaceInProgram(InProg, T, ET, Result),
	!,
	rewriteCalls([[T|EqTypes]|EqClasses], Result, OutProg).

rewriteCalls([[_]|EqClasses], InProg, OutProg) :-
	!,
	rewriteCalls(EqClasses, InProg, OutProg).

rewriteCalls([_|EqClasses], InProg, OutProg) :-

	/* This case should not occur! (LifeGuard) */
	nl,
	print('ALARM(2)!'),
	nl,
	
	rewriteCalls(EqClasses, InProg, OutProg).

rewriteCalls([], FIX, FIX).

%------------------------------------------------------------

replaceInProgram([proc(N/1, OldDef)|OldProcs], NewName,
		 OldName, [proc(N/1, NewDef)|NewProcs]) :-

	replaceAllOccurrences(NewName,OldName,
			      OldDef, NewDef),
        !,
	replaceInProgram(OldProcs, NewName,
			 OldName, NewProcs).

replaceInProgram([],_,_,[]).

%############################################################


%=================================================
%[PUBLIC:LEGACY]
fetchProcedure(P, [proc(P/1,Def)|_], Procedure) :-

	nonvar(Def),
	!,
	/* copy_term: with fresh variables */
	/* to avoid confusion             */
	copy_term(proc(P/1,Def), Procedure).

fetchProcedure(P, [_|Program], Proc) :-
	fetchProcedure(P, Program, Proc).

fetchProcedure(_,[],_) :- !, fail.
%=================================================


%###############################################################
%############################# END #############################
%###############################################################

%---Test------

test(rul__constraint__declaration([x_ex_t34791(_263527),
				   x_ex_t34792(_263528)],
 [proc(x_ex_t34791/1,
      [(x_ex_t34791(term(_5931,_5929)):-x_ex_t34812(_5931),
	                                x_ex_t34813(_5929))]),
 proc(x_ex_t34792/1,
      [(x_ex_t34792([]):-true)]),
 proc(x_ex_t34806/1,
      [(x_ex_t34806(term(_5820,_5818)):-x_ex_t34829(_5820),
	                                x_ex_t34830(_5818))]),
 proc(x_ex_t34807/1,
      [(x_ex_t34807([_5801|_5799]):-x_ex_t34832(_5801),
	                            x_ex_t34833(_5799))]),
 proc(x_ex_t34812/1,
      [(x_ex_t34812(clause):-true)]),
 proc(x_ex_t34813/1,
      [(x_ex_t34813([_5762|_5760]):-x_ex_t34838(_5762),
	                            x_ex_t34839(_5760))]),
 proc(x_ex_t34829/1,
      [(x_ex_t34829(parent):-true)]),
 proc(x_ex_t34830/1,
      [(x_ex_t34830([_5644|_5642]):-x_ex_t34856(_5644),
	                            x_ex_t34857(_5642))]),
 proc(x_ex_t34832/1,
      [(x_ex_t34832(term(_5624,_5622)):-x_ex_t34859(_5624),
	                                x_ex_t34860(_5622))]),
 proc(x_ex_t34833/1,
      [(x_ex_t34833([]):-true)]),
 proc(x_ex_t34838/1,
      [(x_ex_t34838(term(_5585,_5583)):-x_ex_t34865(_5585),
	                                x_ex_t34866(_5583))]),
 proc(x_ex_t34839/1,
      [(x_ex_t34839([]):-true)]),
 proc(x_ex_t34851/1,
      [(x_ex_t34851(x):-true)]),
 proc(x_ex_t34856/1,
      [(x_ex_t34856(var(_5524)):-x_ex_t34874(_5524))]),
 proc(x_ex_t34857/1,
      [(x_ex_t34857([_5510|_5508]):-x_ex_t34876(_5510),
	                            x_ex_t34877(_5508))]),
 proc(x_ex_t34859/1,
      [(x_ex_t34859(female):-true)]),
 proc(x_ex_t34860/1,
      [(x_ex_t34860([_5491|_5489]):-x_ex_t34879(_5491),
	                            x_ex_t34880(_5489))]),
 proc(x_ex_t34865/1,
      [(x_ex_t34865(male):-true)]),
 proc(x_ex_t34866/1,
      [(x_ex_t34866([_5433|_5431]):-x_ex_t34888(_5433),
	                            x_ex_t34889(_5431))]),
 proc(x_ex_t34872/1,
      [(x_ex_t34872(y):-true)]),
 proc(x_ex_t34874/1,
      [(x_ex_t34874(x):-true)]),
 proc(x_ex_t34876/1,
      [(x_ex_t34876(var(_5414)):-x_ex_t34891(_5414))]),
 proc(x_ex_t34877/1,
      [(x_ex_t34877([]):-true)]),
 proc(x_ex_t34879/1,
      [(x_ex_t34879(var(_5400)):-x_ex_t34893(_5400))]),
 proc(x_ex_t34880/1,
      [(x_ex_t34880([]):-true)]),
 proc(x_ex_t34885/1,
      [(x_ex_t34885(term(_5385,_5383)):-x_ex_t34895(_5385),
	                                x_ex_t34896(_5383))]),
 proc(x_ex_t34886/1,
      [(x_ex_t34886([]):-true)]),
 proc(x_ex_t34888/1,
      [(x_ex_t34888(term(_5365,_5363)):-x_ex_t34898(_5365),
	                                x_ex_t34899(_5363))]),
 proc(x_ex_t34889/1,
      [(x_ex_t34889([]):-true)]),
 proc(x_ex_t34891/1,
      [(x_ex_t34891(y):-true)]),
 proc(x_ex_t34893/1,
      [(x_ex_t34893(x):-true)]),
 proc(x_ex_t34895/1,
      [(x_ex_t34895(b):-true)]),
 proc(x_ex_t34896/1,
      [(x_ex_t34896([]):-true)]),
 proc(x_ex_t34898/1,
      [(x_ex_t34898(a):-true)]),
 proc(x_ex_t34899/1,
      [(x_ex_t34899([]):-true)]),
 proc(y_ex_t37896/1,
      [(y_ex_t37896(term(_7074,_7072)):-y_ex_t37899(_7074),
	                                y_ex_t37900(_7072))]),
 proc(y_ex_t37899/1,
      [(y_ex_t37899(clause):-true)]),
 proc(y_ex_t37900/1,
      [(y_ex_t37900([_7036|_7034]):-any(_7036),
	                            any(_7034))]),
 proc(y_ex_t37905/1,
      [(y_ex_t37905(clause):-true)]),
 proc(y_ex_t37914/1,
      [(y_ex_t37914(clause):-true)]),
 proc(y_ex_t37921/1,
      [(y_ex_t37921([_6842|_6840]):-y_ex_t37932(_6842),
	                            y_ex_t37933(_6840))]),
 proc(y_ex_t37923/1,
      [(y_ex_t37923(term(_6822,_6820)):-y_ex_t37935(_6822),
	                                y_ex_t37936(_6820))]),
 proc(y_ex_t37929/1,
      [(y_ex_t37929(clause):-true)]),
 proc(y_ex_t37932/1,
      [(y_ex_t37932(var(_6745)):-y_ex_t37947(_6745))]),
 proc(y_ex_t37933/1,
      [(y_ex_t37933([_6731|_6729]):-y_ex_t37949(_6731),
	                            y_ex_t37950(_6729))]),
 proc(y_ex_t37935/1,
      [(y_ex_t37935(parent):-true)]),
 proc(y_ex_t37936/1,
      [(y_ex_t37936([_6712|_6710]):-y_ex_t37952(_6712),
	                            y_ex_t37953(_6710))]),
 proc(y_ex_t37939/1,
      [(y_ex_t37939([]):-true)]),
 proc(y_ex_t37945/1,
      [(y_ex_t37945([]):-true)]),
 proc(y_ex_t37947/1,
      [(y_ex_t37947(x):-true)]),
 proc(y_ex_t37949/1,
      [(y_ex_t37949(var(_6634)):-y_ex_t37964(_6634))]),
 proc(y_ex_t37950/1,
      [(y_ex_t37950([]):-true)]),
 proc(y_ex_t37952/1,
      [(y_ex_t37952(var(_6620)):-y_ex_t37966(_6620))]),
 proc(y_ex_t37953/1,
      [(y_ex_t37953([_6606|_6604]):-y_ex_t37968(_6606),
	                            y_ex_t37969(_6604))]),
 proc(y_ex_t37956/1,
      [(y_ex_t37956([_6587|_6585]):-y_ex_t37971(_6587),
	                            y_ex_t37972(_6585))]),
 proc(y_ex_t37964/1,
      [(y_ex_t37964(y):-true)]),
 proc(y_ex_t37966/1,
      [(y_ex_t37966(x):-true)]),
 proc(y_ex_t37968/1,
      [(y_ex_t37968(var(_6510)):-y_ex_t37983(_6510))]),
 proc(y_ex_t37969/1,
      [(y_ex_t37969([]):-true)]),
 proc(y_ex_t37971/1,
      [(y_ex_t37971(var(_6496)):-y_ex_t37985(_6496))]),
 proc(y_ex_t37972/1,
      [(y_ex_t37972([]):-true)]),
 proc(y_ex_t37974/1,
      [(y_ex_t37974(a):-true)]),
 proc(y_ex_t37975/1,
      [(y_ex_t37975([]):-true)]),
 proc(y_ex_t37978/1,
      [(y_ex_t37978([]):-true)]),
 proc(y_ex_t37980/1,
      [(y_ex_t37980(term(_6461,_6459)):-y_ex_t37990(_6461),
	                                y_ex_t37991(_6459))]),
 proc(y_ex_t37983/1,
      [(y_ex_t37983(y):-true)]),
 proc(y_ex_t37985/1,
      [(y_ex_t37985(x):-true)]),
 proc(y_ex_t37987/1,
      [(y_ex_t37987(b):-true)]),
 proc(y_ex_t37988/1,
      [(y_ex_t37988([]):-true)]),
 proc(y_ex_t37990/1,
      [(y_ex_t37990(a):-true)]),
 proc(y_ex_t37991/1,
      [(y_ex_t37991([]):-true)]),
 proc(ub_t391/1,
      [(ub_t391([_6280|_6278]):-t392(_6280),
	                        t393(_6278))]),
 proc(t392/1,
      [(t392(term(_6241,_6239)):-y_ex_t37905(_6241),
	                                t395(_6239))]),
 proc(t393/1,
      [(t393([_6222|_6220]):-t397(_6222),
	                     t398(_6220))]),
 proc(t395/1,
      [(t395([_6203|_6201]):-t400(_6203),
	                     t401(_6201))]),
 proc(t397/1,
      [(t397(term(_6183,_6181)):-y_ex_t37914(_6183),
	                                t403(_6181))]),
 proc(t398/1,
      [(t398([_6164|_6162]):-t405(_6164),
	                     t406(_6162))]),
 proc(t400/1,
      [(t400(term(_6144,_6142)):-t408(_6144),
	                  y_ex_t37921(_6142))]),
 proc(t401/1,
      [(t401([_6125|_6123]):-y_ex_t37923(_6125),
	                            t410(_6123))]),
 proc(t403/1,
      [(t403([_6106|_6104]):-t412(_6106),
	                     t413(_6104))]),
 proc(t405/1,
      [(t405(term(_6086,_6084)):-y_ex_t37929(_6086),
	                                t415(_6084))]),
 proc(t406/1,
      [(t406([_6067|_6065]):-x_ex_t34791(_6067),
	                     x_ex_t34792(_6065)),
       (t406([]):-true)]),
 proc(t408/1,
      [(t408(father):-true),
       (t408(mother):-true)]),
 proc(t410/1,
      [(t410([_6009|_6007]):-t419(_6009),
	              y_ex_t37939(_6007))]),
 proc(t412/1,
      [(t412(term(_5989,_5987)):-t421(_5989),
	                         t422(_5987))]),
 proc(t413/1,
      [(t413([_5970|_5968]):-x_ex_t34806(_5970),
	                     x_ex_t34807(_5968)),
       (t413([]):-true)]),
 proc(t415/1,
      [(t415([_5951|_5949]):-t425(_5951),
	              y_ex_t37945(_5949))]),
 proc(t419/1,
      [(t419(term(_5859,_5857)):-t427(_5859),
	                  y_ex_t37956(_5857))]),
 proc(t421/1,
      [(t421(mother):-true),
       (t421(parent):-true)]),
 proc(t422/1,
      [(t422([_5840|_5838]):-t430(_5840),
	                     t431(_5838))]),
 proc(t425/1,
      [(t425(term(_5781,_5779)):-t433(_5781),
	                         t434(_5779))]),
 proc(t427/1,
      [(t427(male):-true),
       (t427(female):-true)]),
 proc(t430/1,
      [(t430(var(_5677)):-x_ex_t34851(_5677)),
       (t430(term(_6567,_6565)):-y_ex_t37974(_6567),
	                         y_ex_t37975(_6565))]),
 proc(t431/1,
      [(t431([_5663|_5661]):-t438(_5663),
	              y_ex_t37978(_5661))]),
 proc(t433/1,
      [(t433(parent):-true),
       (t433(male):-true)]),
 proc(t434/1,
      [(t434([_5605|_5603]):-y_ex_t37980(_5605),
	                            t441(_5603))]),
 proc(t438/1,
      [(t438(var(_5538)):-x_ex_t34872(_5538)),
       (t438(term(_6481,_6479)):-y_ex_t37987(_6481),
	                         y_ex_t37988(_6479))]),
 proc(t441/1,
      [(t441([_5452|_5450]):-x_ex_t34885(_5452),
	                     x_ex_t34886(_5450)),
       (t441([]):-true)]),
 proc(any/1,
      [(any(_796935):-true)])])).


