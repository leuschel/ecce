% #######################################################
% ATTENTION: This File is only required in Stefan's Local
% test environment! It MUST NOT be loaded within the ECCE
% system! ###############################################

/* --------------------------------------------- */
/* (C) COPYRIGHT MICHAEL LEUSCHEL 1995,1996,1997 */
/* --------------------------------------------- */

/* ========= */
/* DEBUGGING */
/* ========= */

:- dynamic debug_printing/1.

/* ---------------- */
/* debug_printing/1 */
/* ---------------- */

debug_printing(on). /* on  or  off */

/* ------------------------------------ */
/* set_debug_printing_value/0 */
/* ------------------------------------ */

set_debug_printing_value :-
	print('Debugging Information Printing:'),nl,
	print('on: (Print Debugging/Tracing Info)'),nl,
	print('off:(No Debugging/Tracing info)'),nl,
	print('Current choice: '),
	debug_printing(Cur),
	print(Cur),nl,
	print('choice =>'),
	read(NewValue),
	((not(NewValue=on),not(NewValue=off))
	 -> (print('Illegal value, assuming off'),nl,
	     set_debug_printing(off))
	 ;  (set_debug_printing(NewValue))
	).

/* -------------------- */
/* set_debug_printing/1 */
/* -------------------- */

set_debug_printing(_NewVal) :-
	retract(debug_printing(_Cur)),
	fail.
set_debug_printing(NewVal) :-
	asserta(debug_printing(NewVal)).

/* ------------- */
/* debug_print/1 */
/* ------------- */

debug_print(X) :-
	debug_printing(on),!,
	print(X).
debug_print(_X).

/* --------- */
/* debug_nl/ */
/* --------- */

debug_nl :-
	debug_printing(on),!,
	nl.
debug_nl.

%####################################################



















