%###############################################################
%################### MODULE: HISTORY DATABASE ##################
%###############################################################

:- module(historyDB, [markEvent/2, storeData/2,
		      events/0, data/0, history/0]).

:- use_module(library(lists)).

:- use_module(gensym2, 'gensym2.pl', [seed/1]).

% ==============================================================
% PURPOSE: support the Pre-and-Post-Condition-Module. As soon as
% some specified pre- or post condition is found violated we can
% use this database to store the according event for the purpose
% of analysis and debugging. ===================================
%###############################################################

markEvent(EventDescription,
	  OutputReference) :-

	seed(KEY),

	recordz(KEY,
		EventDescription,
		ADR),

	addressToKey(ADR,
		     OutputReference).

%---------------------------------------------------------------

storeData(InputKey, EventData) :-

	recordz(InputKey,
		EventData,_).

%---------------------------------------------------------------

history :-

	/* outputs the whole population */
	/* We enforce backtracking with */
	/* fail.                        */

	nl,
	current_key(Key,_),
	number(Key),
	
        nl,
	print('KEY '),
	print(Key),
	
	nl,
	entry(Key),

	recorded(Key,  _, ADR),
	addressToKey(ADR, Ref),
	name(Ref, [107|_]),
	
	nl,
	entry(Ref),
	
	fail.

history.

%---------------------------------------------------------------

events :-
	
	/* outputs the event population */
	/* We enforce backtracking with */
	/* fail.                        */

	nl,
	current_key(Key,_),
	number(Key),
        nl,
	print('KEY '),
	print(Key),
	
	nl,
	entry(Key),
	
	fail.

events.

%---------------------------------------------------------------

data :-
	/* outputs the data population, */
	/* We enforce backtracking with */
	/* fail.                        */

	nl,
	current_key(Key,_),
	name(Key, [107|_]),
        nl,
	print('KEY '),
	print(Key),
	
	nl,
	entry(Key),
	
	fail.

data.

%---------------------------------------------------------------

entry(Key) :-

	recorded(Key, Item, A),
	nl,
	print('     ITEM    '),
	print(Item),
	nl,
	print('     ADDR    '),
	print(A),
	nl.

%---------------------------------------------------------------

addressToKey(Address, Key) :-

	/* Transform a database address */
	/* into a database key which is */
	/* useful for data structuring  */
	/* and cross referencing the DB */
	
	Address =.. ['$ref'|[A,B]],

	name(A, CodeA),
	name(B, CodeB),

	append([107|CodeA],
	        [95|CodeB],
	            CodeK),

	name(Key, CodeK).

%###############################################################
%############################ END ##############################
%###############################################################
