%###################################################################
%################### MODULE: AUXILIARY PROCEDURES ##################
%###################################################################

:- module(auxil, [combinePairs/2, progSize/3, attachID/4,
		  deleteID/2, difference/3, wellDefined/3,
		  removeClause/4, newName/2, sameSet/2,
		  onlyVariables/1, replaceAllOccurrences/4,
		  pruneRCD/2, globalDepends/3, prepareTriple/10,
		  fillUpWithANY/3, coordinateVariables/4,
		  listToGoal/2, orderSubGoals/2]).

% WARNING !!! The procedures provided by this module are used
% by many other modules! So please don't do any changes unless
% you are sure that your changes don't have unwanted effects in
% other modules (of which you might be not aware) !!! Thank you.

:- use_module(library(lists)).
:- use_module(library(terms)).

:- use_module(historyDB, 'historyDB.pl', [markEvent/2, storeData/2]).
%###################################################################


% ORDERSUBGOALS: ==========================================
% Brings sub goals of a clause in proper order with respect
% to the order of variables in the clause head. The input
% program is required to be RUL! For example the old clause
% {p(f(X,Y)):-q(Y),r(X)} will be replaced by the new clause
% {p(f(X,Y)):-r(X),q(Y)}. =================================

orderSubGoals([proc(N/1, OldDefN)|OldRULprog],
	      [proc(N/1, NewDefN)|NewRULprog]) :-

	orderDefinition(OldDefN, NewDefN),

	orderSubGoals(OldRULprog, NewRULprog).

orderSubGoals([],[]).

orderDefinition([OldClause|OldDef],
		[NewClause|NewDef]) :-

	orderClause(OldClause, NewClause),

	orderDefinition(OldDef, NewDef).

orderDefinition([],[]).

orderClause((Fact:-true), (Fact:-true)) :- !.

orderClause((Head:-OldSubGoals),
	    (Head:-NewSubGoals)) :-

        Head =.. [_,Argument],
	Argument =.. [_|Vars],

	onlyVariables(Vars),

	listToGoal(OldList, OldSubGoals),
	
	arrange(Vars, OldList, NewList),

	listToGoal(NewList, NewSubGoals).

arrange([V|Vars], [G|OldList], [G|NewList]) :-

	G =.. [_, Var],

	V == Var,
	!,
	arrange(Vars, OldList, NewList).

arrange(Vars, [G|OldList], NewList) :-

	append(OldList, [G], InterList),

	/* terminates iff RUL syntax! */

	arrange(Vars, InterList, NewList).

arrange([],[],[]).


% LISTTOGOAL: =========================================
% a simple structural transformation in both directions.
% =====================================================

listToGoal([P|Preds], (P,Goals)) :-

	listToGoal(Preds, Goals).

listToGoal([Predicate], Predicate) :-

	Predicate \= (_,_).


% (PUBLIC) FILLUPWITHANY: ===============================
% Unconstrained goal variables get the any-constraint per
% default. The input goals must be in goal normal form.
% =======================================================

fillUpWithANY([], Constraints, Constraints).

fillUpWithANY([G|InputGoals], InputConstr, OutputConstr) :-

	term_variables(G, Variables),

	fillUp(Variables, InputConstr, InterResult),

	fillUpWithANY(InputGoals, InterResult, OutputConstr).

fillUp([], Constr, Constr).

fillUp([V|Variables], OldConstr, NewConstr) :-

	find(V, OldConstr),
	!,
	fillUp(Variables, OldConstr, NewConstr).

fillUp([V|Variables], OldConstr, NewConstr) :-

	fillUp(Variables, [any(V)|OldConstr], NewConstr).

find(V, [C|_]) :-

	C =.. [_,Var],
	V == Var,
	!.

find(V, [_|Constraints]) :-

	find(V, Constraints).


% (PUBLIC) PRUNERCD ========================================
% Takes a RUL constraint declaration and removes all clauses
% from the corresponding program which do not contribute to
% the definition of the given constraints. Thus, the output
% program does not contain any dead code any more w.r.t. the
% given constraints. =======================================

pruneRCD(rul__constraint__declaration([], _),
	 rul__constraint__declaration([],[])) :- !.

pruneRCD(rul__constraint__declaration(Constraints,
				      InputProgram),
	 rul__constraint__declaration(Constraints,
				      OutputProgram)) :-

	deleteANY(InputProgram, WithoutANY),

	append(WithoutANY,
	       [proc(any/1, [(any(_):-true)])],
	       InterProgram),

	findPruningCandidates(Constraints,
			      InterProgram,
			      Candidates),

	pruneProgram(Candidates, InterProgram,
		     OutputProgram),

	OutputProgram \= [],
	!.

pruneRCD(RCD, RCD) :-
	nl,
	print('* Pruning Warning: Strange Input RCD: stored in DB. *'),
	nl,
	markEvent(strange_Pruning_Input, Ref),
	storeData(Ref, RCD),
	!.


deleteANY([proc(any/1,_)|OldProcs], NewProcs) :-
	!,
	deleteANY(OldProcs, NewProcs).

deleteANY([Proc|OldProcs], [Proc|NewProcs]) :-

	deleteANY(OldProcs, NewProcs).

deleteANY([],[]).


pruneProgram([], ThisProgram, ThisProgram).

pruneProgram([P|ProcNames], InputProgram, OutputProgram) :-

	deleteDefinition(P, InputProgram, Result),

	pruneProgram(ProcNames, Result, OutputProgram).

deleteDefinition(_, [], []).

deleteDefinition(P, [proc(P/1,_)|Program], Program) :- !.

deleteDefinition(P, [ProcDef|ProgIn], [ProcDef|ProgOut]) :-

	deleteDefinition(P, ProgIn, ProgOut).
	
findPruningCandidates(Constraints, Program, Candidates) :-

	extractPredicateNames(Constraints, ConstrNames),

	extractProcedureNames(Program, ProcNames),

	getNonPruningNames(ConstrNames, ProcNames,
			   Program, NonCandidates),

        extractPruningNames(ProcNames, NonCandidates,
	                    Candidates).

extractPruningNames([], _, []).

extractPruningNames([P|ProcNames], NonCands, [P|Cands]) :-

	non_member(P, NonCands),
	!,
	extractPruningNames(ProcNames, NonCands, Cands).

extractPruningNames([_|ProcNames], NonCands, Cands) :-

	extractPruningNames(ProcNames, NonCands, Cands).

extractPredicateNames([], []).

extractPredicateNames([P|Preds], [N|Names]) :-

	P =.. [N|_],

	extractPredicateNames(Preds, Names).

extractProcedureNames([], []).

extractProcedureNames([proc(N/1,_)|Procs], [N|Names]) :-

	extractProcedureNames(Procs, Names).

getNonPruningNames([], _, _, []) :- !.

getNonPruningNames(ConstrNames, ProcNames,
		   Program, NonCandidates) :-

	dependTest(ConstrNames, ProcNames,
		   Program, TestResult),

	append(ConstrNames, TestResult,
	       NonCandidates).

dependTest([], _, _, []).

dependTest([C|ConstrNames], ProcNames,
	   Program, TestResult) :-

	dependCheck(C, ProcNames,
		    Program, Dependants),

	dependTest(ConstrNames, ProcNames,
		   Program, InterResult),

	append(Dependants, InterResult,
	       TestResult).

dependCheck(_, [], _, []).

dependCheck(NameP,   [NameQ|ProcNames],
	    Program, [NameQ|Dependants]) :-

	globalDepends(NameP, NameQ, Program),
	!,
	dependCheck(NameP, ProcNames,
		    Program, Dependants).

dependCheck(NameP, [_|ProcNames],
	    Program, Dependants) :-

	dependCheck(NameP, ProcNames,
		    Program, Dependants).


% (PUBLIC) REPLACEALLOCCURRENCES ==========================
% This procedure supports shortening. Given new name P, old
% Name Q and a RUL program, all clause goals Q(X) are repla-
% ced by P(X). Clause heads stay as they are. =============

replaceAllOccurrences(P, Q,
		      [(Head:-InputGoals)|InputDefs],
		      [(Head:-ResultGoals)|ResultDefs]) :-
                                                      
	replaceInClauses(P, Q, InputGoals, ResultGoals),
                                                       
	replaceAllOccurrences(P, Q, InputDefs, ResultDefs).
                                          
replaceAllOccurrences(_, _, [], []).

                                        
replaceInClauses(_, _, true, true) :- !.
                                    
replaceInClauses(P, Q,                          
		 (FirstInputGoal, MoreInputGoals),
		 (FirstResultGoal, MoreResultGoals)) :-
	!,                                            
	replaceGoal(P, Q, FirstInputGoal, FirstResultGoal),
                                            
	replaceInClauses(P, Q,              
			 MoreInputGoals, 
			 MoreResultGoals).
                                        
replaceInClauses(P, Q, OneInputGoal, OneResultGoal) :-
                                          
	replaceGoal(P, Q, OneInputGoal, OneResultGoal).

/* P(X) replaces Q(X). Q is overwritten by P. */

replaceGoal(P, Q, PredQ, PredP) :-
                                                       
	PredQ =.. [Q, SameArgument],
	
	PredP =.. [P, SameArgument],                   
	!.                                             

/* goals with other names remain unchanged. */

replaceGoal(_, _, SameGoal, SameGoal).


% (PUBLIC) ONLYVARIABLES: ==========================
% Checks if a non-empty List contains only Variables.
% ==================================================

onlyVariables([X]) :- var(X), !.                       
                                                       
onlyVariables([X|Xn]) :-                               
                                                       
	var(X),
	
	onlyVariables(Xn).                             


% (PUBLIC) WELLDEFINED: ===========================
% Checks if a type name corresponds to a definition
% with respect to the given program representation.
% =================================================

wellDefined(PredName, PredDef, RULprogram) :-
	
      inProgram(PredName, PredDef, RULprogram),
      !.

wellDefined(PredName, _, _) :-

      nl,
      print('* ERROR: PREDICATE '),
      print(PredName/1),
      print(' NOT FOUND *'),
      nl,
      
      fail.

inProgram(PredName, PredDef, [proc(PredName/1, PredDef)|_]) :- !.

inProgram(PredName, PredDef, [proc(_,_)|RULprogram]) :-
	
      inProgram(PredName, PredDef, RULprogram).


% (PUBLIC) REMOVECLAUSE: ===================================
% Takes a predicate and its goals and a definition list, and
% REMOVES from the list THE FIRST clause whose head argument
% is the same as the argument found in the input predicate,
% thus the removed clause q(D):-(...) has the same domain D
% as the input clause p(D):-(...). Note that "Predicate" and
% "RemovedHead" may be identical, thus "removeClause" should
% never fail (supposed that the arguments are properly used).
% I/O-Usage: (+,-,+,-). =====================================

removeClause(AnchorPredicate, RemovedGoals,
	     [(RemovedHead:-RemovedGoals)|RemainingClauses],
	     RemainingClauses) :-
	
      AnchorPredicate =.. [_,AnchorFunctor],
      
      RemovedHead =.. [_,HeadFunctor],

      functor(AnchorFunctor, SameName, SameArity),
      
      functor(HeadFunctor, SameName, SameArity),
      !.


removeClause(AnchorPredicate, RemovedGoals,
	     [SameClause|ScannedClauses],
	     [SameClause|RemainingClauses]) :-
	
      removeClause(AnchorPredicate, RemovedGoals,
		   ScannedClauses, RemainingClauses).


% (PUBLIC) ATTACHID: =======================================
% Takes an ordinary program representation and attaches each
% predicate call with a unique natural number identifier.
% I/O-Usage (+,+,-,-). =====================================
                                                             
attachID(ID, [], [], ID).                                    
                                                             
attachID(ID, [proc(X/1, Clauses)|ProcDefs],                  
	     [proc(X/1, NumClauses)|NumProcDefs], TopID) :-  
                                                             
	attachClausesID(ID, Clauses, NumClauses, OutID),     
                                                             
	NewID is OutID + 1,                                  
                                                             
	attachID(NewID, ProcDefs, NumProcDefs, TopID).

                                                             
/* case: only one clause */

attachClausesID(ID, [(P:-Goals)],                            
		    [([P,ID]:-NumGoals)], OutID) :-          
        !,                                                   
	NextID is ID + 1,                                    
				                             
        attachGoalsID(NextID, Goals, NumGoals, OutID).       
                                                             
                                                             
/* case: more than one clause */

attachClausesID(ID, [(P:-Goals)|Clauses],                    
		[([P,ID]:-NumGoals)|NumClauses], OutID) :-   
                                                             
        SuccID is ID + 1,                                    
                                                             
        attachGoalsID(SuccID, Goals, NumGoals, NextID),      
                                                             
	NewID is NextID + 1,                                 
                                                             
	attachClausesID(NewID, Clauses, NumClauses, OutID).  
                                                             
                                                             
/* case: multiple Goal */

attachGoalsID(ID, (Goal, MoreGoals),                         
	          ([Goal,ID], MoreNumGoals), OutID) :-       
	!,                                                   
	NextID is ID + 1,                                    
                                                             
	attachGoalsID(NextID, MoreGoals,                     
		      MoreNumGoals, OutID).                  
                                                             
/* case: single Goal */

attachGoalsID(ID, Goal, [Goal,ID], ID).


% (PUBLIC) DELETEID: =====================================
% Takes a numbered program and delete the identifiers from
% the predicates. (Inverse to "attachID" from above.) I/O-
% Usage (+,-). ===========================================
                                                           
deleteID([], []).                                          
                                                           
deleteID([proc(X/1, NumClauses)|NumProcDefs],               
	 [proc(X/1, Clauses)|ProcDefs]) :-                  
                                                            
	deleteClausesID(NumClauses, Clauses),               
                                                            
	deleteID(NumProcDefs, ProcDefs).                    


/* case: only one clause */

deleteClausesID([([P,_]:-NumGoals)], [(P:-Goals)]) :-       
        !,                                                  
        deleteGoalsID(NumGoals, Goals).                     
                                                            
                                                            
/* case: more than one clause */

deleteClausesID([([P,_]:-NumGoals)|NumClauses],             
		[(P:-Goals)|Clauses]) :-                    
                                                            
        deleteGoalsID(NumGoals, Goals),                     
                                                            
	deleteClausesID(NumClauses, Clauses).               
                                                            
                                                            
/* case: multiple Goal */

deleteGoalsID(([Goal,_], MoreNumGoals),                     
	      (Goal, MoreGoals)) :-                         
	!,                                                  
	deleteGoalsID(MoreNumGoals, MoreGoals).

                                                            
/* case: single Goal */

deleteGoalsID([Goal,_], Goal).


% (PUBLIC) COMBINEPAIRS: ===========================
% For the purpose of complete pairwise comparison of
% arbitrary list elements we take an inputlist L and
% compute its cross-product LxL as output. we do not
% need twins of the form (P,P) so we exclude them by
% construction for reasons of efficiency. The pairs
% in the output list are unique if (and only if) the
% input list represents a genuine set (and not a bag).
% ===================================================

combinePairs([_], []).                                 
                                                       
combinePairs([X|Names], OutputPairs) :-                
	                                               
	construction(X, Names, XPairs),
	
	combinePairs(Names, RestPairs), 
	                                               
	append(XPairs, RestPairs, OutputPairs).        
                                                       
                                                       
construction(Xa, [Xb], []) :-

	Xa == Xb,
	!.                              
                                                       
construction(X, [Y], [(X,Y), (Y,X)]) :-

	X \== Y,
	!.       
                                                       
construction(Xa, [Xb|Ys], Pairs) :-

	Xa == Xb,
	!,                                               
	construction(Xa, Ys, Pairs).                    
                                                       
construction(X, [Y|Ys], [(X,Y), (Y,X) |Pairs]) :-      
                                                       
	X \== Y,
	
	construction(X, Ys, Pairs).                    


% (PUBLIC) NEWNAME: ============================================
% Produces a new name for a new type to be generated. "name" and
% "append" are SICSTUS built-in predicates. The new name has the
% form 't<N>' where <N>	should be natural number. [116] is ASCII
% for 't'. <N> is intended to be the IndexNumber input such that
% newName(IndexNumber, t<IndexNumber>) is true. I/O-Usage (+,-).
% ==============================================================

newName(Index, NewName) :-
	
      name(Index, ASCII_Index),
      
      name(t, ASCII_t),
      
      append(ASCII_t, ASCII_Index, ASCII_NewName),
      
      name(NewName, ASCII_NewName).


% (PUBLIC) SAMESET: ==================================
% Strictly speaking it's not about sets here but about 
% multi sets (or bags), which is however irrelevant in 
% our case. "permutation" is a SICSTUS built-in, predi-
% cate (see manual). I/O-Use is check-only, thus (+,+).
% ====================================================

sameSet(ListA, ListB) :- permutation(ListA, ListB).                   


% (PUBLIC) DIFFERENCE: ================================
% ListC is computed by removing all those elements from
% ListB which also appear in ListA. ===================

difference([], SameList, SameList).

difference(_, [], []).

difference([A|ListA], ListB, ListC) :-

	delete(ListB, A, ResultB),

	difference(ListA, ResultB, ListC).


% CALLCHAIN: ====================================================
% callChain: See also Definition 3.5, page 601 in J.P. Gallagher
% and D.A.deWaal, "Fast and Precise Regular Approximations of Lo-
% gic Programs" Proc 11th Internat Conf on Logic Programming, MIT
% Press 1994. callChain expresses the transitive closure of the
% "calls" relation (see below). Note: For two predicates P and Q
% there may be more than one unique call chain. Call chains can  
% be of arbitrary length when procedures are (mutually) recursive.
% For this reason we break the rekursion as soon as an element re-
% occurs in the chain. Below you find the globalDepends-interface
% to callChain, according to Gallagher's definition. "non_member"
% is a SICSTUS built-in predicate. "callChain" is needed as well
% in this "auxil" module (see above) as in the "shorten" module.
% ===============================================================
                                                       
callChain(P, Q, [P,Q], RULprogram, _) :- calls(P, Q, RULprogram).
                                        
callChain(P, Q, [P,R|CallChain], RULprogram, VisitedPredNames) :-
                                                       
	calls(P, R, RULprogram),
	
	non_member(R, VisitedPredNames),               
                                                       
	callChain(R, Q, [R|CallChain],
		  RULprogram, [R|VisitedPredNames]).	       

/* PUBLIC */
globalDepends(P, Q, RULprogram) :-                     
                                                       
	callChain(P, Q, _, RULprogram, [P]).           

% CALLS: ==========================================================
% calls: See Definition 3.5, page 601 in J.P.Gallagher & D.A.deWaal,
% "Fast and Precise Regular Approximations of Logic Programs", Proc
% 11th Internat Conf on	Logic Programming, MIT Press 1994. We take
% two names of predicates and a program representation and check if
% the predicate are in the call relation wrt. the program represen-
% tation. All parameters are input (+,+,+), otherwise failure. The
% self-explaining auxilliary predicates to "calls" are given below.
% =================================================================
                                  
calls(P, Q, [proc(P/1, DefinitionP)|_]) :-             

	P \== Q, /* we're not interested in P == Q */
	
	inClauseHead(P, DefinitionP),
	
	inClauseBody(Q, DefinitionP).
                                       
calls(P, Q, [_|RULprogram]) :-

        P \== Q, /* we aren't interested in P == Q */
	
	calls(P, Q, RULprogram).
                                            
inClauseHead(P, [(Predicate:-_)]) :- Predicate =.. [P|_].
                                                       
inClauseHead(P, [(Predicate:-_)|Clauses]) :-           
                                                       
        Predicate =.. [P|_],
        
	inClauseHead(P, Clauses).

inClauseHead(P, [(Predicate:-_)|_]) :-                 
                                                       
        Predicate =.. [OtherName|_],
	
	P \== OtherName,
	
	nl,
	print('* SYNTAX ERROR IN PROGRAM REPRESENTATION *'),
	nl,
	
	fail.

inClauseBody(Q, [(_:-Predicates)|_]) :- checkBody(Q, Predicates). 
                                  
inClauseBody(Q, [_|Clauses]) :- inClauseBody(Q, Clauses).

checkBody(Q, (FirstGoal, _)) :-                        
                                                       
	FirstGoal =.. [Q|_],
	
	Q \== true.                                    

checkBody(Q, (_, NextGoals)) :- checkBody(Q, NextGoals).
                                                       
checkBody(Q, OnlyOnePred) :-                           
                                                       
	OnlyOnePred \=  (_,_),
	
	OnlyOnePred =.. [Q|_],
	
	Q \== true.                                    


% (PUBLIC) PROGSIZE: ========================================
% counts all head and tail predicates occuring in the clauses
% of the input program. Speaking "OO" this procedure has been
% "inherited" from procedure attachID (see above). ==========
                        
progSize(Num, [], Num).


progSize(InitNum, [iFact(_,_)|Definitions], TopNum) :-

	NewNum is InitNum + 2, /* ("1" :- "2") */

	progSize(NewNum, Definitions, TopNum).


progSize(InitNum, [proc(_/1, Clauses)|ProcDefs], TopNum) :-  
                                                             
	countClauses(InitNum, Clauses, OutNum),     
                                                             
	NewNum is OutNum + 1,                                  
                                                             
	progSize(NewNum, ProcDefs, TopNum).

/* weird case: undefined */
countClauses(Num, [], Num) :-
	nl,
	print('* Warning: Empty Proc-Definition Detected! *'),
	nl,
	!.

/* case: only one clause */

countClauses(Num, [(_:-Goals)], OutNum) :-          
        !,                                                   
	NextNum is Num + 1,                                    
				                             
        countGoals(NextNum, Goals, OutNum).


/* case: more than one clause */

countClauses(Num, [(_:-Goals)|Clauses], OutNum) :-   
                                                             
        SuccNum is Num + 1,                                    
                                                             
        countGoals(SuccNum, Goals, NextNum),      
                                                             
	NewNum is NextNum + 1,                                 
                                                             
	countClauses(NewNum, Clauses, OutNum).  


/* case: multiple Goal */                                    

countGoals(Num, (_, MoreGoals), OutNum) :-       
	!,                                                   
	NextNum is Num + 1,                                    
                                                             
	countGoals(NextNum, MoreGoals, OutNum).
                                                             

/* case: single Goal */                                      

countGoals(Num, _, Num).                    


% (PUBLIC) PREPARETRIPLE: =====================================
% prepareTriple supports nextUpperBound (see module upperBound)
% in the case that neither t1 nor t2 is syntactically the same
% as t in (t1,t2,t). In this case we must insert these names in
% a list of type name triples. To enforce certain lexicographic
% order we use SICSTUS built-in in "@=<" predicate (see manual).
% When this is done, we can insert the type name triple into the
% triple list. Moreover, prepareTriple supports also the inter-
% section procedure (see module interSection), thus "upperName"
% "UType" (etc.) can also be read as "intersectionName", "IType"
% (etc.). In case that prepareTriple is called with InputTriples
% un-instantiated, a new triple list is generated. =============

prepareTriple(TypeName1, TypeName2, UpperName,
	      Type1, Type2, UType, InputTriples,
	      ReferenceTriples, IndexInput, IndexOutput) :-
	
      TypeName1 @=< TypeName2,
      !,
      insertTriple(TypeName1, TypeName2, UpperName,
		   Type1, Type2, UType, InputTriples,
		   ReferenceTriples, IndexInput, IndexOutput).

prepareTriple(TypeName1, TypeName2, UpperName, Type1, Type2,
	      UType, InputTriples, ReferenceTriples, IndexInput,
	      IndexOutput) :-
	
      insertTriple(TypeName2, TypeName1, UpperName,
		   Type1, Type2, UType, InputTriples,
		   ReferenceTriples, IndexInput, IndexOutput).

% INSERTTRIPLE: ===============================================
% insertTriple supports the prepareTriple procedure. Takes the
% input type names and puts them into a triples. New type names
% for the created new type (upper type or intersection type) are
% provided by index incrementation. "var", "memberchk" are SICS-
% TUS built-in predicates. var(InputTriples) checks if the input
% triple list is still an uninstantiated variable (i.e. the list
% does not yet exist) in which case it has to be created from
% scratch (by unification, see "="). ==========================

insertTriple(TypeName1, TypeName2, UpperName, Type1, Type2,
	     UType, InputTriples, ReferenceTriples, IndexInput,
	     IndexOutput) :-
	
      inTripleList(TypeName1, TypeName2, UpperName,
		   [(Type1,Type2,UType)|InputTriples],
		   ReferenceTriples, IndexInput, IndexOutput).

inTripleList(TypeName1, TypeName2, UpperName, InputTripleList,
	     ReferenceTriples, IndexInput, IndexOutput) :-
	
      var(InputTripleList), /* List does not yet exist */
      !,
      newName(IndexInput, UpperName),
      
      IndexOutput is IndexInput + 1,
      
      InputTripleList = [(TypeName1,TypeName2,UpperName)|_],
      
      memberchk((TypeName1,TypeName2,UpperName),
		ReferenceTriples).

inTripleList(TypeName1, TypeName2, UpperName,
	     [(TypeName1,TypeName2,UpperName)|_],
	     _, SameIndex, SameIndex) :- !.

inTripleList(TypeName1, TypeName2, UpperName,
	     [_|InputTriples], ReferenceTriples,
	     IndexInput, IndexOutput) :-
	
      inTripleList(TypeName1, TypeName2, UpperName,
		   InputTriples, ReferenceTriples,
		   IndexInput, IndexOutput).

% (PUBLIC) COORDINATE VARIABLES ========================
% Constraints refer to Goals via Variable Names in RCDs.
% In Clauses, the Subgoals refer to the Clause Heads via
% Variable Names as well. With this procedure, those re-
% ferences are made explicit by attaching numerical co-
% ordinates. ===========================================

coordinateVariables(Goals, Constr, GoalsWithID, ConstrWithID) :-

	attachReferenceIDs(0, Goals, GoalsWithID),
	
	transferReferences(GoalsWithID, Constr, ConstrWithID).

transferReferences(_, [], []).

transferReferences(GoalsWithID, [C|Constr], [CID|IDconstr]) :-

	searchReference(GoalsWithID, C, CID),

	/* By construction, the identifiers in IDconstr */
	/* are unique iff the original constraints are  */
	/* in the required normal form.                 */

	transferReferences(GoalsWithID, Constr, IDconstr).

searchReference([GID|_], C, CID) :-

	C =.. [Name, Variable],

	CID =.. [Name, [OrdNum2,[OrdNum1,Variable]]],

	reference(GID, OrdNum2, OrdNum1, Variable),
	!.

searchReference([_|Goals], C, CID) :-
        !,
	searchReference(Goals, C, CID).

searchReference(_, C, _) :-
	nl,
	print('* REFERENCE ERROR: Constraint '),
	print(C),
	nl,
	print('* does not refer to any goal! '),
	nl,
	!,
	fail.

reference(GID, OrdNum2, OrdNum1, Variable) :-

	GID =.. [_|IDvarList],

	occurs(IDvarList, OrdNum2, OrdNum1, Variable).

occurs([[OrdNum2,[OrdNum1,Var]]|_],
       OrdNum2, OrdNum1, Variable) :-

	Var == Variable,
	!.

occurs([_|IDvars], OrdNum2, OrdNum1, Variable) :-

	occurs(IDvars, OrdNum2, OrdNum1, Variable).


attachReferenceIDs(Seed, Goals, Output) :-

	dimension1(Seed, Goals, Dim1),
	
	dimension2(Dim1, Output).

dimension1(_, [], []).

dimension1(Seed, [Atom|List], [[Number,Atom]|ListID]) :-

	Number is Seed + 1,

	dimension1(Number, List, ListID).

dimension2([], []).

dimension2([[Number,Atom]|List], [AtomID|ListID]) :-

	proceed(Number, Atom, AtomID),

	dimension2(List, ListID).

proceed(Number, Pred, PredID) :-

	Pred =.. [Name|VarList],

	propagate(Number, VarList, NumVars),

	dimension1(0, NumVars, VarsID),

	PredID =.. [Name|VarsID].

propagate(_, [], []).

propagate(ID, [Var|VarList], [[ID,Var]|VarListID]) :-

	propagate(ID, VarList, VarListID).

%##########################################################
%########################## END ###########################
%##########################################################
