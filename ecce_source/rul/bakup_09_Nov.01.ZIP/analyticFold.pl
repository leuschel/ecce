%##############################################################
%###### FOLDING ANALYSIS SUPPORTING THE GOAL-RULIFICATION #####
%##############################################################
%---(C)-Stefan-Gruner-University-of-Southampton-England-2001---

:- module(analyticFold, [goalFolding/4]).

/* MOTIVATION: In our old goalRULification procedure we had too
   many cases in which goal-internal subterm-relationsships had
   been lost in the RULification process. For example, take the
   goal g(f(X),f(X)) with constraint c(X). It has been trans-
   formed into g(Y,Z) with constraints s(Y),t(Z) which were de-
   fined as t(f(U)):-c(U) and s(f(V)):-c(V). Thus: we have only
   preserved the relation c(X), but in the RULified (or folded)
   goal g(Y,Z) itself we have lost the information that Y == Z.
   With this module, we now bring back some of the lost equiva-
   lence information! As g's old subterms f(X),f(X) have been
   the same, their generated type definitions t(f(U)):-c(U) and
   s(f(V)):-c(V) are equivalent and can therefore be compressed
   to r(f(W)):-c(W). Thus we may replace the new-generated con-
   straint s(Y) by r(Y) and t(Z) by r(Z), and this possibility
   is a safe indicator that Y and Z have been equivalent before
   the transformation. We can thus eventually transform g(Y,Z)
   with r(Y) and r(Z) into the final form g(A,A) with the con-
   straint r(A). This achieved by the procedure in this module.
   However, there is a PRINCIPLE source of un-precision in RUL-
   ification (goal folding) which we cannot overcome at all: it
   is the occurrance of identical variables in different terms.
   Example: g(X,f(X)). Because variables are the FixPoint of
   the folding procedure, we cannot replace them by variables
   as we would do it with the terms. Thus, in our example we
   will definitly produce g(X,Y) -- and without any other means
   of relational information than our RUL constraint definition
   (which is the basis of our calculus) we will certainly loose
   the old information that X is somehow within Y. The same is
   true for similar situations, for example g(f(X),h(f(X))) or
   g(f(X),h(X)). Nevertheless, better to have only one precision
   improvement than no one at all! :) From now on it is strongly
   recommended to use the goalFolding/4 procedure instead of the
   less sophisticated old goalRULification/4.
*/

:- use_module(library(terms)).

:- use_module(library(lists)).

:- use_module(self_check).

:- use_module(prePostCon, 'prePostCon.pl', [isGoals/1, isRCD/1]).

:- use_module(compressor, 'compressor.pl', [compress/2]).

:- use_module(proSiNo, 'proSiNo.pl', [goalRULification/4,
				  constraintProjection/3]).

%##############################################################
                                               % roughly tested

:- assert_pre(analyticFold:goalFolding(In1, In2, _, _),

	      (prePostCon:isGoals([In1]),
	       prePostCon:isRCD(In2))).

:- assert_post(analyticFold:goalFolding(_, _, Out1, Out2),

	       (prePostCon:isGoals([Out1]),
		prePostCon:isRCD(Out2))).

goalFolding(InputGoal, InputRCD, OutputGoal, OutputRCD) :-

	/* case: precision can be improved */

	findMultipleArgs(InputGoal, Multiples),
	!,
	goalRULification(InputGoal,  ResultGoal,
			 InputRCD, ResultRCD),

	shrink(ResultGoal, ResultRCD, NextRCD),

	identifyVariables(Multiples,
			  ResultGoal, OutputGoal),

	cutConstraints(NextRCD, OutputRCD).

goalFolding(InputGoal, InputRCD, OutputGoal, OutputRCD) :-

	/* case: precision cannot be improved */

	goalRULification(InputGoal,  OutputGoal,
			 InputRCD, ResultRCD),

	shrink(OutputGoal, ResultRCD, OutputRCD).

%------------------------------------------------------------

cutConstraints(rul__constraint__declaration(InpC, Prog),
	       rul__constraint__declaration(CutC, Prog)) :-

	remove_duplicates(InpC, CutC).

%------------------------------------------------------------

identifyVariables(Multiples, InputGoal, OutputGoal) :-

	InputGoal =.. [Pred|InputVars],

	length(InputVars, Length),

	unification(Length, Multiples,
		    InputVars, OutputVars),

	OutputGoal =.. [Pred|OutputVars].

%------------------------------------------------------------
                                             % roughly tested

unification(InputNumber, [RefList|MultiList],
	    InputVariables, OutputVariables) :-

	unify(InputNumber, RefList,
	      InputVariables, ResultVars),

	unification(InputNumber, MultiList,
		    ResultVars, OutputVariables).

unification(_, [], Vars, Vars).

%------------------------------------------------------------
                                             % roughly tested

unify(InputNumber, [Num1,Num2], InVars, OutVars) :-

	Nth is InputNumber - Num1,
	Mth is InputNumber - Num2,

	nth(Nth, InVars, U),
	nth(Mth, InVars, V),

	U = V,

	OutVars = InVars,
	!.

unify(InputNumber, [Num1,Num2|RefList], InVars, OutVars) :-

	Nth is InputNumber - Num1,
	Mth is InputNumber - Num2,

	nth(Nth, InVars, U),
	nth(Mth, InVars, V),

	U = V,
	!,
	unify(InputNumber, [Num2|RefList], InVars, OutVars).

%------------------------------------------------------------
% findMultipleArgs: Variables will not be taken into account,
% as they will not be replaced by procedure goalRULification.
%------------------------------------------------------------
                                             % roughly tested
findMultipleArgs(InputGoal,_) :-

	InputGoal =.. [_|Arguments],

	no_doubles(Arguments),
	!,
	fail.

findMultipleArgs(InputGoal, Multiples) :-

	InputGoal =.. [_|Arguments],
	
	attachPositions(Arguments, PosArg),

	discardVariables(PosArg, PosTerms),

	searchMultiples(PosTerms, Multiples).

%--------------------------------------------------------------

discardVariables([[V,_]|OldPosArgs], NewPosArgs) :-

	var(V),
	!,
	discardVariables(OldPosArgs, NewPosArgs).

discardVariables([[A,P]|OldPosArgs], [[A,P]|NewPosArgs]) :-

	discardVariables(OldPosArgs, NewPosArgs).

discardVariables([],[]).

%--------------------------------------------------------------

searchMultiples([[E,Pos]|Elements], MultiplePositions) :-

	sameElement(E, Elements, PositionsE),

	PositionsE \== [],
	!,
	removeTreatedPositions(PositionsE,
			       Elements,
			       RestList),

	searchMultiples(RestList, RestPositions),

	append([[Pos|PositionsE]],
	       RestPositions,
	       MultiplePositions).

searchMultiples([_|Elements], MultiPositions) :-

	searchMultiples(Elements, MultiPositions).

searchMultiples([],[]).

%--------------------------------------------------------------

removeTreatedPositions([Pos|Positions],
		       [[E,Pos]|Elements], Output) :-
	!,
	removeTreatedPositions(Positions,
			       Elements, Output).

removeTreatedPositions([], List, List) :- !.

removeTreatedPositions(Positions, [E|Elements], Output) :-

	append(Elements, [E], Permutation),

	removeTreatedPositions(Positions, Permutation, Output).

%--------------------------------------------------------------

sameElement(E, [[E,P]|Elements], [P|Positions]) :-
	!,
	sameElement(E, Elements, Positions).

sameElement(E, [_|Elements], Positions) :-

	sameElement(E, Elements, Positions).

sameElement(_,[],[]).

%--------------------------------------------------------------

attachPositions([],[]).

attachPositions([E|Elements], [[E,Pos]|PosElements]) :-

	length(Elements, Pos),

	attachPositions(Elements, PosElements).

%--------------------------------------------------------------

/* Bug Fix 17.10.2001: constraintProjection must not be applied!
   The reason is the following. shrink is called by goalFolding,
   and goalFolding is called by proSiNo:l_goalRULification/4.In
   that procedure, a whole list of goals is treated at once. As
   soon as we apply constraintProjection in the context of only
   one goal, we destroy the reference context for all the other
   goals, which leads to false or over-generalised results of
   l_goalRULification! Therefore, we do not call the projection
   here any more. We call it in l_goalRULification after anyway.
*/

shrink(InputGoal, InputRCD, OutputRCD) :-

	term_variables(InputGoal, ResultVars),

%	constraintProjection(ResultVars,  /* IN LARGER CONTEXT WRONG */
%			     InputRCD,    /* IN LARGER CONTEXT WRONG */
%			     ResultRCD),  /* IN LARGER CONTEXT WRONG */

	compress(InputRCD, OutputRCD).

%############################ END #############################
%##############################################################

