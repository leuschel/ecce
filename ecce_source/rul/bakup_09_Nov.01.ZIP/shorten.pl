%##############################################################
%##################### MODULE: SHORTENING #####################
%##############################################################
%---(C)-Stefan-Gruner-University-of-Southampton-England-2001---

:- module(shorten, [shorten/2, shortenToFixPoint/2,
		    allDependants/2, short/4]).

:- use_module(library(lists)).

:- use_module(self_check).

%:- ['debug2.pl']. /* Local: only in Stefan's Environment */

:- use_module(prePostCon, 'prePostCon.pl', [isRULprog/1]).

:- use_module(subType, 'subType.pl', [subType/3]).

:- use_module(upperBound, 'upperBound.pl', [upperBound/7]).

:- use_module(auxil, 'auxil.pl', [combinePairs/2, progSize/3,
	     difference/3, sameSet/2, attachID/4, deleteID/2,
             replaceAllOccurrences/4, globalDepends/3]).

%#######################################################

:- assert_pre(shorten:shorten(In,_),
	      prePostCon:isRULprog(In)).

:- assert_pre(shorten:shortenToFixPoint(In,_),
	      prePostCon:isRULprog(In)).

:- assert_post(shorten:shorten(_,Out),
	       prePostCon:isRULprog(Out)).

:- assert_post(shorten:shortenToFixPoint(_,Out),
	       prePostCon:isRULprog(Out)).

% (PUBLIC) SHORTEN: ====================================
% See Definition 3.7., page 602, in J.P. Gallagher and 
% D.A.deWaal, "Fast and Precise Regular Approximations 
% of Logic Programs" Proc. 11th Internat. Conf. on Logic  
% Programming, MIT Press 1994. It takes a RUL program as  
% input and outputs a shortened version of it. A program
% is shortened by eliminating certain call-dependencies.
% This is done by replacing certain predicates. (Shorte-
% ning is related to Widening as some predicates are re-
% placed by their upper bounds, which is a kind of Wide-
% ning.) For reasons of recursion (see shortenToFixPoint
% below) we maintain a history of predicate replacements.
% Note that shortening never changes clause heads, only
% clause tails. ========================================

shorten(InputProgram, OutputProgram) :-

	/* PRECONDITION */
	isRULprog(InputProgram),
                                                       
	allDependants(InputProgram, DPredPairs),

	!, /* mal: added cut */
	
	short(InputProgram, DPredPairs, OutputProgram, _).

/* PUBLIC */
short(RULprogram, [], RULprogram, []) :- !.

short(InputProgram, [(P,Q)|Pairs], OutputProgram,
      [ReplacementInfo|ReplacementHistory]) :-   
                                  
	determineCase(P, Q, InputProgram, Case),

	!, /* mal: added cut */

	user:debug_nl,
	user:debug_print(Case),
	user:debug_nl,
	                                       
	treatCase(Case, P, Q, InputProgram,
		  ResultProgram, ReplacementInfo),

	!, /* mal: added cut */
	
	short(ResultProgram, Pairs, OutputProgram,
	      ReplacementHistory).    


% DOMAINDEPENDENCE: ===================================
% domainDependence: See Definition 3.6 page 602 in J.P.
% Gallagher and D.A. deWaal, "Fast and Precise Regular 
% Approximations of Logic Programs" Proc 11th Internat 
% Conf on Logic Programming, MIT Press 1994. We take 2 
% predicates check if their names can be found in call 
% chain and check if they're defined over the same set 
% of function symbols. P and Q must be syntactically   
% different, otherwise the relation would be trivially 
% true.(The relation is called D in Gallagher's paper.)
% Please note that the input program must be in RUL!
% =====================================================

domainDependence(P, Q, RULprogram) :-                  
                                                       
	P \== Q,                                       
	                                               
	globalDepends(P, Q, RULprogram), /* imported */           
	                                               
	domain(P, RULprogram, DomainP),
	
	domain(Q, RULprogram, DomainQ),                
                                                       
	sameSet(DomainP, DomainQ).


domain(P, [proc(P/1, Definition)|_], Domain) :-        
	                                               
	analyseHeads(P, Definition, [], Domain).       
                                                       
domain(P, [_|ProgrRepr], Domain) :-	               
                                                       
	domain(P, ProgrRepr, Domain).                  

/* multi case: there are RUL clauses to be examined */

analyseHeads(any, [(_:-true)], _, []) :-

        /* exceptional case: any(X) */
        !.

analyseHeads(P, [(Pred:-_)|Definitions],               
	     Accumulator, Domain) :-                   
                                                       
        /* case: p(f(X1...Xn)) where f is a function */
	
	Pred =.. [P, Functor],
	
	Functor =..[FunctSymbol|_],                    
	!,                                             
	analyseHeads(P, Definitions,                   
		     [FunctSymbol|Accumulator], Domain).

                                                       
analyseHeads(P, [(Pred:-_)|Definitions],               
	     Accumulator, Domain) :-                   
                                                       
        /* case: p(c) where c is constant */
	
	Pred =.. [P, ConstSymbol],
	
	functor(ConstSymbol, ConstSymbol, 0),          
	!,                                             
	analyseHeads(P, Definitions,                   
		     [ConstSymbol|Accumulator], Domain).

                                                       
analyseHeads(P, [(P:-_)|Definitions],                  
	     Accumulator, Domain) :-                   

        /* case: p is a nullary proposition */
	
        functor(P, P, 0),                              
	!,                                             
	analyseHeads(P, Definitions,                   
		     Accumulator, Domain).             
                                                       
% exit case: nothing to examine

analyseHeads(_, [], AccuOutput, AccuOutput).           


% SUCCESSINCLUSION: ==================================
% successInclusion: See Definition 3.2 page 601 in J.P
% Gallagher and D.A.deWaal, "Fast and Precise Regular  
% Approximations of Logic Programs" Proc 11th Internat 
% Conf on Logic Programming, MIT Press 1994. We'll use 
% the "subType" predicate of above for expressing this
% relation. Thus successInclusion is only an interface
% which we use just for terminological reasons. Inten-
% ded I/O-Usage is check-only, thus (+,+,+). =========
  
successInclusion(UnaryPred1, UnaryPred2, RULprogram) :-

	 subType(UnaryPred1, UnaryPred2, RULprogram).   

                                              
% (PUBLIC) ALLDEPENDANTS: ============================
% allDependants: Preliminary to Def.3.7 on page 602 in 
% J.P. Gallagher and D.A.deWaal, "Fast and Precise Re- 
% gular	Approximations of Logic Programs", Proc 11th   
% Internat Conf on Logic Programming, MIT Press 1994.  
% We compute a complete list of pairs (P,Q) such that  
% domainDependence(P,Q,RULprogram) holds for each pair 
% in that list. We will use that list later to compute 
% the shortened version of the RUL program, which must 
% contain at least two definitions (otherwise failure).
% =====================================================

allDependants(RULprogram, OutputPairs) :-              
                                                       
	extractCandidatePairs(RULprogram,              
			      IntermediatePairs),      
                                                       
	filterDependPairs(IntermediatePairs,           
	                  RULprogram, OutputPairs).    
                                                       
                                                       
extractCandidatePairs(RULprogram, PairList) :-         
                                                       
	extractNames(RULprogram, NameList),
	
	combinePairs(NameList, PairList).              
                                                       
                                                       
extractNames([proc(P/1,_)], [P]).                      
                                                       
extractNames([proc(P/1,_)|ProcDefs], [P|Names]) :-     
                                                       
	extractNames(ProcDefs, Names).                 

                                                       
filterDependPairs([], _, []).                          
                                                       
filterDependPairs([(P,Q)|InputPairs], RULprogram,      
		  [(P,Q)|OutputPairs]) :-             
                                                      
	domainDependence(P, Q, RULprogram),            
	!,    /* This cut is essential! */             
	                                               
	filterDependPairs(InputPairs, RULprogram,      
			  OutputPairs).                
                                                       
filterDependPairs([_|InputPairs], RULprogram,          
		  OutputPairs) :-                      
                                                       
	filterDependPairs(InputPairs, RULprogram,      
			  OutputPairs).

% DETERMINECASE: =====================================
% determineCase checks which one of the three cases of
% Def.3.7 page 602 in Gallagher's above-mentioned 1994
% paper applies. Precondition for a proper application
% is that "domainDependence(P,Q,.)" holds true for the
% given program: otherwise case3 would be chosen with-
% out any proper justification! case X (nothing to do)
% must be checked BEFORE the application of the case 3
% procedure! Please note the logical relation between
% all these four cases. ==============================
 
determineCase(P, Q, RULprogram, case1) :-              
                                                       
	successInclusion(P, Q, RULprogram),
	successInclusion(Q, P, RULprogram),            
	!.                                             
                                                       
determineCase(P, Q, RULprogram, case2) :-              
                                               
	successInclusion(Q, P, RULprogram),
	/* order is crucial: first Q then P */ 
	!.

determineCase(_, _, _, case3).


% CASE1: ==============================================
% In the clause tails (goals) of the given program, we
% have to replace all predicate names Q by name P such
% that each Q(X) becomes P(X). The treated program must
% be in RUL. I/O-Usage (+,+,+,+,-). The term (Q,P) is
% for the recorded replacement history (see below).
% =====================================================

treatCase(case1, P, Q,                                 
	  [proc(Name/1, InputProcDef)|InputProgram],
	  [proc(Name/1, ResultProcDef)|ResultProgram],
	  (Q,P)) :-

	replaceAllOccurrences(P, Q,                    
			      InputProcDef,            
			      ResultProcDef),
	
	treatCase(case1, P, Q,                         
		  InputProgram, ResultProgram, _).
                                                       
treatCase(case1, _, _, [], [], _).                        
      
% CASE2: ==================================================
% We have to identify certain occurrences of Q-goals, so we
% compute an intermediate program where each goal carries a
% unique identifier. Then we rename those Q-goals which are
% identified to be renamed by P. Finally, we delete all the
% identifiers as we don't need them any more. (Q,P) keeps
% information for the replacement history (see fix point).
% =========================================================
    
treatCase(case2, P, Q, InputProgram, ResultProgram, (Q,P)) :- 
                                                       
	attachID(0, InputProgram, IDprogram, _),

	/* first Q, then P, this is crucial here! */
	determinePlaces(Q, P, IDprogram, ListOfQIDs),
	                                               
	treat2(P, Q, ListOfQIDs, IDprogram, TreatedIDprogram),
	                                               
	deleteID(TreatedIDprogram, ResultProgram).       

% CASE3: ============================================
% We have to compute the upper bound of P and Q. Then
% we have to replace P by the computed upper bound in
% all clause tail occurrences (which is then the same
% situation as in case1). We feed the upperBound call
% with an input index obtained by the progSize call,
% such that we are sure that the computed upper bound
% name is unique and not in conflict with the already
% existing names in the input program. As a result of
% case 3, we also return the upper bound information.
% ===================================================
                                            
treatCase(case3, P, Q, InputProgram,
	  ResultProgram, (P,Q,UName)) :-
                                                    
	progSize(0, InputProgram, StartIndex),
                                                  
	upperBound(P, Q, UName, UDef,
		   InputProgram, StartIndex, _),
	
	treatCase(case1, UName, P, InputProgram,
		  PReplacedProgram, _),
	
	treatCase(case1, UName, Q, PReplacedProgram,
		  PQReplacedProg, _),
                                                 
	append(PQReplacedProg, UDef, ResultProgram).

% DETERMINEPLACES: ========================================
% We take a RUL program attached with unique predicate IDs
% and two predicate names X and Y which occur in the input
% program. We search an output list of XIDs such that: (i)
% each predicate name belonging to the output identifiers 
% is X. (ii) There exist clause head predicates with name 
% Y such that these Y-heads depend on at least one of the 
% X-Goals the IDs of which appear in the output list. (iii)
% No clause head predicate named X depends on at least one
% of the X-goals the IDs of which appear in the output list.
% Conditions (i),(ii),(iii) must all hold. Intended I/O-Use
% is (+,+,+,-), and the empty output list [] is returned in
% case that the search was not successful. As a consequence
% from the above specification, the output list must be the
% empty list for logical reasons if both X and Y represent
% the same predicate name. For reasons of efficiency, this
% case is made explicit below, but of course it would also
% turn out as a result of the ID-search. ==================

determinePlaces(SameName, SameName, _, []) :- !.

determinePlaces(PredNameX, PredNameY, IDprog, OutputXIDs) :-

	headList(PredNameX, IDprog, HeadXIDs),
	
	headList(PredNameY, IDprog, HeadYIDs),
        
	goalList(PredNameX, IDprog, GoalXIDs),             
                                                       
	filterPlaces(HeadXIDs, HeadYIDs, GoalXIDs,
		     OutputXIDs, IDprog). 


% HEADLIST: ===========================================
% I/O-Usage(+,+,-). Returns the identifiers of clause 
% heads with predicate name Pred in a numbered program.
% =====================================================
                                                       
headList(Pred, [proc(Pred/1, Defs)|_], Identifiers) :- 
	!,                                             
	readHeads(Defs, Identifiers).

                                                                      
headList(Pred, [_|NumProcs], Identifiers) :-           
        !,                                             
	headList(Pred, NumProcs, Identifiers).

                                               
headList(Pred, [], _) :-
	
	nl,                                 
	print('* ERROR: UNDEFINED PREDICATE '),               
	print(Pred),                                   
	print(' *'),
	fail.                                          


readHeads([([_,ID]:-_)|IdClauses], [ID|Identifiers]) :- 
        !,                                             
        readHeads(IdClauses, Identifiers).              
                                                       
readHeads([], []).                                      


% GOALLIST: =============================================
% goalList takes a predicate name and an identifiertagged
% RUL program. Returns a list of the identifiers of those
% predicates whose name is the same as the input name and
% which are goals (not heads) in the clauses of the input
% program. ==============================================

goalList(Pred, [proc(_/1, Defs)|Procs], IdList) :-    
                                                      
	readGoals(Pred, Defs, FirstIds),               
	                                               
	goalList(Pred, Procs, RestIds),                
                                                       
	append(FirstIds, RestIds, IdList).

                                                       
goalList(_, [], []).                                   
                                                       
                                                       
readGoals(Pred, [(_:-Goals)|Defs], OutputIds) :-        
                                                       
        analyse(Pred, Goals, FirstIds),                
	                                               
	readGoals(Pred, Defs, RestIds),                
                                                       
	append(FirstIds, RestIds, OutputIds).

                                                       
readGoals(_, [], []).                                   
                                                       

analyse(P, ([Pred,ID], MoreGoals), [ID|MoreIds]) :- 
                                                       
	Pred =.. [P,_],                                
	!,                                             
	analyse(P, MoreGoals, MoreIds).

                                                       
analyse(P, (_, MoreGoals), Ids) :-                     
	!,                                             
	analyse(P, MoreGoals, Ids).

                                                       
analyse(P, [Pred,ID], [ID]) :-  Pred =.. [P,_], !.

                                                       
analyse(_, _, []).


% FILTERPLACES: ======================================
% An input list of goal-IDs (from a numbered input RUL
% program) is filtered according to certain relations 
% with head-IDs in that program. I/O-Usage(+,+,+,-,+).
% Because "qDependsOn" and "pIndependentOf" logically 
% exclude each other on the same input, we can write  
% the first case of "filterPlaces" as an abbreviation.
% ====================================================
                                                  
filterPlaces(SameInput, SameInput, _, [], _) :- !.          
				
filterPlaces(_, _, [], [], _) :- !.

                                                       
filterPlaces(HeadPlacesP, HeadPlacesQ, [PID|GoalPlacesP],
	     [PID|OutputPlaceList], IDprog) :- 
                                                       
	qDependsOn(PID, HeadPlacesQ, IDprog),         
                                                       
	pIndependentOf(PID, HeadPlacesP, IDprog),     
	!,                                             
	filterPlaces(HeadPlacesP, HeadPlacesQ,         
		     GoalPlacesP, OutputPlaceList,
		     IDprog). 

filterPlaces(HeadPlacesP, HeadPlacesQ, [_|GoalPlacesP],
	     OutputPlaceList, IDprog) :-   
                                                       
	filterPlaces(HeadPlacesP, HeadPlacesQ,         
		     GoalPlacesP, OutputPlaceList,
		     IDprog).

                                        
% QDEPENDSON: ========================================
% A list of head identifiers represents all the clause
% heads of a predicate Q. A single identifier stands
% for the occurrence of one certain predicate P in a 
% certain clause body of the program. We check if the
% predicate Q (represented by the list of head identi-
% fiers) depends on that special occurrence of P which
% is the case when we can find a call chain from one
% of the Q-heads to that occurrence of P. TailPID is 
% the P-identifier. "QID" is any of the head-Q-identi- 
% fiers. Intended I/O-Usage: check-only, thus (+,+,+).
% ====================================================
                                                     
qDependsOn(TailPID, [QID|_], IDprog) :-               
                                                       
	callChainID([_,QID], [_,TailPID],              
		    _, IDprog, [QID]),                
	!.                                             


qDependsOn(TailPID, [_|MoreQIDs], IDprog) :-          
                                                       
	qDependsOn(TailPID, MoreQIDs, IDprog).        


qDependsOn(_, [], _) :- !, fail.                       


% PINDEPENDENTOF: ====================================
% The opposite of "qDependsOn". A list of identifiers
% represents some clause heads. One single identifier
% represents a special occurrence of some goal. If we
% can find a call chain from one of those heads to the
% identified goal, we have detected that the heads set
% is not independent of this goal which leads to fail.
% Intended I/O-Usage is (+,+,+) for check-only. ======

pIndependentOf(TailPID, [PID|_], IDprog) :-           
                                                      
	callChainID([_,PID], [_,TailPID],              
		    _, IDprog, [PID]),                
	!,                                             
	fail.

                                                       
pIndependentOf(TailPID, [_|MorePIDs], IDprog) :-      
                                                       
	pIndependentOf(TailPID, MorePIDs, IDprog).

                                                      
pIndependentOf(_, [], _) :- !.


% TREAT2: ===========================================
% supports case 2 of the above shortening definition.
% ===================================================
                                                     
treat2(P, Q, PlaceListQIDs,                          
       [proc(X/1, InputProcDef)|InputIDprogram],     
       [proc(X/1, InterProcDef)|InterIDprogram]) :-  
                                                       
	replaceSpecialOccurrences(P, Q, PlaceListQIDs,
			          InputProcDef,       
			          InterProcDef),
                     
	treat2(P, Q, PlaceListQIDs,                   
	       InputIDprogram, InterIDprogram).
                                                   
treat2(_, _, _, [], []).                          


replaceSpecialOccurrences(P, Q, PlaceListQIDs,         
			  [(Head:-GoalsQ)|InputDefs],  
			  [(Head:-GoalsP)|InterDefs]) :-
                                                       
         substitute(P, Q, PlaceListQIDs, GoalsQ, GoalsP),
               
	 replaceSpecialOccurrences(P, Q, PlaceListQIDs,
				   InputDefs, InterDefs).
                                                       
replaceSpecialOccurrences(_, _, _, [], []).            
                                                       

/* first double case: multiple goals */        
/* a) Q to be replaced by P here    */

substitute(P, Q, PlaceListQIDs,                         
	   ([PredQ,ID], MoreGoalsQ),               
	   ([PredP,ID], MoreGoalsP)) :-        
                                               
	memberchk(ID, PlaceListQIDs),
	
	PredP =.. [P, SameArgument],
	
	PredQ =.. [Q, SameArgument],
	!,                                        
	substitute(P, Q, PlaceListQIDs,           
		   MoreGoalsQ, MoreGoalsP).        
                                                   
/* b) nothing to replace here */

substitute(P, Q, PlaceListQIDs,                  
	   (SameGoal, MoreGoalsQ),
	   (SameGoal, MoreGoalsP)) :-       
        !,                                       
	substitute(P, Q, PlaceListQIDs,        
		   MoreGoalsQ, MoreGoalsP).     
                                                 
/* second double case: single goals */           
/* a) Q to be replaced by P here   */

substitute(P, Q, PlaceListQIDs, [PredQ,ID], [PredP,ID]) :-
                                                       
	memberchk(ID, PlaceListQIDs),
	
	PredP =.. [P, SameArgument],
	
	PredQ =.. [Q, SameArgument],
	!.                          
                               
/* b) nothing to replace */       
                                   
substitute(_, _, _, Goal, Goal).


% CALLCHAINID: =============================================
% callChainID is a variant of auxil:callChain. It works for
% programs with uniquely numbered predicates. BE SURE THAT
% YOU CALL THIS TRICKY PREDICATE WITH THE PROPER INPUT PARA-
% METERS !!! "non_member" is SICSTUS built-in. =============
                                                       
callChainID([P,IDP], [Q,IDQ], [IDP,IDQ], NumProg, _) :-	
                                                       
	callsID([P,IDP], [Q,IDQ], NumProg).	       
                                                       
                                                       
callChainID([P,IDP], [Q,IDQ],                          
	    [IDP,IDR,SomeID|IDchain],                   
	    NumProg, [IDP|VisitedIDs]) :-              
                                                       
	callsID([P,IDP], [R,IDR], NumProg),
	
	non_member(IDR, [IDP|VisitedIDs]),             
	                                               
	callsID([R,SomeID], _, NumProg),
	
	non_member(SomeID, [IDP|VisitedIDs]),           
	                                               
	callChainID([R,SomeID], [Q,IDQ],                
		    [SomeID|IDchain], NumProg,          
		    [IDP,IDR,SomeID|VisitedIDs]).       
                                                       
                                                       
callsID([P,PID], [Q,QID], [proc(P/1, DefinitionP)|_]) :-   
	                                               
	inClauseID([P,PID], [Q,QID], DefinitionP),
	
	PID < QID. /* redundant: just for security */  
                                                      
                                                       
callsID([P,PID], [Q,QID], [_|NumberedProgram]) :- 
	                                               
	callsID([P,PID], [Q,QID], NumberedProgram).    
                                                       
                                                       
inClauseID([P,PID], [Q,QID], [([Predicate,PID]:-Goals)|_]) :-
                                                       
        Predicate =.. [P|_],
	
        checkBodyID([Q,QID], Goals).                   
	                                               
                                                       
inClauseID([P,PID], [Q,QID], [_|NumClauses]) :-        
                                                       
	inClauseID([P,PID], [Q,QID], NumClauses).      
	                                               
                                                       
checkBodyID([Q,QID], ([FirstGoal,QID], _)) :-          
                                                       
	FirstGoal =.. [Q|_],
	
	Q \== true.                                    

checkBodyID([Q,QID], (_, NextGoals)) :-                
                                                       
	checkBodyID([Q,QID], NextGoals).               
                                                       
checkBodyID([Q,QID], [OnlyOnePredicate,QID]) :-        
                                                       
	OnlyOnePredicate =.. [Q|_],
	
	Q \== true.                                    


% (PUBLIC) SHORTENTOFIXPOINT =========================
% shortenToFixPoint: according to Definition 3.8, page
% 602 in J.P Gallagher & D.A.deWaal, "Fast and Precise
% Regular Approximations of Logic Programs", Proc 11th
% Internat Conf on Logic Programming, MIT Press 1994. 
% The Fixpoint is reached as soon as allDependants re-
% sults in empty list []. Until we have better theore-
% tical insight I use the following HEURISTICS to pre-
% vent possible nondetermination caused by shortening:
% Let D(t,s) hold and let r be an upper bound for t or
% s. After shortening we might now have D(t,r), and so
% on. For this reason, we keep track of the shortening
% history and we exclude all cases D(t,r) from the re-
% cursion where the insertion of r to the program is a
% result from a previous shortening step caused by the
% D(t,s) relation. ===================================

shortenToFixPoint(InputProgram, OutputProgram) :-

	/* PRECONDITION */
	isRULprog(InputProgram),
	
	user:debug_nl,
	user:debug_print('SHORTEN'),
	user:debug_nl,
	
	shortenLoop(loop, [], InputProgram, OutputProgram).

/* removed by mal: I don't see why this is necessary ?
  shortenLoop should never fail ?
  shortenToFixPoint(FixpointProgram, FixpointProgram). */


shortenLoop(loop, ForbiddenPairs, InputProgram, OutputProgram) :-
	
	user:debug_print('   LOOP:'),
	user:debug_nl,
	
%	user:debug_print('      Forbidden Pairs:    '),
%	user:debug_print(ForbiddenPairs),
%	user:debug_nl,

%	user:debug_print('Program to be shortened:'),
%	user:debug_nl,
%	user:debug_print(InputProgram),
%	user:debug_nl,
	
	allDependants(InputProgram, DPredPairs),

	user:debug_print('      Found Dependants:   '),
	user:debug_print(DPredPairs),
	user:debug_nl,

	difference(ForbiddenPairs, DPredPairs,
		   AllowedPairs),

	user:debug_print('      Treated Predicates: '),
	user:debug_print(AllowedPairs),
	user:debug_nl,
	
	exitTest(AllowedPairs, ExitDecision),
	                                             
	short(InputProgram, AllowedPairs,
	      IntermediateProgram, ReplacementHistory),
	 
	!, /* mal: added cut */

%	user:debug_print('One-Step-Shortened Program:'),
%	user:debug_nl,
%	user:debug_print(IntermediateProgram),
%	user:debug_nl,

%	user:debug_print('      ReplacementHistory: '),
%	user:debug_print(ReplacementHistory),
%	user:debug_nl,

	analyseHistory(ReplacementHistory, ResultList),

	append(ResultList, ForbiddenPairs, NewForbidden),
	 
	!, /* mal: added cut */

        shortenLoop(ExitDecision, NewForbidden,
		    IntermediateProgram, OutputProgram).

shortenLoop(exit, _, FixpointProgram, FixpointProgram) :-
	
	user:debug_print('EXIT LOOP'),
	user:debug_nl.

exitTest([], exit) :- !.

exitTest(Pairs, loop) :- Pairs \== [].


% ANALYSEHISTORY: ===================================
% We construct forbidden pairs from found upper type
% information stemming from previous shortening cases
% (see above). I/O-Usage is (+,-). ==================

analyseHistory([], []).

analyseHistory([(P,Q,U)|ReplacementHistory],
	       [(P,U),(Q,U)|ForbiddenPairs]) :-

	!,
	analyseHistory(ReplacementHistory, ForbiddenPairs).

analyseHistory([(P,U)|ReplacementHistory],
	       [(P,U)|ForbiddenPairs]) :-

	!,
	analyseHistory(ReplacementHistory, ForbiddenPairs).

analyseHistory([_|ReplacementHistory], ForbiddenPairs) :-

	analyseHistory(ReplacementHistory, ForbiddenPairs).

%##########################################################
%########################## END ###########################
%##########################################################

