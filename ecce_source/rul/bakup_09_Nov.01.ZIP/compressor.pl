%#################################################################
%####################### MODULE: COMPRESSION #####################
%#################################################################

:- module(compressor, [compress/2, fetchProcedure/3]).

:- use_module(library(lists)).
:- use_module(library(terms)).

%:-['debug2.pl']. /* Local: For Use only in Stefan's Environment */

:-use_module(prePostCon, 'prePostCon.pl', [isRCD/1, isNormal/1]).

:- use_module(gensym2, 'gensym2.pl', [seed/1]).

:- use_module(auxil, 'auxil.pl', [replaceAllOccurrences/4,
	                       pruneRCD/2, combinePairs/2,
			    listToGoal/2, orderSubGoals/2]).

:- use_module(self_check).

%#################################################################

%(PUBLIC) COMPRESS: ==============================================
% Removes redundant code from an RCD. Normal Form is required, and
% will be preserved. [Roughly tested.] ===========================

:- assert_pre(compressor:compress(In,_),
	      prePostCon:isRCD(In)).

:- assert_post(compressor:compress(_,Out),
	       prePostCon:isRCD(Out)).

compress(rul__constraint__declaration([], _),
	 rul__constraint__declaration([],[])) :- !.

compress(OldRCD, NewRCD) :-

	user:debug_print('COMPRESSION:'),
	user:debug_nl,
	
	pruneRCD(OldRCD, State1),

	order(State1, State2),

	compression(State2, NewRCD),
	!,
	user:debug_print('DONE.'),
	user:debug_nl.

compress(RCD, RCD) :-

	user:debug_nl,
	user:debug_print('>>> Compression Impossible <<<'),
	user:debug_nl.

%-----------------------------------------------------------------
                                                  % roughly tested

order(rul__constraint__declaration(C, ProgIn),
      rul__constraint__declaration(C, ProgOut)) :-

	orderSubGoals(ProgIn, ProgOut).

%-----------------------------------------------------------------
                                                  % roughly tested

compression(rul__constraint__declaration(OldC, OldP),
	    rul__constraint__declaration(NewC, NewP)) :-

	/* PRECONDITION */
	isNormal(OldC),

	redundanceAnalysis(OldP, RedundanceInfo),

	RedundanceInfo \== [], /* Loop Exit Condition! */

	constraintRewriting(OldC, RedundanceInfo, InterC),

	programRewriting(OldP, RedundanceInfo, InterP),
	!,
	compression(rul__constraint__declaration(InterC,
						 InterP),
		    rul__constraint__declaration(NewC,
						 NewP)).

compression(FixpointRCD, FixpointRCD) :- !.

%-----------------------------------------------------------------
                                               % thoroughly tested

programRewriting(InputProg, [(P,Q,rewriteBy(R))|Table], OutputProg) :-

	fetchProcedure(P, InputProg, Proc),

	transformProcedure(R, Proc, TransProc),

	deleteProcedure(P, InputProg, State1),

	deleteProcedure(Q, State1, State2),

	append(State2, [TransProc], State3),

	replaceInProgram(State3, R, P, State4),

	replaceInProgram(State4, R, Q, Result),
	!,
	programRewriting(Result, Table, OutputProg).

programRewriting(FixProg, [], FixProg).

%-----------------------------------------------------------------
                                                  % roughly tested

transformProcedure(T, proc(_/1, OldDef), proc(T/1, NewDef)) :-

	renameClauseHeads(T, OldDef, NewDef).

%-----------------------------------------------------------------
                                                  % roughly tested

renameClauseHeads(T, [(OldH:-G)|OldCl], [(NewH:-G)|NewCl]) :-

        OldH =.. [_, Functor],
	NewH =.. [T, Functor],
	!,
	renameClauseHeads(T, OldCl, NewCl).

renameClauseHeads(_,[],[]).

%-----------------------------------------------------------------
                                                  % roughly tested
% (PUBLIC)
fetchProcedure(P, [proc(P/1,Def)|_], Procedure) :-
	!,
	/* copy_term: with fresh variables */
	/* to avoid confusion             */
	copy_term(proc(P/1,Def), Procedure).

fetchProcedure(P, [_|Program], Proc) :-

	fetchProcedure(P, Program, Proc).

%-----------------------------------------------------------------
                                                  % roughly tested

deleteProcedure(P, [proc(P/1,_)|Procs], Procs) :- !.

deleteProcedure(P, [Proc|InProcs], [Proc|OutProcs]) :-

	deleteProcedure(P, InProcs, OutProcs).

deleteProcedure(_,[],[]).

%-----------------------------------------------------------------
                                                  % roughly tested
replaceInProgram(IllegalInput,_,_,_) :-

	var(IllegalInput),
	!,
	fail.

replaceInProgram([proc(N/1, OldDef)|OldProcs],
		 NewName,
		 OldName,
		 [proc(N/1, NewDef)|NewProcs]) :-

	replaceAllOccurrences(NewName,
			      OldName,
			      OldDef,
			      NewDef),
        !,
	replaceInProgram(OldProcs, NewName,
			 OldName, NewProcs).

replaceInProgram([],_,_,[]).

%-----------------------------------------------------------------
                                                  % roughly tested

constraintRewriting([OldC|OldConstr], Memory, [NewC|NewConstr]) :-

	OldC =.. [OldName, ThisVariable],
	
	lookUp(OldName, Memory, NewName),

	NewName \== notFound,
	
	NewC =.. [NewName, ThisVariable],
	!,
	constraintRewriting(OldConstr, Memory, NewConstr).

constraintRewriting([C|OldConstr], Memory, [C|NewConstr]) :-

	constraintRewriting(OldConstr, Memory, NewConstr).

constraintRewriting([],_,[]).
	
%-----------------------------------------------------------------
                                                  % roughly tested
lookUp(P, [(P,_,rewriteBy(Q))|_], Q) :- !.

lookUp(P, [(_,P,rewriteBy(Q))|_], Q) :- !.

lookUp(P, [_|RewritingTable], Q) :-

	lookUp(P, RewritingTable, Q).

lookUp(_, [], notFound).

%-----------------------------------------------------------------
                                                  % roughly tested
redundanceAnalysis(Program, OutputTriples) :-

	sameSizeDefinitions(Program, DefPairs),

	equivalentDefinitions(DefPairs, TypeTriples),

	eliminateDuplicates(TypeTriples, OutputTriples).

%-----------------------------------------------------------------

eliminateDuplicates([(P,Q,X)|Triples], [(P,Q,X)|Output]) :-

	discard((P,Q,_), Triples, Rest1),

	discard((Q,P,_), Rest1, Rest2),

	eliminateDuplicates(Rest2, Output).

eliminateDuplicates([],[]).

%-----------------------------------------------------------------

discard((P,Q,_), [(P,Q,_)|Triples], Rest) :-
	!,
	discard((P,Q,_), Triples, Rest).

discard((P,Q,_), [Tri|Triples], [Tri|Rest]) :-

	discard((P,Q,_), Triples, Rest).

discard(_,[],[]).

%-----------------------------------------------------------------
                                                  % roughly tested
sameSizeDefinitions(Program, SameSizeDefPairs) :-

	combinePairs(Program, DefPairs),

	filterSameSize(DefPairs, SameSizeDefPairs).

%-----------------------------------------------------------------
                                                  % roughly tested

filterSameSize([(proc(N/1, DefN),proc(T/1, DefT))|OldPairs],
	       [(proc(N/1, DefN),proc(T/1, DefT))|NewPairs]) :-

	same_length(DefN, DefT),
	!,
	filterSameSize(OldPairs, NewPairs).

filterSameSize([(_,_)|OldPairs], NewPairs) :-

	filterSameSize(OldPairs, NewPairs).

filterSameSize([],[]).

%----------------------------------------------------------------
                                                 % roughly tested

equivalentDefinitions([(proc(N/1,DefN), proc(T/1,DefT))|DefPairs],
		      [(N,T,rewriteBy(X))|EquivalenceInformation]) :-

	equivalentClauses(DefN, DefT),
	!,
	seed(SeedNr),
	
	name(SeedNr, CodeS),
	name(zip_, CodeC),
	
	append(CodeC, CodeS, CodeX),

	name(X, CodeX),
	
	equivalentDefinitions(DefPairs, EquivalenceInformation).

equivalentDefinitions([(_,_)|DefPairs], EquivalenceInformation) :-

	equivalentDefinitions(DefPairs, EquivalenceInformation).

equivalentDefinitions([],[]).

%--------------------------------------------------------------
                                               % roughly tested
equivalentClauses(DefN, DefT) :-

	sameDomain(DefN,DefT),

	sameRange(DefN, DefT).

%--------------------------------------------------------------
                                               % roughly tested
sameRange(Def, [(Head2:-Tail2)|Clauses2]) :-

        /* PRECONDITION: all clauses ordered */

        /* with backtracking */
        permutation(Def, [(Head1:-Tail1)|Clauses1]),

	Head1 =.. [_,Arg1],
	Head2 =.. [_,Arg2],
	copy_term(Arg1, D),
	copy_term(Arg2, D),
	copy_term(Tail1,T),
	copy_term(Tail2,T),
	!,
	sameRange(Clauses1, Clauses2).

sameRange([],[]).
	
%--------------------------------------------------------------

sameDomain(DefN, DefT) :-

	extractDomain(DefN, DN),
	extractDomain(DefT, DT),

	compareDomains(DN, DT).

%--------------------------------------------------------------
                                               % roughly tested
compareDomains(D1, D2) :-

       /* with backtracking */
	permutation(D1, Perm),
	copy_term(Perm, Copy),
	copy_term(D2,   Copy).

%--------------------------------------------------------------
                                               % roughly tested
extractDomain([(ANY:-_)|Clauses], Domain) :-

        ANY =.. [any,_],
	!,
	extractDomain(Clauses, Domain).

extractDomain([(Head:-_)|Clauses], [D|Domain]) :-

        Head =.. [_, D],
	!,
	extractDomain(Clauses, Domain).

extractDomain([],[]).

%###############################################################
%############################# END #############################
%###############################################################

%---Test-(passed!)--

con([p(X),q(Y)]).

program([proc(p/1, [(p(f(X)):-t(X)),
		    (p(g):-true)]),
	 proc(q/1, [(q(f(Y)):-s(Y)),
		    (q(g):-true)]),
	 proc(r/1, [(r(b):-true)]),
	 proc(s/1, [(s(a):-true)]),
	 proc(t/1, [(t(a):-true)])]).

