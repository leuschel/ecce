:- module(_,[airplane_ticket/8,
	     hotel_room/4,
	     activity/4],[]).
:- include('transactions').

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Travel Agency Database
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- data(airplane_ticket/8).
airplane_ticket(700,1,hawai,
	        datime(2004,10,15,11,0,0),
	        datime(2004,10,15,22,0,0),
		datime(2004,10,22,11,0,0),
	        datime(2004,10,22,14,0,0),1).

airplane_ticket(750,2,hawai,
	        datime(2004,10,20,23,0,0),
		datime(2004,10,20,08,0,0),
		datime(2005,10,26,11,0,0),
		datime(2004,10,26,14,0,0),39).

:- data(hotel_room/4).
% It is not possible to make a reservation (easier)
hotel_room(101,datime(2004,10,15,12,0,0),datime(2004,10,22,12,0,0),busy).
hotel_room(102,datime(2004,10,15,12,0,0),datime(2004,12,22,12,0,0),busy).
hotel_room(103,datime(2004,10,15,12,0,0),datime(2004,12,22,12,0,0),busy).
hotel_room(104,datime(2004,10,15,12,0,0),datime(2004,10,22,12,0,0),busy).
hotel_room(105,_,_,free).

:- data(activity/4).
% The activities are ofered through packets. That is, you only
% can choose a set of activities. They starts and finishes at 
% the same day.
activity(1,['visit downtown',
	    'go to the beach',
            'visit mall',
            'free time'], datime(2004,10,16,10,0,0,0), 1).
activity(2,['go to the beach',
            'hiking',
            'free time'], datime(2004,12,24,12,0,0,0), 19).

