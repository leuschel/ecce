:- module(_,[
	     buy_airplane_ticket/8,
	     rent_hotel/3,
	     choose_activities/4],[]).
:- use_module(library(system), [pause/1]).
:- use_module('test_db').
:- include('transactions').


%:- transactional(buy_airplane_ticket/8).
buy_airplane_ticket(Dest,P,SD1,SD2,ED1,ED2,Seats,Id):-
       airplane_ticket(P,Id,Dest,SD1,SD2,ED1,ED2,Seats),
       ( Seats > 0 ->
%         pause(5),
         retract_fact(airplane_ticket(P,Id,Dest,SD1,SD2,
                                    ED1,ED2,Seats)),
         NSeats is Seats - 1,
         asserta_fact(airplane_ticket(P,Id,Dest,SD1,SD2,
                                    ED1,ED2,NSeats))
       ;
         Id= -1
       ).
%:- transactional(rent_hotel/3).
rent_hotel(Start_Date,End_Date,Id_Room):-
     ( hotel_room(Id_Room,_,_,free) ->
%       pause(5),
       retract_fact(hotel_room(Id_Room,_,_,_)),
       asserta_fact(hotel_room(Id_Room,Start_Date,End_Date,busy))
     ;
       Id_Room = -1
     ).
%:- transactional(choose_activities/4).
choose_activities(Date,Start_Date,Free,Id):-
     activity(Id,A,Start_Date,Free),
     ( (Date @=< Start_Date, Free > 0) ->
%       pause(5),         
       retract_fact(activity(Id,A,Start_Date,Free)),
       NFree is Free - 1,
       asserta_fact(activity(Id,A,Start_Date,NFree))
     ;
       Id = -1
     ).
