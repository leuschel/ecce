%%transaction_test.pl
%%(c)2003 Nick D. Pattengale
%% nickp@cs.unm.edu

:- module(_,[],[]).
:- include('transactions').
:- use_module(library(system), [pause/1]).
:- use_module(library(concurrency), [eng_call/4,eng_wait/1,eng_release/1]).


%% The two goals to execute to see transactions
%% in action are demo_nontransactonal/0 and
%% demo_transactionaltxns/0

%% This file will load if it exists in the same directory
%% with all of the other files turned in with this project.

%% This demo pulls together the entire transaction
%% system.  The test will run two threads, one of which
%% will simulate a deposit into a bank account and
%% the other will simulate an interest calculation
%% program.  The test ensures a pause in the interest
%% calculation thread so that the update made by the
%% deposit thread is capable of being lost without
%% locking.


%If this module gets integrated into the ciao
%distribution, we will want to do the use_package...
%but that of course implies that this package exists
%in the ciao library...include for now

%:- use_package(transactions).

buy_trip:-

     buy_airplane_ticket(_,_,SD1,SD2,ED1,ED2,S,I_Flight), 
     display_string("Trip Data: \n"),
     display_string("Flight "), display_string("#"),
     display(I_Flight), display_string(" Details: \n"),
     display_string("Depart: "), display(SD1),
     display_string("\nArrive: "), display(SD2),
     display_string("Depart: "), display(ED1),
     display_string("\nArrive: "), display(ED2),
     display_string("\nSeat: "),display(S),
     rent_hotel(SD2,ED1,Id_Room),
     display_string("\nRoom: "), display(Id_Room),
     choose_activities(SD2,SDA,N,Id_Act),
     display_string("\nActivity #"),display(Id_Act),
     display_string("\nDate: "),display(SDA),
     display_string("\nNumber: "),display(N).
     
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% concurrent_calls([]).
% concurrent_calls([H|T]):-
%         eng_call(H,create,create,TH),
% 	pause(2),
% 	concurrent_calls(T),
% 	eng_wait(TH),
% 	eng_release(TH).

two_calls(Call1, Call2) :-
	eng_call(Call1, create, create, T1),
	pause(2),
	eng_call(Call2, create, create, T2),
	eng_wait(T1),
	eng_release(T1),
	eng_wait(T2),
	eng_release(T2).

% demo_nontransactional :-
% 	display_string("Concurrently buying a travel to Hawai that includes:"),
% 	nl,
% 	display_string(" airplane ticket, hotel and a set of activities"),
% 	nl,
        
% 	display_string("of: $"), balance(nick,X), display(X), nl,
% 	display_string("Resultant balance should be $"),
% 	X1 is X * 0.1 + X + 5000, display(X1),
% 	display_string(" or $"),
% 	X2 is ( (X + 5000) * 0.1) + X + 5000, display(X2),
% 	nl,
% 	display_string("Please Wait..."), nl,
% 	two_calls( dirty_calc_interest, dirty_deposit(nick, 5000) ),
% 	display_string("Done - Result is: $"), balance(nick,Y),
% 	display(Y), nl,
% 	display_string("Obviously transactions are necessary!"), nl.

