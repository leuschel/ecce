:- module(_,[
	     nonbuy_airplane_ticket/8,
	     nonrent_hotel/3,
	     nonchoose_activities/4],[]).
:- use_module('test_db').

nonbuy_airplane_ticket(Dest,P,SD1,SD2,ED1,ED2,Seats,Id):-
       airplane_ticket(P,Id,Dest,SD1,SD2,ED1,ED2,Seats),
       ( Seats > 0 ->
         retract_fact(airplane_ticket(P,Id,Dest,SD1,SD2,
                                    ED1,ED2,Seats)),
         NSeats is Seats - 1,
         asserta_fact(airplane_ticket(P,Id,Dest,SD1,SD2,
                                    ED1,ED2,NSeats))
       ;
         Id= -1
       ).
nonrent_hotel(Start_Date,End_Date,Id_Room):-
     ( hotel_room(Id_Room,_,_,free) ->
       retract_fact(hotel_room(Id_Room,_,_,_)),
       asserta_fact(hotel_room(Id_Room,Start_Date,End_Date,busy))
     ;
       Id_Room = -1
     ).
nonchoose_activities(Date,Start_Date,Free,Id):-
     activity(Id,A,Start_Date,Free),
     ( (Date @=< Start_Date, Free > 0) ->
       retract_fact(activity(Id,A,Start_Date,Free)),
       NFree is Free - 1,
       asserta_fact(activity(Id,A,Start_Date,NFree))
     ;
       Id = -1
     ).
