
:-module(aso_asociacion,[asociacion/19]).

asociacion('ESPC','AS','CIID','ESPC','EL','CIUD','ESPC','EL','CIID','11',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','CILU','ESPC','EL','CIUD','ESPC','EL','LUGA','0N',_,_,_,'ESPC','AS','LUCI',_,_,_).
asociacion('ESPC','AS','CINH','ESPC','EL','CIUD','ESPC','EL','CINH','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','CINO','ESPC','EL','CIUD','ESPC','EL','CINO','11',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','ESCO','ESPC','EL','ESPE','ESPC','EL','ESCO','11',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','ESEV','ESPC','EL','ESPE','ESPC','EL','EVEN','0N',_,_,_,'ESPC','AS','EVES',_,_,_).
asociacion('ESPC','AS','ESFL','ESPC','EL','ESPE','ESPC','EL','ESFL','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','ESNO','ESPC','EL','ESPE','ESPC','EL','ESNO','11',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','ESPE','ESPC','EL','ESPE','ESPC','EL','PERS','0N',_,_,_,'ESPC','AS','PEES',_,_,_).
asociacion('ESPC','AS','ESTE','ESPC','EL','ESPE','ESPC','EL','ESTE','11',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','EVDU','ESPC','EL','EVEN','ESPC','EL','EVDU','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','EVES','ESPC','EL','EVEN','ESPC','EL','ESPE','11',_,_,_,'ESPC','AS','ESEV','C',_,_).
asociacion('ESPC','AS','EVLU','ESPC','EL','EVEN','ESPC','EL','LUGA','11',_,_,_,'ESPC','AS','LUEV','C',_,_).
asociacion('ESPC','AS','EVPE','ESPC','EL','EVEN','ESPC','EL','PERS','0N',_,_,_,'ESPC','AS','PEEV',_,_,_).
asociacion('ESPC','AS','EVSE','ESPC','EL','EVEN','ESPC','EL','SESI','0N',_,_,_,'ESPC','AS','SEEV',_,_,_).
asociacion('ESPC','AS','LUCA','ESPC','EL','LUGA','ESPC','EL','LUCA','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','LUCI','ESPC','EL','LUGA','ESPC','EL','CIUD','11',_,_,_,'ESPC','AS','CILU',_,_,_).
asociacion('ESPC','AS','LUCO','ESPC','EL','LUGA','ESPC','EL','LUCO','11',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','LUCP','ESPC','EL','LUGA','ESPC','EL','LUCP','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','LUCT','ESPC','EL','LUGA','ESPC','EL','LUCT','11',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','LUEV','ESPC','EL','LUGA','ESPC','EL','EVEN','0N',_,_,_,'ESPC','AS','EVLU',_,_,_).
asociacion('ESPC','AS','LUFA','ESPC','EL','LUGA','ESPC','EL','LUFA','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','LUME','ESPC','EL','LUGA','ESPC','EL','LUME','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','LUNA','ESPC','EL','LUGA','ESPC','EL','LUNA','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','LUNC','ESPC','EL','LUGA','ESPC','EL','LUNC','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','LUNO','ESPC','EL','LUGA','ESPC','EL','LUNO','11',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','LUTF','ESPC','EL','LUGA','ESPC','EL','LUTF','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','PECO','ESPC','EL','PERS','ESPC','EL','PECO','11',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','PEES','ESPC','EL','PERS','ESPC','EL','ESPE','0N',_,_,_,'ESPC','AS','ESPE',_,_,_).
asociacion('ESPC','AS','PEEV','ESPC','EL','PERS','ESPC','EL','EVEN','0N',_,_,_,'ESPC','AS','EVPE',_,_,_).
asociacion('ESPC','AS','PEFF','ESPC','EL','PERS','ESPC','EL','PEFF','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','PEFN','ESPC','EL','PERS','ESPC','EL','PEFN','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','PENO','ESPC','EL','PERS','ESPC','EL','PENO','11',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','PEPO','ESPC','EL','PERS','ESPC','EL','PEPO','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','SEAL','ESPC','EL','SESI','ESPC','EL','SEAL','01',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','SEEV','ESPC','EL','SESI','ESPC','EL','EVEN','11',_,_,_,'ESPC','AS','EVSE','C',_,_).
asociacion('ESPC','AS','SEFS','ESPC','EL','SESI','ESPC','EL','SEFS','11',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','SEHO','ESPC','EL','SESI','ESPC','EL','SEHO','11',_,_,_,_,_,_,_,_,_).
asociacion('ESPC','AS','SEPR','ESPC','EL','SESI','ESPC','EL','SEPR','01',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','AUCO','TEA1','EL','AUTO','TEA1','EL','COAU','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','AUFF','TEA1','EL','AUTO','TEA1','EL','FFAL','01',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','AUFN','TEA1','EL','AUTO','TEA1','EL','FNAC','01',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','AUNO','TEA1','EL','AUTO','TEA1','EL','NOAU','01',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','AUOB','TEA1','EL','AUTO','TEA1','EL','OBRA','0N',_,_,_,'TEA1','AS','OBAU',_,_,_).
asociacion('TEA1','AS','CIID','TEA1','EL','CIUD','TEA1','EL','COCI','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','CINH','TEA1','EL','CIUD','TEA1','EL','NHAB','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','CINO','TEA1','EL','CIUD','TEA1','EL','NCIU','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','CITE','TEA1','EL','CIUD','TEA1','EL','TEAT','0N',_,_,_,'TEA1','AS','TECI',_,_,_).
asociacion('TEA1','AS','OBAU','TEA1','EL','OBRA','TEA1','EL','AUTO','11',_,_,_,'TEA1','AS','AUOB',_,_,_).
asociacion('TEA1','AS','OBED','TEA1','EL','OBRA','TEA1','EL','FPUB','01',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','OBEO','TEA1','EL','OBRA','TEA1','EL','ESOB','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','OBID','TEA1','EL','OBRA','TEA1','EL','COOB','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','OBTE','TEA1','EL','OBRA','TEA1','EL','TEAT','0N',_,_,_,'TEA1','AS','TEOB',_,_,_).
asociacion('TEA1','AS','OBTI','TEA1','EL','OBRA','TEA1','EL','NOOB','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','SEAL','TEA1','EL','SESI','TEA1','EL','ALIB','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','SEFS','TEA1','EL','SESI','TEA1','EL','FSES','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','SEHS','TEA1','EL','SESI','TEA1','EL','HSES','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','SEND','TEA1','EL','SESI','TEA1','EL','DURA','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','SEPR','TEA1','EL','SESI','TEA1','EL','PREC','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','SETE','TEA1','EL','SESI','TEA1','EL','TEAT','11',_,_,_,'TEA1','AS','TESE',_,_,_).
asociacion('TEA1','AS','TEAP','TEA1','EL','TEAT','TEA1','EL','FAPE','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','TEAS','TEA1','EL','TEAT','TEA1','EL','NASI','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','TECA','TEA1','EL','TEAT','TEA1','EL','CALL','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','TECI','TEA1','EL','TEAT','TEA1','EL','CIUD','11',_,_,_,'TEA1','AS','CITE',_,_,_).
asociacion('TEA1','AS','TEIT','TEA1','EL','TEAT','TEA1','EL','COTE','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','TENO','TEA1','EL','TEAT','TEA1','EL','NOMB','11',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','TENU','TEA1','EL','TEAT','TEA1','EL','NUCA','01',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','TEOB','TEA1','EL','TEAT','TEA1','EL','OBRA','01',_,_,_,'TEA1','AS','OBTE',_,_,_).
asociacion('TEA1','AS','TEPO','TEA1','EL','TEAT','TEA1','EL','COPO','01',_,_,_,_,_,_,_,_,_).
asociacion('TEA1','AS','TESE','TEA1','EL','TEAT','TEA1','EL','SESI','0N',_,_,_,'TEA1','AS','SETE',_,_,_).










