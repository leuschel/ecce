:-module(con_concepto,[concepto/9]).


concepto('BAS0','AC','0001','Imprimir','Imprimir',_,_,'ACCION_OBJETO',_).
concepto('BAS0','AC','0002','Dar','Verbo DAR, se usa mucho',_,_,'ACCION_OBJETO',_).
concepto('BAS0','AC','0003','Mostrar','Verbo MOSTRAR, se usa mucho',_,_,'ACCION_OBJETO',_).
concepto('BAS0','AC','0004','Listar','Peticion de listados',_,_,'ACCION_OBJETO',_).
concepto('BAS0','AC','0005','Contar','Puedes ser enumerar o decir, dependera del objeto',_,_,'ACCION_OBJETO',_).
concepto('BAS0','AC','0006','Sacar','Forma general de pedir algo',_,_,'ACCION_OBJETO',_).
concepto('BAS0','AC','0007','Decir','Forma general de pedir algo',_,_,'ACCION_OBJETO',_).
concepto('BAS0','AC','EXIT','Acabar','Se desea finalizar la ejecucion',_,_,'ACCION_OBJETO',_).
concepto('BAS0','AC','HELP','Ayuda','Una expresion ayuda',_,_,'ACCION_OBJETO',_).
concepto('BAS0','AC','SALU','Saludo completo','Una expresion de saludo completa',_,_,'ACCION_OBJETO',_).
concepto('BAS0','GE','GNBD','El propio sistema','Se refiere al sistema como concepto: HIC, GNBD,',_,_,'REDUCCION',_).
concepto('BAS0','GE','SIGN','Signo de puntuacion','Un signo de puntuacion, aparece en el valor inicial',_,_,'SIGNOS','SIGNO').
concepto('BAS0','GE','TXCO','El texto codigo','Maneras de decir codigo',_,_,'TEXTO_CNFH',_).
concepto('BAS0','GE','TXFX','El texto fecha','El texto fecha, esto es: fecha, dia,',_,_,'TEXTO_CNFH',_).
concepto('BAS0','GE','TXHO','El texto hora','Maneras de decir hora: hora [de comer],',_,_,'TEXTO_CNFH',_).
concepto('BAS0','GE','TXNU','El texto numero','Maneras de decir numero: numero, cantidad,',_,_,'TEXTO_CNFH',_).
concepto('BAS0','GE','USER','El usuario','Se refiere al usuario como concepto: yo,',_,_,'REDUCCION',_).
concepto('BAS0','GE','VAFX','Una fecha','Una fecha sin relacionar con nada',_,_,'FECHAS','FECHA').
concepto('BAS0','GE','VAHO','Una hora','Una hora sin relacionar con nada',_,_,'HORAS','HORA').
concepto('BAS0','GE','VAQU','Un texto en comillas','Un texto independiente entre comillas',_,_,'QUOTED','QUOTED').
concepto('BAS0','OB','LIST','Formas listado','Maneras de pedir un listado, relacion,',_,_,'ACCION_OBJETO',_).
concepto('BAS0','OB','TOTA','Formas total','Maneras de pedir un TOTAL',_,_,'ACCION_OBJETO',_).
concepto('BAS0','OR','ORDA','Orden ascendente','Indicacion de ordenamiento ascendente',_,_,'ORDEN',_).
concepto('BAS0','OR','ORDD','Orden descencente','Indicacion de ordenamiento descendente',_,_,'ORDEN',_).
concepto('BAS0','OR','ORDE','Orden','Indicacion de ordenamiento',_,_,'ORDEN',_).
concepto('BAS0','OR','ORTA','Ascendente textos','Orden alfabetico ascendente de campos textuales',_,_,'ORDEN',_).
concepto('BAS0','PE','FICH','Fichero','Referencia a fichero',_,_,'PERIFERICOS',_).
concepto('BAS0','PE','IMPR','Impresora','Referencia a la impresora',_,_,'PERIFERICOS',_).
concepto('BAS0','PE','PANT','Pantalla','Referencia a la pantalla',_,_,'PERIFERICOS',_).
concepto('BAS0','PE','VENT','Ventana','Referencia a una ventana de pantalla',_,_,'PERIFERICOS',_).
concepto('BAS0','RE','CORT','Aposicion cortesia','Aposicion cortesia',_,_,'REDUCCION',_).
concepto('BAS0','SX','0000','TOFU de sintaxis','Concepto ficticio para la gramatica de sintaxis',_,_,'SINTAXIS',_).
concepto('BAS0','SX','ARLI','Articulo libre','Articulo + [ Que , cual, ...]',_,_,_,_).
concepto('BAS0','SX','COMP','Comparativo','Parte inicial de un comparativo:mas, menos,',_,_,_,_).
concepto('BAS0','SX','CONJ','Conjunciones','Conjunciones o expresiones que funcionan como conjuncion',_,_,_,_).
concepto('BAS0','SX','CTFC','Cuantificadores','Cuantificadores',_,_,_,_).
concepto('BAS0','SX','DEMO','Demostrativo','Demostrativos o expresiones que funcionan como demostrativo',_,_,_,_).
concepto('BAS0','SX','DISY','Disyunciones','Disyunciones o expresiones que funcionan como disyuncion',_,_,_,_).
concepto('BAS0','SX','FUVA','Funcion de valor','Funcion que es seguro sobre valor',_,_,_,_).
concepto('BAS0','SX','FVCF','Func. valor o CTF','Funcion sobre valor o cuantificador',_,_,_,_).
concepto('BAS0','SX','NEGA','Negaciones','Negaciones o expresiones que funcionan como negacion',_,_,_,_).
concepto('BAS0','SX','POSE','Posesivos','Posesivos',_,_,_,_).
concepto('BAS0','SX','PRIN','Pron interrogativo','Pronombres interrogativos',_,_,_,_).
concepto('BAS0','SX','PRIR','Interrogt/relativo','Pronombre interrogativo o relativo',_,_,_,_).
concepto('BAS0','SX','PRPO','Preposiciones','Preposiciones',_,_,_,_).
concepto('BAS0','SX','PRRE','Pronombre relativo','Pronombres relativos',_,_,_,_).
concepto('BAS0','SX','VAUX','Verbos auxiliar','Aparece en valor inicial: ser, estra, haber, tener, have, be',_,_,_,_).
concepto('BAS0','VG','CIUD','Unas 1500 ciudades','Tabla con unas 1500 ciudades detodo el mundo',_,_,'ELEM_ATRIB_VALOR',_).
concepto('BAS0','VG','NOPE','12000 nombre persona','Unos 12000 nombres de persona de todo el mundo',_,_,'ELEM_ATRIB_VALOR',_).
concepto('BAS0','VG','PAIS','Unos 300 paises','Unos 300 nombres de pais',_,_,'ELEM_ATRIB_VALOR',_).
concepto('CINE','EL','0003','Pelicula','Concepto generico pelicula',_,_,'ELEM_ATRIB_VALOR',_).
concepto('CINE','VA','0001','Peliculas de CINE','Nombres de pelicula se basara en una tabla de peliculas',_,_,'ELEM_ATRIB_VALOR',_).
concepto('CINE','VA','0002','Actores de cine','Diferentes actores y actrices. Sera un termino generico',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','AS','CIID','-> Id ciudad','-> Id ciudad',_,_,'ASOCIACION',_).
concepto('ESPC','AS','CILU','Ciudad -> Lugar','Ciudad -> Lugar',_,_,'ASOCIACION',_).
concepto('ESPC','AS','CINH','-> Nu habitantes','-> Nu habitantes',_,_,'ASOCIACION',_).
concepto('ESPC','AS','CINO','-> Nombre ciudad','-> Nombre ciudad',_,_,'ASOCIACION',_).
concepto('ESPC','AS','ESCO','-> Cod. espectaculo','-> Cod. espectaculo',_,_,'ASOCIACION',_).
concepto('ESPC','AS','ESEV','Espect -> Evento','Espect -> Evento',_,_,'ASOCIACION',_).
concepto('ESPC','AS','ESFL','-> Fx edicion','-> Fx edicion',_,_,'ASOCIACION',_).
concepto('ESPC','AS','ESNO','-> Nomb espectaculo','-> Nombre espectaculo',_,_,'ASOCIACION',_).
concepto('ESPC','AS','ESPE','Especta. -> Persona','Espectaculo -> Persona',_,_,'ASOCIACION',_).
concepto('ESPC','AS','ESTE','-> Tipo espectaculo','-> Tipo espectaculo',_,_,'ASOCIACION',_).
concepto('ESPC','AS','EVDU','-> Duracion','-> Duracion',_,_,'ASOCIACION',_).
concepto('ESPC','AS','EVES','Evento -> Espect','Evento -> Espect',_,_,'ASOCIACION',_).
concepto('ESPC','AS','EVLU','Evento -> Lugar','Evento -> Lugar',_,_,'ASOCIACION',_).
concepto('ESPC','AS','EVPE','Evento -> Persona','Evento -> Persona',_,_,'ASOCIACION',_).
concepto('ESPC','AS','EVSE','Evento -> Sesion','Evento -> Sesion',_,_,'ASOCIACION',_).
concepto('ESPC','AS','LUCA','-> Calle lugar','-> calle lugar',_,_,'ASOCIACION',_).
concepto('ESPC','AS','LUCI','Lugar -> Ciudad','Lugar -> ciudad',_,_,'ASOCIACION',_).
concepto('ESPC','AS','LUCO','-> Cod lugar','-> cod lugar',_,_,'ASOCIACION',_).
concepto('ESPC','AS','LUCP','-> Codigo postal','-> codigo postal',_,_,'ASOCIACION',_).
concepto('ESPC','AS','LUCT','-> Tipo lugar','-> tipo lugar',_,_,'ASOCIACION',_).
concepto('ESPC','AS','LUEV','Lugar -> Evento','Lugar -> Evento',_,_,'ASOCIACION',_).
concepto('ESPC','AS','LUFA','-> Fx apertura','-> fx apertura',_,_,'ASOCIACION',_).
concepto('ESPC','AS','LUME','-> Metro','-> Metro',_,_,'ASOCIACION',_).
concepto('ESPC','AS','LUNA','-> Nu asientos','-> nu asientos',_,_,'ASOCIACION',_).
concepto('ESPC','AS','LUNC','-> Nu calle lugar','-> nu  calle lugar',_,_,'ASOCIACION',_).
concepto('ESPC','AS','LUNO','-> Nombre lugar','-> nombre lugar',_,_,'ASOCIACION',_).
concepto('ESPC','AS','LUTF','-> Telf lugar','-> Telf lugar',_,_,'ASOCIACION',_).
concepto('ESPC','AS','PECO','-> Cod persona','-> Cod persona',_,_,'ASOCIACION',_).
concepto('ESPC','AS','PEES','Persona -> Espectac','Persona -> Espectaculo',_,_,'ASOCIACION',_).
concepto('ESPC','AS','PEEV','Persona -> Evento','Persona -> Evento',_,_,'ASOCIACION',_).
concepto('ESPC','AS','PEFF','-> Fx fallecimiento','-> Fx fallecimiento',_,_,'ASOCIACION',_).
concepto('ESPC','AS','PEFN','-> Fx nacimiento','-> Fx nacimiento',_,_,'ASOCIACION',_).
concepto('ESPC','AS','PENO','-> Nombre persona','-> Nombre persona',_,_,'ASOCIACION',_).
concepto('ESPC','AS','PEPO','-> Pais origen','-> Pais origen',_,_,'ASOCIACION',_).
concepto('ESPC','AS','SEAL','-> Asientos libres','-> asientos libres',_,_,'ASOCIACION',_).
concepto('ESPC','AS','SEEV','Sesion -> Evento','Sesion -> Evento',_,_,'ASOCIACION',_).
concepto('ESPC','AS','SEFS','-> Fx sesion','-> fx sesion',_,_,'ASOCIACION',_).
concepto('ESPC','AS','SEHO','-> Hora sesion','-> Hora sesion',_,_,'ASOCIACION',_).
concepto('ESPC','AS','SEPR','-> Precio','-> precio',_,_,'ASOCIACION',_).
concepto('ESPC','EL','CIID','Identificador ciudad','Identificador ciudad',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','CINH','Numero de habitantes','Numero de habitantes',_,'CANTIDAD','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','CINO','Nombre ciudad','Nombre ciudad',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','CIUD','Ciudad','Ciudad',_,'ESPACIO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','ESCO','Cod. espectaculo','Codigo del espectaculo',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','ESFL','Fecha lanzamiento','Fecha lanzamiento',_,'TIEMPO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','ESNO','Nombre espectaculo','Nombre del espectaculo',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','ESPE','Espectaculo','Espectaculo',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','ESTE','Tipo espectaculo','Tipo espectaculo',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','EVDU','Duracion','Duracion',_,'UNIDAD','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','EVEN','Evento','Evento',_,'ACTO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','LUCA','Calle lugar','Calle lugar',_,'ESPACIO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','LUCO','Codigo lugar','Codigo lugar',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','LUCP','Codigo postal','Codigo postal',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','LUCT','Cod. tipo lugar','Cod. tipo lugar',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','LUFA','Fecha apertura','Fecha apertura',_,'TIEMPO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','LUGA','Lugar','Lugar',_,'ESPACIO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','LUME','Metro','Metro',_,'ESPACIO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','LUNA','Numero de asientos','Numero de asientos',_,'CANTIDAD','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','LUNC','Numero calle','Numero calle',_,'ESPACIO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','LUNO','Nombre del lugar','Nombre del lugar',_,'ESPACIO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','LUTF','Telefono lugar','Telefono Lugar',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','PECO','Cod. persona','Cod. persona',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','PEFF','Fx fallecimiento per','Fx fallecimiento persona',_,'TIEMPO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','PEFN','Fx nacimiento perso','Fx nacimiento persona',_,'TIEMPO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','PENO','Nombre persona','Nombre persona',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','PEPO','Pais origen persona','Pais origen persona',_,'LUGAR','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','PERS','Persona','Persona',_,'PERSONA','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','SEAL','Num asientos libres','Numero de asientos libres',_,'CANTIDAD','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','SEFS','Fecha sesion','Fecha sesion',_,'TIEMPO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','SEHO','Hora sesion','Hora sesion',_,'TIEMPO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','SEPR','Precio','Precio',_,'UNIDAD','ELEM_ATRIB_VALOR',_).
concepto('ESPC','EL','SESI','Sesion','Sesion',_,'ACTO','ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','CIIN','Identif. num ciudad','Identificador numerico de ciudad',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','CIIQ','Identif. alfa ciudad','Identificador alfanumerico de ciudad',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','CIN1','CIU 1: MADRID','CIUDAD 1: MADRID',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','CIN2','CIU 2: EDIMBURGO','CIUDAD 2: EDIMBURGO',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','CIN3','CIU 3: COPENHAGEN','CIUDAD 3: COPENHAGEN',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','CIN4','CIU 4: STRUER','CIUDAD 4: STRUER',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','CINH','Numero habitantes','Numero habitantes',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','CINO','Hereda VG ciudad','Hereda el nombre de ciudad de un valor general',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','CINQ','Nom ciudad quoted','Nom ciudad quoted',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','ES10','Conc 1: ACDC','Conccierto 1: ACDC',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','ESCN','Cod. espectac. Num','Codigo espectaculo Numerico',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','ESCQ','Cod. espectac. Quo','Codigo espectaculo Quoted',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','ESFP','Fx. lanzamiento','Fecha lanzamiento espectaculo',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','ESN1','OBRA 1: MARIA SABINA','OBRA 1: MARIA SABINA',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','ESN2','OBRA 2: HOMENAJE','OBRA 2: HOMENAJE AL BOSCO',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','ESN3','OBRA 3: HAMLET','OBRA 3: HAMLET',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','ESN4','OBRA 4: KING LEAR','OBRA 4: KING LEAR',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','ESNQ','Nom. espectaculo','Nombre espetaculo QUOTED',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','EST2','Tipo espectac. QUO','Tipo espectaculo QUOTED',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','EST3','Tipo espectac. Num','Tipo espectaculo numerico',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','ESTE','Tipo espectac. TG','Tipo espectaculo(Tabla)',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','EVDU','Durac. en minutos','Numero de minutos que dura un evento',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUC1','Codigo alfa Lugar','Codigo alfanumerico Lugar es un quoted',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUC2','Codigo alfa Lugar','Codigo numerico Lugar es un numerico',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUCQ','Nombre calle QUOTED','Nombre de calle QUOTED',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUFA','Fecha apertura','Fecha apertura',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUFN','Telefono numero','Telefono como numero',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUFQ','Telefono codigo','Telefono como codigo',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUMQ','Codigo alfa Lugar','Codigo alfanumerico Metro es un quoted',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUMT','Tabla metros','Tabla de terminos genericos de metro',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUN1','NO LUGAR 1: GARAGE','NO TEATRO 1: THE GARAGE THEATRE',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUN2','NO LUGAR 2: TRAVERS','NO TETARO 2: TRAVERSE THEATRE',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUNA','Numero asientos','Numero asientos',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUNC','Numero calle','Numero calle',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUNQ','Nombre lugar QUOTED','Nombre del lugar QUOTED',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUP1','Codigo postal numer','Codigo postal numerico',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUP2','Codigo postal Quote','Codigo postal Quoted',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUTN','Tipo lugar numerico','Tipo lugar numerico',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUTQ','Tipo lugar quoted','Tipo lugar quoted',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','LUTT','Tipo lugar tabla','Tipo lugar tabla de terminos genericos',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','PECN','Cod numerico persona','Codigo numerico persona',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','PECQ','Cod alfa persona','Codigo alfanumerico persona',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','PEFF','Fx falle. persona','Fecha fallecimiento persona',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','PEFN','Fx nacim. persona','Fecha nacimiento persona',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','PEN1','Persona 1: CELA','Persona 1: CELA',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','PEN2','PerS 2: SHAKESPEARE','Persona 2: SHAKESPEARE',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','PEN3','Persona 3: ANDERSEN','Persona 3: ANDERSEN',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','PENO','Hereda VG nombres','Hereda VG nombres de persona',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','PENQ','Persona quoted','Persona quoted',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','PEPO','Pais origen T.G.','Termino generico de pais',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','PEPQ','Pais origen quoted','Pais origen quoted',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','SEAL','Num asientos libres','Numero (ASIENTOS LIBRES)',_,'CANTIDAD','ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','SEFS','Fx sesion','Fecha sesion',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','SEHN','Hora sesion (num)','Hora sesion en formato numero',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','SEHO','Hora sesion (hor)','Hora sesion en formato hora',_,_,'ELEM_ATRIB_VALOR',_).
concepto('ESPC','VA','SEPR','Numero precio','Numero precio',_,_,'ELEM_ATRIB_VALOR',_).
concepto('RECE','EL','0002','Receta','Receta como plato a preparar en contextos gastronomicos',_,_,'ELEM_ATRIB_VALOR',_).
concepto('RECE','EL','0003','Valor energetico','Representa el aporte energetico',_,_,'ELEM_ATRIB_VALOR',_).
concepto('RECE','VA','0001','Diferentes recetas','Recetas posibles obtenidas de fuentes externas','Posible conjunto de recetas, tabla de terminos genericos',_,'ELEM_ATRIB_VALOR',_).
concepto('RELI','EL','0001','Un libro de cocina','Un libro de cocina',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','AS','AUCO','-> cod autor','-> cod autor',_,_,'ASOCIACION',_).
concepto('TEA1','AS','AUFF','-> fx fallecimiento','-> fx fallecimiento',_,_,'ASOCIACION',_).
concepto('TEA1','AS','AUFN','-> fx nacimiento','-> fx nacimiento',_,_,'ASOCIACION',_).
concepto('TEA1','AS','AUNO','-> nombre','-> nombre',_,_,'ASOCIACION',_).
concepto('TEA1','AS','AUOB','Autor -> Obra','Autor -> Obra',_,_,'ASOCIACION',_).
concepto('TEA1','AS','CIID','-> id ciudad','-> id ciudad',_,_,'ASOCIACION',_).
concepto('TEA1','AS','CINH','-> nu habitantes','-> nu habitantes',_,_,'ASOCIACION',_).
concepto('TEA1','AS','CINO','-> nombre ciudad','-> nombre ciudad',_,_,'ASOCIACION',_).
concepto('TEA1','AS','CITE','Ciudad -> Teatro','Ciudad -> Teatro',_,_,'ASOCIACION',_).
concepto('TEA1','AS','OBAU','Obra -> Autor','Obra -> Autor',_,_,'ASOCIACION',_).
concepto('TEA1','AS','OBED','-> fx edicion','-> fx edicion',_,_,'ASOCIACION',_).
concepto('TEA1','AS','OBEO','-> estilo obra','-> estilo obra',_,_,'ASOCIACION',_).
concepto('TEA1','AS','OBID','-> id obra','-> id obra',_,_,'ASOCIACION',_).
concepto('TEA1','AS','OBTE','Obra -> Teatro','Obra -> Teatro',_,_,'ASOCIACION',_).
concepto('TEA1','AS','OBTI','-> titulo obra','-> titulo obra',_,_,'ASOCIACION',_).
concepto('TEA1','AS','SEAL','-> asientos libres','-> asientos libres',_,_,'ASOCIACION',_).
concepto('TEA1','AS','SEFS','-> fx sesion','-> fx sesion',_,_,'ASOCIACION',_).
concepto('TEA1','AS','SEHS','-> Hora sesion','-> Hora sesion',_,_,'ASOCIACION',_).
concepto('TEA1','AS','SEND','-> duracion','-> duracion',_,_,'ASOCIACION',_).
concepto('TEA1','AS','SEPR','-> precio','-> precio',_,_,'ASOCIACION',_).
concepto('TEA1','AS','SETE','Sesion -> Teatro','Sesion -> Teatro',_,_,'ASOCIACION',_).
concepto('TEA1','AS','TEAP','-> fx apertura','-> fx apertura',_,_,'ASOCIACION',_).
concepto('TEA1','AS','TEAS','-> nu asientos','-> nu asientos',_,_,'ASOCIACION',_).
concepto('TEA1','AS','TECA','-> calle','-> calle',_,_,'ASOCIACION',_).
concepto('TEA1','AS','TECI','Teatro -> ciudad','Tatro -> ciudad',_,_,'ASOCIACION',_).
concepto('TEA1','AS','TEIT','-> id teatro','-> id teatro',_,_,'ASOCIACION',_).
concepto('TEA1','AS','TENO','-> nombre teatro','-> nombre teatro',_,_,'ASOCIACION',_).
concepto('TEA1','AS','TENU','-> nu calle teatro','-> nu  calle teatro',_,_,'ASOCIACION',_).
concepto('TEA1','AS','TEOB','Teatro -> Obra','Teatro -> Obra',_,_,'ASOCIACION',_).
concepto('TEA1','AS','TEPO','-> codigo postal','-> codigo postal',_,_,'ASOCIACION',_).
concepto('TEA1','AS','TESE','Teatro -> Sesion','Teatro -> Sesion',_,_,'ASOCIACION',_).
concepto('TEA1','EL','ALIB','Num asientos libres','Numero de asientos libres',_,'CANTIDAD','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','AUTO','Autor','Autor',_,'PERSONA','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','CALL','Calle','Calle',_,'ESPACIO','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','CIUD','Ciudad','Ciudad',_,'ESPACIO','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','COAU','Codigo autor','Codigo autor',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','COCI','Codigo ciudad','Codigo ciudad',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','COOB','Codigo de la obra','Codigo de la obra',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','COPO','Codigo postal','Codigo postal',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','COTE','Codigo teatro','Codigo teatro',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','DURA','Duracion sesion','Duracion sesion',_,'TIEMPO','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','ESOB','Estilo obra','Estilo obra',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','FAPE','Fecha apertura','Fecha apertura',_,'TIEMPO','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','FFAL','Fx fallecimiento aut','Fx fallecimiento autor',_,'TIEMPO','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','FNAC','Fx nacimiento autor','Fx nacimiento autor',_,'TIEMPO','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','FPUB','Fecha publicacion','Fecha publicacion de la obra',_,'TIEMPO','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','FSES','Fecha sesion','Fecha sesion',_,'TIEMPO','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','HSES','Hora sesion','Hora sesion',_,'TIEMPO','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','NASI','Numero de asientos','Numero de asientos',_,'CANTIDAD','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','NCIU','Nombre ciudad','Nombre ciudad',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','NHAB','Numero de habitantes','Numero de habitantes',_,'CANTIDAD','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','NOAU','Nombre autor','Nombre autor',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','NOMB','Nombre del teatro','Nombre del teatro',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','NOOB','Nombre de la obra','Nombre de la obra',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','NUCA','Numero calle','Numero calle',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','OBRA','Obra','Obra',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','PREC','Precio','Precio',_,'UNIDAD','ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','SESI','Sesion','Sesion',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','EL','TEAT','Teatro','Teatro',_,'ESPACIO','ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','ALI1','Numero asientos libr','Numero (ASIENTOS LIBRES)',_,'CANTIDAD','ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','AUT1','Autor 1: CELA','Autor 1: CELA',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','AUT2','Autor 2: SHAKESPEARE','Autor 2: SHAKESPEARE',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','AUT3','Autor 3: ANDERSEN','Autor 3: ANDERSEN',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','COAA','Cod alfa autor','Codigo alfanumerico autor',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','COCI','Codigo alfa CIUDAD','Codigo alfanumerico CIUDAD',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','COO1','Codigo OBRA alfa','Codigo OBRA alfanumerico',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','COP1','Codigo postal numer','Codigo postal numerico',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','COT1','Codigo alfa TEATRO','Codigo alfanumerico TEATRO',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','DUR1','Numero minutos','Numero minutos',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','ESOB','Estilo obra (Tabla)','Estilo obra TERMINO GENERICO',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','ESOQ','Estilo obra QUOTED','Estilo obra QUOTED',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','FAP1','Fecha apertura','Fecha apertura',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','FFA1','Fx fallecimiento aut','Fecha fallecimiento autor',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','FNA1','Fx nacimiento autor','Fecha nacimiento autor',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','FPU1','Fx publicacion','Fecha publicacion libro',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','FSE1','Fx sesion','Fecha sesion',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','HSE1','Hora sesion','Hora sesion',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NAS1','Numero asientos','Numero asientos',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NHA1','Numero habitantes','Numero habitantes',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOA1','Nombre autor','Nombre autor',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOC1','CIUDAD 1: MADRID','CIUDAD 1: MADRID',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOC2','CIUDAD 2: EDIMBURGO','CIUDAD 2: EDIMBURGO',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOC3','CIUDAD 3: COPENHAGEN','CIUDAD 3: COPENHAGEN',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOC4','CIUDAD 4: STRUER','CIUDAD 4: STRUER',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOCQ','Nombre calle QUOTED','Nombre de calle QUOTED',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOM1','NO TEAT 1: GARAGE','NO TEATRO 1: THE GARAGE THEATRE',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOM2','NO TEAT 2: TRAVERSE','NO TETARO 2: TRAVERSE THEATRE',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOMQ','Nombre teatro QUOTED','Nombre del teatro QUOTED',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOO1','OBRA 1: MARIA SABINA','OBRA 1: MARIA SABINA',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOO2','OBRA 2: HOMENAJE','OBRA 2: HOMENAJE AL BOSCO',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOO3','OBRA 3: HAMLET','OBRA 3: HAMLET',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOO4','OBRA 4: KING LEAR','OBRA 4: KING LEAR',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NOOQ','Nombre OBRA QUOTED','Nombre OBRA QUOTED',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','NUC1','Numero calle','Numero calle',_,_,'ELEM_ATRIB_VALOR',_).
concepto('TEA1','VA','PRE1','Numero precio','Numero precio',_,_,'ELEM_ATRIB_VALOR',_).
