:-module(salida,[write_sem_set/2, 
	         map_write_list/1,
	         write_list/1, 
		 write_solution/2, 
		 map_write_solution/3, 
		 map_write_token_list/1]).

:-use_module(library(lists)).
:-use_module(library(sort)).
:-use_module(library(format)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	write_elem
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

write_sem_set(cjto_sem( traza(_Origen),
                        token(_Area,_Cat,_Id),
                        elemento(CS,_IdS,_Ctx,Pol,D,_Nat,valor(Vi,Vf,F,Tipo)),
                        accion(_Acc,DA,Obj,Ord,Perif),
                        Lista_Asoc),Deep):-
        CS = valor(_),
        !,
        format_slot_s(Deep,"[~w]~n",[D]),
        %format_slot(Deep,"  Cp. Sem:    ~w~n",[CS]),
        format_slot(Deep,"  Val ini:  ~w~n",[Vi]),
        format_slot(Deep,"  Val fin:  ~w~n",[Vf]),
        format_slot(Deep,"  Fun:      ~w~n",[F]),
        format_slot(Deep,"  Tipo:     ~w~n",[Tipo]),
        format_slot(Deep,"  Accion:   ~w~n",[DA]),
        format_slot(Deep,"  Objeto:   ~w~n",[Obj]),
        format_slot(Deep,"  Orden:    ~w~n",[Ord]),
        format_slot(Deep,"  Perif:    ~w~n",[Perif]),
        format_slot(Deep,"  Pol:      ~w~n",[Pol]),
        Deep_Next is Deep + 1,
%        sort(Lista_Asoc, Lista_Asoc_S),
        write_assocs(Lista_Asoc,Deep_Next).
%        format("~n",[]).

write_sem_set(cjto_sem( traza(_Origen),
                        token(_Area,_Cat,_Id),
                        elemento(_CS,_IdS,Ctx,Pol,D,_Nat,valor(_Vi,_Vf,_F,_Tipo)),
                        accion(_Acc,DA,Obj,Ord,Perif),
                        Lista_Asoc),Deep):-
        format_slot_s(Deep,"[~w]~n",[D]),
        format_slot_cuantif(Deep,"  Cuant:    ~w~n",[Ctx]),
        %format_slot(Deep,"  Val ini:  ~w~n",[Vi]),
        %format_slot(Deep,"  Val fin:  ~w~n",[Vf]),
        %format_slot(Deep,"  Fun:      ~w~n",[F]),
        %format_slot(Deep,"  Tipo:     ~w~n",[Tipo]),
        format_slot(Deep,"  Accion:   ~w~n",[DA]),
        format_slot(Deep,"  Objeto:   ~w~n",[Obj]),
        format_slot(Deep,"  Orden:    ~w~n",[Ord]),
        format_slot(Deep,"  Perif:    ~w~n",[Perif]),
        format_slot(Deep,"  Pol:      ~w~n",[Pol]),
        Deep_Next is Deep + 1,
%        sort(Lista_Asoc, Lista_Asoc_S),
        write_assocs(Lista_Asoc,Deep_Next).
%        format("~n",[]).


write_sem_set(separador(Fase,Elemento),Deep):-
        format_slot(Deep,"(~w)~n ",[Fase]),
	write_sem_set(Elemento,Deep).
write_sem_set(nada,_).
write_sem_set(falta,_).


write_sem_set_all(cjto_sem( traza(_Origen),
                        token(Area,Cat,Id),
                        elemento(CS,IdS,Ctx,Pol,D,Nat,valor(Vi,Vf,F,Tipo)),
                        accion(Acc,DA,Obj,Ord,Perif),
                        Lista_Asoc),Deep):-
	format_slot(Deep,"=====================================-~n",[]),
        format_slot(Deep,"Token.Area:         ~w~n",[Area]),
	format_slot(Deep,"Token.Categoria:    ~w~n",[Cat]),
	format_slot(Deep,"Token.Id:           ~w~n",[Id]),
        format_slot(Deep,"Elem.Cat_Sem:       ~w~n",[CS]),
        format_slot(Deep,"Elem.Id_Sem:        ~w~n",[IdS]),
  	format_slot(Deep,"Elem.Cuantific:     ~w~n",[Ctx]),
	format_slot(Deep,"Elem.Polaridad:     ~w~n",[Pol]),
	format_slot(Deep,"Elem.Descripcion:   ~w~n",[D]),
	format_slot(Deep,"Elem.Naturaleza:    ~w~n",[Nat]),
        format_slot(Deep,"Elem.Valor.Valor_ini:    ~w~n",[Vi]),
	format_slot(Deep,"Elem.Valor.Valor_fin:    ~w~n",[Vf]),
        format_slot(Deep,"Elem.Valor.Funcion:      ~w~n",[F]),
	format_slot(Deep,"Elem.Valor.Tipo:         ~w~n",[Tipo]),
        format_slot(Deep,"Accion.Accion:       ~w~n",[Acc]),
        format_slot(Deep,"Accion.Des_Accion:   ~w~n",[DA]),
        format_slot(Deep,"Accion.Objeto:       ~w~n",[Obj]),
        format_slot(Deep,"Accion.Orden:        ~w~n",[Ord]),
        format_slot(Deep,"Accion.Periferico:   ~w~n",[Perif]),
        Deep_Next is Deep + 1,
	write_assocs_all(Lista_Asoc,Deep_Next),
	format_slot(Deep,"~n",[]).

write_sem_set_all(separador(Fase,Elemento),Deep):-
        format_slot(Deep,"(~w)~n ",[Fase]),
	write_sem_set_all(Elemento,Deep).
write_sem_set_all(nada,_).
write_sem_set_all(falta,_).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    format_slot[_cuantif|_s]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
format_slot_cuantif(Deep, _,[cuantif(Vi,Vf,F)]):-
        format_slot(Deep," cuantificador:     ~w~n",[Vi]),
        format_slot(Deep," cuantif final:     ~w~n",[Vf]),
        format_slot(Deep," cuantif  func:     ~w~n",[F]).


format_slot(Deep,String,[Arg]):-
	nonvar(Arg),
	!,
	format_deep(Deep),
	format(String,Arg).

format_slot(_,_,_).

format_slot_s(Deep,String,Arg):-
	format_deep(Deep),
	format(String,Arg).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%      write_assocs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
write_assocs([],_).

write_assocs([asoc(traza(_Origen), 
                   token(_Area,_Cat,Id),
                   elemento(_CS,_Tipo_UML,_Tipo,Desc,_Nat,_Card,valor(_Vi,_Vf,_Fun, _Tipo)),
                   Elem)|Tail_Assocs],Deep_Prev):-
        member(Id,['CONJ','DISY','SIGN']),
        !,
        Deep is Deep_Prev - 1,
	format_slot(Deep,"{~w}~n",[Desc]),
	write_sem_set(Elem,Deep),
	write_assocs(Tail_Assocs,Deep).

write_assocs([asoc(traza(_Origen),
                   token(_Area,_Cat,_Id),
                   elemento(_CS,_Tipo_UML,_Tipo,Desc,_Nat,_Card,valor(_Vi,_Vf,_Fun, _Tipo)),
                   Elem)|Tail_Assocs],Deep):-
	format_slot(Deep,"{~w}~n",[Desc]),
        Deep_Next is Deep + 1,
	write_sem_set(Elem,Deep_Next),
	write_assocs(Tail_Assocs,Deep).

write_assocs_all([],_).
write_assocs_all([asoc(token(Area,Cat,Id),
                   elemento(CS,Tipo_UML,Tipo,Desc,Nat,Card,valor(Vi,Vf,F, Tipo)),
                   Elem)|Tail_Assocs],Deep_Prev):-
        member(Id,['CONJ','DISY']),
        !,
        Deep is Deep_Prev - 1,
        format_slot(Deep,"<-------ASOCIACION-------------------~n",[]),
        format_slot(Deep,"<Area:        ~w~n",[Area]),
	format_slot(Deep,"<Categoria:   ~w~n",[Cat]),
	format_slot(Deep,"<Id:          ~w~n",[Id]),
        format_slot(Deep,"<Cat Sem      ~w~n",[CS]),
	format_slot(Deep,"<Valor ini:   ~w~n",[Vi]),
	format_slot(Deep,"<Valor fin:   ~w~n",[Vf]),
	format_slot(Deep,"<Funcion:     ~w~n",[F]),
	format_slot(Deep,"<Tipo UML:    ~w~n",[Tipo_UML]),
	format_slot(Deep,"<Tipo:        ~w~n",[Tipo]),
	format_slot(Deep,"<Descripcion: ~w~n",[Desc]),
 	format_slot(Deep,"<Naturaleza:  ~w~n",[Nat]),
 	format_slot(Deep,"<Cardinal:    ~w~n",[Card]),
	write_sem_set_all(Elem,Deep),
	write_assocs_all(Tail_Assocs,Deep).

write_assocs_all([asoc(traza(_Origen),
                   token(Area,Cat,Id),
                   elemento(CS,Tipo_UML,Tipo,Desc,Nat,Card,valor(Vi,Vf,F, Tipo)),
                   Elem)|Tail_Assocs],Deep):-
        format_slot(Deep,"<-------ASOCIACION-------------------~n",[]),
        format_slot(Deep,"<Area:        ~w~n",[Area]),
	format_slot(Deep,"<Categoria:   ~w~n",[Cat]),
	format_slot(Deep,"<Id:          ~w~n",[Id]),
        format_slot(Deep,"<Cat Sem      ~w~n",[CS]),
	format_slot(Deep,"<Valor ini:   ~w~n",[Vi]),
	format_slot(Deep,"<Valor fin:   ~w~n",[Vf]),
	format_slot(Deep,"<Funcion:     ~w~n",[F]),
	format_slot(Deep,"<Tipo UML:    ~w~n",[Tipo_UML]),
	format_slot(Deep,"<Tipo:        ~w~n",[Tipo]),
	format_slot(Deep,"<Descripcion: ~w~n",[Desc]),
 	format_slot(Deep,"<Naturaleza:  ~w~n",[Nat]),
 	format_slot(Deep,"<Cardinal:    ~w~n",[Card]),
        Deep_Next is Deep + 1,
	write_sem_set_all(Elem,Deep_Next),
	write_assocs_all(Tail_Assocs,Deep).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        [map_]write_list[_all]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

map_write_list([]).
map_write_list([(Entrada,Lista)|Resto]):-
	write_token_list(Entrada),
	write_list(Lista),
	format("////////////////////////////////////////////////////////////~n",[]),
        map_write_list(Resto).


write_list([]):-
	format("---------------------------------------------------------------~n~n",[]).
write_list([Elem|Tail]):-
	write_sem_set(Elem,0),
	!,
	write_list(Tail).
	
write_list([Elem|Tail]):-
	format(" Unknown: ~w~n",[Elem]),	
	write_list(Tail).
	
write_list_all([]):-
	format("----------------------------------------------------------------~n~n",[]).
write_list_all([Elem|Tail]):-
	write_sem_set_all(Elem,0),
	!,
	write_list_all(Tail).
	
write_list_all([Elem|Tail]):-
	format(" Unknown: ~w~n",[Elem]),	
	write_list_all(Tail).

format_deep(-1):-
        !.
format_deep(0):-
	!.
format_deep(N):-
	format("     ",[]),
	N1 is N - 1,
	format_deep(N1).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    map_write_token_list
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
map_write_token_list([]):-
	!.
map_write_token_list([Entrada|Resto]):-
	write_token_list(Entrada),
        format("-----------------------------~n~n",[]),
        map_write_token_list(Resto).



write_token_list([]).
write_token_list([(Id,V_i,V_f,F)|Resto]):-
	name(Ident,Id),
        format("(~w, ",[Ident]),
	format_val(V_i),
	format(", ",[]),
        format_val(V_f),
	format(", ",[]),
        format_val(F),
        format(")~n",[]),
        write_token_list(Resto).

format_val(Valor):-
	list(Valor),
	!,
	atom_codes(ElValor,Valor),
        format("~w",[ElValor]).
format_val(Valor):-
	format("~w",[Valor]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        write_solution
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

map_write_solution(_, _, []):-
	!.
map_write_solution(Frase, Coste, [S|Resto]):-
        write_solution(Frase, S),
        map_write_solution(Frase, Coste, Resto).



write_solution(Frase, (Coste, Salida, Entrada, Tokens)):-
                       format("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv~n~n~n",[]),
                       write_token_list(Tokens),
                       format("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv~n~n",[]),
                       write_list(Entrada),
                       format("~n~n~n",[]),
                       write_list(Salida),
                       format("Frase:~w          [Coste: ~w]~n~n",[Frase,Coste]),
                       format("#################################################################~n~n~n",[]).


