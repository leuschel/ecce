:-module(convertir,[convert/2]). 

:-use_module(library(format)).

:-use_module(unificar).
:-use_module(con_concepto).
:-use_module(aso_asociacion).
:-use_module(val_valor).
:-use_module(ele_elemento).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

convert(token(Indice, Area, 'GE', 'VANU', Vi, Vf, F), E):-
     convert(token(Indice, Area, 'SX', 'FUVA', Vi, Vf, F), E).

convert(token(Indice, Area, 'VG', Id, Vi, Vf, F), E):-
     valor(Area_Va, Cat_Va, Id_Va, _, _, _, _, _, _, Area_1, 'VG', Id_1, _),
     ground(Area_1),
     ground(Id_1),
     Area_1 = Area,
     Id_1 = Id,
     convert(token(Indice, Area_Va, Cat_Va, Id_Va, Vi, Vf, F), E).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Conjuncion ==> 
convert(token(_, Area_Conj, 'SX', 'CONJ', Val_ini, Val_fin, Fun),separador('fase 1',
        cjto_sem(
                 traza(
                      _                             %Origen
                 ),
                 token(
                       _,                           % Area
                       _,                           % Categoria
                       _                            % Identificador
                 ),
                 elemento(
                        Cat_Sem_Elem,               % Categoria Semantica
                        _,                          % Id Semantico
                        _,                          % Cuantificador
                        _,                          % Polaridad
                        _,                          % Descripcion
                        _,                          % Naturaleza
                        valor(
                              _,                    % Valor_inicial
                              _,                    % Valor_final
                              _,                    % Funcion
                              _                     % Tipo de dato
                        )
                 ),
                 accion(
                        _,                          % Accion | Saludo | Salida | Ayuda
                        _,                          % Descripcion de la accion
                        _,                          % Objeto
                        _,                          % Orden
                        _                           % Periferico
                 ),
                 [
                          asoc(
                               traza(
                                     original              %Origen
                               ),
                               token(
                                     Area_Conj,            % Area Asociacion
                                     'SX',                 % Categoria Asociacion
                                     'CONJ'                % Id Asoc
                                ),
                                elemento(
                                     asociacion(Cat_Sem_Elem,Cat_Sem_Elem,coordinada),
                                     _,                    % Tipo UML
                                     _,                    % Tipo de la Asociacion
                                     Desc_Conj,            % Descripcion de la Asociacion
                                     Nat_Conj,             % Naturaleza de la asociacion
                                     _,                    % Cardinalidad
                                     valor(
                                           Val_ini,        % Valor inicial Asociacion
                                           Val_fin,        % Valor inicial Asociacion
                                           Fun,            % Valor inicial Asociacion                  
                                           _               % Valor inicial Asociacion                
                                     )
                                 ),
                                 cjto_sem(
                                          traza(
                                                _                           %Origen
                                          ),
                                          token(
                                                _,                          % Area
                                                _,                          % Categoria
                                                _                           % Identificador
                                          ),
                                          elemento(
                                                Cat_Sem_Elem,
                                                _,                          % Id Semantico
                                                _,                          % Cuantificador
                                                _,                          % Polaridad
                                                _,                          % Descripcion
                                                _,                          % Naturaleza
                                                valor(
                                                      _,                    % Valor_inicial
                                                      _,                    % Valor_final
                                                      _,                    % Funcion
                                                      _                     % Tipo de dato
                                                )
                                          ),
                                          accion(
                                                _,                          % Accion | Saludo | Salida | Ayuda
                                                _,                          % Descripcion de la accion
                                                _,                          % Objeto
                                                _,                          % Orden
                                                _                           % Periferico
                                          ),
                                          []
                                 ) % fin cjto_sem
                          ) % fin asoc
                  ]
       ))):-
     concepto(Area_Conj, 'SX', 'CONJ', Desc_Conj, _, _, Nat_Conj, _, _).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Disyuncion ==> 
convert(token(_, Area_Conj, 'SX', 'DISY', Val_ini, Val_fin, Fun),separador('fase 1',
        cjto_sem(
                 traza(
                      _                             %Origen
                 ),
                 token(
                       _,                           % Area
                       _,                           % Categoria
                       _                            % Identificador
                 ),
                 elemento(
                        Cat_Sem_Elem,               % Categoria Semantica
                        _,                          % Id Semantico
                        _,                          % Cuantificador
                        _,                          % Polaridad
                        _,                          % Descripcion
                        _,                          % Naturaleza
                        valor(
                              _,                    % Valor_inicial
                              _,                    % Valor_final
                              _,                    % Funcion
                              _                     % Tipo de dato
                        )
                 ),
                 accion(
                        _,                          % Accion | Saludo | Salida | Ayuda
                        _,                          % Descripcion de la accion
                        _,                          % Objeto
                        _,                          % Orden
                        _                           % Periferico
                 ),
                 [
                          asoc(
                               traza(
                                     original              %Origen
                               ),
                               token(
                                     Area_Conj,            % Area Asociacion
                                     'SX',                 % Categoria Asociacion
                                     'DISY'                % Id Asoc
                                ),
                                elemento(
                                     asociacion(Cat_Sem_Elem,Cat_Sem_Elem,coordinada),
                                     _,                    % Tipo UML
                                     _,                    % Tipo de la Asociacion
                                     Desc_Conj,            % Descripcion de la Asociacion
                                     Nat_Conj,             % Naturaleza de la asociacion
                                     _,                    % Cardinalidad
                                     valor(
                                           Val_ini,        % Valor inicial Asociacion
                                           Val_fin,        % Valor inicial Asociacion
                                           Fun,            % Valor inicial Asociacion                  
                                           _               % Valor inicial Asociacion                
                                     )
                                 ),
                                 cjto_sem(
                                          traza(
                                                _                           %Origen
                                          ),
                                          token(
                                                _,                          % Area
                                                _,                          % Categoria
                                                _                           % Identificador
                                          ),
                                          elemento(
                                                Cat_Sem_Elem,
                                                _,                          % Id Semantico
                                                _,                          % Cuantificador
                                                _,                          % Polaridad
                                                _,                          % Descripcion
                                                _,                          % Naturaleza
                                                valor(
                                                      _,                    % Valor_inicial
                                                      _,                    % Valor_final
                                                      _,                    % Funcion
                                                      _                     % Tipo de dato
                                                )
                                          ),
                                          accion(
                                                _,                          % Accion | Saludo | Salida | Ayuda
                                                _,                          % Descripcion de la accion
                                                _,                          % Objeto
                                                _,                          % Orden
                                                _                           % Periferico
                                          ),
                                          []
                                 ) % fin cjto_sem
                          ) % fin asoc
                  ]
      ))):-
     concepto(Area_Conj, 'SX', 'DISY', Desc_Conj, _, _, Nat_Conj, _, _).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preposicion ==> 
convert(token(_, _, 'SX', 'PRPO', _, _, _),falta).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pronombre Demostrativo ==> 
convert(token(_, _, 'SX', 'DEMO', _, _, _),falta).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pronombre Posesivo ==> 
convert(token(_, _, 'SX', 'POSE', _, _, _),falta).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Verbo Auxiliar ==> 
convert(token(_, _, 'SX', 'VAUX', _, _, _),falta).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pronombre Interrogativo o Relativo ==> 
convert(token(0, _, 'SX', 'PRIR', _, _, _),falta):-
      !.

convert(token(_, _, 'SX', 'PRIR', _, _, _), separador('fase 1',nada)).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pronombre Relativo ==> 
convert(token(_, _, 'SX', 'PRRE', _, _, _),falta).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Pronombre Interrogativo ==> 
convert(token(_, _, 'SX', 'PRIN', _, _, _),falta).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Funcion_Valor ==> 
convert(token(_, Area, 'SX', 'FUVA', Val_ini, Val_fin, Fun),
        cjto_sem(
                 traza(
                       _                            %Origen
                 ),
                 token(
                       Area,                        % Area
                       'SX',                        % Categoria
                       'FUVA'                       % Identificador
                 ), % fin token
                 elemento(
                        _,                          % Cat Sem
                        _,                          % Id Semantico
                        _,                          % Cuantificador
                        _,                          % Polaridad
                        _,                          % Descripcion
                        _,                          % Naturaleza
                        valor(
                              Val_ini,              % Valor_inicial
                              Val_fin,              % Valor_final
                              Fun,                  % Funcion
                              _                     % Tipo de dato
                        ) % fin valor
                 ), % fin elemento
                 accion(
                        _,                          % Accion | Saludo | Salida | Ayuda
                        _,                          % Descripcion de la accion
                        _,                          % Objeto
                        _,                          % Orden
                        _                           % Periferico
                 ),
                 []
        )).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Valor o Cuantificador ==> 
convert(token(_, Area, 'SX', 'FVCF', Val_ini, Val_fin, Fun),
        cjto_sem(
                 traza(
                       _                            %Origen
                 ),
                 token(
                       Area,                        % Area
                       'SX',                        % Categoria
                       'FVCF'                       % Identificador
                 ), % fin token
                 elemento(
                        _,                          % Cat Sem
                        _,                          % Id Semantico
                        _,                          % Cuantificador
                        _,                          % Polaridad
                        _,                          % Descripcion
                        _,                          % Naturaleza
                        valor(
                              Val_ini,              % Valor_inicial
                              Val_fin,              % Valor_final
                              Fun,                  % Funcion
                              _                     % Tipo de dato
                        ) % fin valor
                 ), % fin elemento
                 accion(
                        _,                          % Accion | Saludo | Salida | Ayuda
                        _,                          % Descripcion de la accion
                        _,                          % Objeto
                        _,                          % Orden
                        _                           % Periferico
                 ),
                 []
        )).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Cuantificador ==> 
convert(token(_, Area, 'SX', 'CTFC', Val_ini, Val_fin, Fun),
        cjto_sem(
                 traza(
                      _                             %Origen
                 ),
                 token(
                       Area,                        % Area
                       'SX',                        % Categoria
                       'FVCF'                       % Identificador
                 ), % fin token
                 elemento(
                        _,                          % Cat_Sem /puedo obligar a que se elem !!!
                        _,                          % Id Semantico
                        cuantif(Val_ini,Val_fin,Fun),% Cuantificador
                        _,                          % Polaridad
                        _,                          % Descripcion
                        _,                          % Naturaleza
                        valor(
                              Val_ini,              % Valor_inicial
                              Val_fin,              % Valor_final
                              Fun,                  % Funcion
                              _                     % Tipo de dato
                        ) % fin valor
                 ), % fin elemento
                 accion(
                        _,                          % Accion | Saludo | Salida | Ayuda
                        _,                          % Descripcion de la accion
                        _,                          % Objeto
                        _,                          % Orden
                        _                           % Periferico
                 ),
                 []
        )).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Comparativo ==> 
convert(token(_, _, 'SX', 'COMP', _, _, _),nada).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Negacion ==> 
	convert(token(_, Area, 'SX', 'NEGA', _, _, _),
        cjto_sem(
                 traza(
                      _                             %Origen
                 ),
                 token(
                       Area,                        % Area
                       'SX',                        % Categoria
                       'FVCF'                       % Identificador
                 ), % fin token
                 elemento(
                        _,                          % Cat_Sem /puedo obligar a que se elem !!!
                        _,                          % Id Semantico
                        _,                          % Cuantificador
                        negativa,                   % Polaridad
                        _,                          % Descripcion
                        _,                          % Naturaleza
                        valor(
                              _,                    % Valor_inicial
                              _,                    % Valor_final
                              _,                  % Funcion
                              _                     % Tipo de dato
                        ) % fin valor
                 ), % fin elemento
                 accion(
                        _,                          % Accion | Saludo | Salida | Ayuda
                        _,                          % Descripcion de la accion
                        _,                          % Objeto
                        _,                          % Orden
                        _                           % Periferico
                 ),
                 []
        )).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Articulo ==> 
convert(token(_, _, 'SX', 'ARLI', _, _, _),falta).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Accion ==> 
convert(token(_, Area, 'AC', Id, _, _, _),
        cjto_sem(
                 traza(
                      _                             %Origen
                 ),
                 token(
                       Area,                        % Area
                       'AC',                        % Categoria
                       Id                           % Identificador
                 ), % fin token
                 elemento(
                        _,                          % Cat Sem, no se como poner que se convierta en accion
                        _,                          % Id Semantico
                        _,                          % Cuantificador
                        _,                          % Polaridad
                        _,                          % Descripcion
                        _,                          % Naturaleza
                        valor(
                              _,                    % Valor_inicial
                              _,                    % Valor_final
                              _,                    % Funcion
                              _                     % Tipo de dato
                        ) % fin valor
                 ), % fin elemento
                 accion(
                        Id,                         % Accion | Saludo | Salida | Ayuda
                        Descripcion,                % Descripcion de la accion
                        _,                          % Objeto
                        _,                          % Orden
                        _                           % Periferico
                 ),
                 []
        )):-
    concepto(Area, 'AC', Id , Descripcion, _, _, _, _, _).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Asociacion ==> 
convert(token(_, Area_Asoc, 'AS', Id_Asoc, Val_ini, Val_fin, Fun),
        cjto_sem(
                 traza(
                       _                            %Origen
                 ),               
                 token(
                       Area_Elem,                   % Area
                       Cat_Elem,                    % Categoria
                       Id_Elem                      % Identificador
                 ),
                 elemento(
                        Cat_Sem_1,                  % Cat Sem
                        Id_Sem_1,                   % Id Semantico
                        _,                          % Cuantificador
                        _,                          % Polaridad
                        Desc_Elem,                  % Descripcion
                        Nat_Elem,                   % Naturaleza
                        valor(
                              _,                    % Valor_inicial
                              _,                    % Valor_final
                              _,                    % Funcion
                              _                     % Tipo de dato
                        )
                 ),
                 accion(
                        _,                          % Accion | Saludo | Salida | Ayuda
                        _,                          % Descripcion de la accion
                        _,                          % Objeto
                        _,                          % Orden
                        _                           % Periferico
                 ),
                 [
                          asoc(
                               traza(
                                     original              %Origen
                                ),
                               token(
                                     Area_Asoc,            % Area Asociacion
                                     'AS',                 % Categoria Asociacion
                                     Id_Asoc               % Id Asoc
                                ),
                                elemento(
                                     asociacion(Cat_Sem_1,Cat_Sem_2,subordinada),
                                     Tipo_UML,             % Tipo UML
                                     Tipo,                 % Tipo de la Asociacion
                                     Desc_Asoc,            % Descripcion de la Asociacion
                                     Nat_Asoc,             % Naturaleza de la asociacion
                                     Card,                 % Cardinalidad
                                     valor(
                                           _,              % Valor inicial Asociacion
                                           _,              % Valor inicial Asociacion
                                           _,              % Valor inicial Asociacion                  
                                           _               % Valor inicial Asociacion                
                                     )
                                 ),
                                 cjto_sem(
                                          traza(
                                                _                            %Origen
                                          ),
                                          token(
                                                Area_At,                     % Area
                                                'EL',                        % Categoria
                                                Id_At                        % Identificador
                                          ),
                                          elemento(
                                                Cat_Sem_2,                  %Cat Sem
                                                Id_Sem_2,                   % Id Semantico
                                                _,                          % Cuantificador
                                                _,                          % Polaridad
                                                Desc_At,                    % Descripcion
                                                Nat_At,                     % Naturaleza
                                                valor(
                                                      Val_ini,              % Valor_inicial
                                                      Val_fin,              % Valor_final
                                                      Fun,                  % Funcion
                                                      _                     % Tipo de dato
                                                )
                                          ),
                                          accion(
                                                _,                          % Accion | Saludo | Salida | Ayuda
                                                _,                          % Descripcion de la accion
                                                _,                          % Objeto
                                                _,                          % Orden
                                                _                           % Periferico
                                          ),
                                          []
                                 ) % fin cjto_sem
                          ) % fin asoc
                  ]
        )):-
    asociacion(Area_Asoc, Cat_Asoc, Id_Asoc, Area_Elem, Cat_Elem, Id_Elem, Area_At, 'EL', Id_At, Card, _,_,_,_,_,_,
               Tipo_UML, Tipo,_),
    concepto(Area_Asoc, Cat_Asoc, Id_Asoc, Desc_Asoc, _, _, Nat_Asoc, _, _),
    concepto(Area_At, 'EL', Id_At, Desc_At, _, _, Nat_At, _, _),
    concepto(Area_Elem, Cat_Elem, Id_Elem, Desc_Elem, _, _, Nat_Elem, _, _),
    Cat_Sem_1 = elemento(token(Area_Elem,'EL',Id_Elem)),
    Id_Sem_1 = elemento(token(Area_Elem,'EL',Id_Elem)),
    (es_elemento(token(Area_At,'EL',Id_At))->
         Cat_Sem_2 = elemento(token(Area_At,'EL',Id_At)),
         Id_Sem_2 = elemento(token(Area_At,'EL',Id_At))
     ;
        asociacion(_, _, _, Area_Elem, Cat_Elem, Id_Elem, Area_At, 'EL', Id_At, _, _,_,_, _,_,_, _,_,_),
        Cat_Sem_2 = atributo(token(Area_Elem,Cat_Elem,Id_Elem)),
        Id_Sem_2 = atributo(token(Area_At,'EL',Id_At),token(Area_Elem,Cat_Elem,Id_Elem))
     ).
                       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Elemento ==>
convert(token(_, Area, 'EL', Id, Val_ini, Val_fin, Fun),
        cjto_sem(
                 traza(
                      original                      %Origen
                 ),
                 token(
                       Area,                        % Area
                       'EL',                        % Categoria
                       Id                           % Identificador
                 ), % fin token
                 elemento(
                        Cat_Sem,
                        Id_Sem,                     % Id Semantico
                        Cuantif,                    % Cuantificador
                        _,                          % Polaridad
                        Descripcion,                % Descripcion
                        Naturaleza,                 % Naturaleza
                        valor(
                              Val_ini,              % Valor_inicial
                              Val_fin,              % Valor_final
                              Fun,                  % Funcion
                              _                     % Tipo de dato
                        ) % fin valor
                 ), % fin elemento
                 accion(
                        _,                          % Accion | Saludo | Salida | Ayuda
                        _,                          % Descripcion de la accion
                        _,                          % Objeto
                        _,                          % Orden
                        _                           % Periferico
                 ),
                 []
        )):-
    concepto(Area, 'EL', Id , Descripcion, _, _, Naturaleza, _, _),
    es_elemento(token(Area,'EL',Id)),
    Cat_Sem = elemento(token(Area,'EL',Id)),
    Cuantif = cuantif(Val_ini,Val_fin,Fun),
    Id_Sem = elemento(token(Area,'EL',Id)).

convert(token(_, Area, 'EL', Id, Val_ini, Val_fin, Fun),
        cjto_sem(
                 traza(
                      original                      %Origen
                 ),
                 token(
                       Area,                        % Area
                       'EL',                        % Categoria
                       Id                           % Identificador
                 ), % fin token
                 elemento(
                        Cat_Sem,
                        Id_Sem,                     % Id Semantico
                        _,                          % Cuantificador
                        _,                          % Polaridad
                        Descripcion,                % Descripcion
                        Naturaleza,                 % Naturaleza
                        valor(
                              Val_ini,              % Valor_inicial
                              Val_fin,              % Valor_final
                              Fun,                  % Funcion
                              _                     % Tipo de dato
                        ) % fin valor
                 ), % fin elemento
                 accion(
                        _,                          % Accion | Saludo | Salida | Ayuda
                        _,                          % Descripcion de la accion
                        _,                          % Objeto
                        _,                          % Orden
                        _                           % Periferico
                 ),
                 [
		     asoc(
			     _,
			     token('BAS0','AS','tiene valor'),
                             elemento(
					 asociacion(token(Area,'EL',Id),token(Area_Va,Cat_Va,Id_Va),subordinada),
                                         _, _, '-> valor', _, _, _ ),
                             cjto_sem(
				   _,
                                   token(
                                          Area_Va,                     % Area
                                          'VA',                        % Categoria
                                          Id_Va                        % Identificador
                                   ),
                                    elemento(
                                              valor(token(Area,'EL',Id)),
                                              valor(token(Area_Va,'VA',Id_Va),
                                                    token(Area,'EL',Id),
                                                    token(Area_Elem,Cat_Elem,Id_Elem)),
                                              _,                          % Cuantificador
                                              _,                          % Polaridad
                                              Desc_Va,                    % Descripcion
                                              Nat_Va,                     % Naturaleza
                                              valor(
                                                     Val_ini,              % Valor_inicial
                                                     Val_fin,              % Valor_final
                                                     Fun,                  % Funcion
                                                     Tipo_Va               % Tipo de dato
                                               )
                                     ),
                                     accion(
                                             _,                          % Accion | Saludo | Salida | Ayuda
                                             _,                          % Descripcion de la accion
                                             _,                          % Objeto
                                             _,                          % Orden
                                             _                           % Periferico
                                      ),
                                      []
                            ) % fin cjto_sem
                        )%fin asoc
		     ]
        )):-
    concepto(Area, 'EL', Id , Descripcion, _, _, Naturaleza, _, _),
    es_atributo(token(Area,'EL',Id)),
    asociacion(_, _, _, Area_Elem, Cat_Elem, Id_Elem, Area, 'EL', Id, _, _,_,_, _,_,_, _,_,_),
    Cat_Sem = atributo(token(Area_Elem,Cat_Elem,Id_Elem)),
    Id_Sem = atributo(token(Area,'EL',Id),token(Area_Elem,Cat_Elem,Id_Elem)),
    valor(Area_Va, Cat_Va, Id_Va, Area, 'EL', Id, _,_,_, _,_,_, Tipo_Va),
    concepto(Area_Va, Cat_Va, Id_Va, Desc_Va, _, _, Nat_Va, _, _).
    



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Valor  ==>
convert(token(_, Area_Va, 'VA', Id_Va, Val_ini, Val_fin, Fun),
        cjto_sem(
                  traza(
                        _                            %Origen
                       ),
                  token(
                        Area_At,                     % Area
                        'EL',                        % Categoria
                        Id_At                        % Identificador
                  ),
                  elemento(
                            atributo(token(Area_Elem, Cat_Elem, Id_Elem)),
                            valor(token(Area_Va,'VA',Id_Va),
                                  token(Area_At,'EL',Id_At),
                                  token(Area_Elem,Cat_Elem,Id_Elem)),
                            _,                          % Cuantificador
                            _,                          % Polaridad
                            Desc_At,                    % Descripcion
                            Nat_At,                     % Naturaleza
                            valor(
                                   Val_ini,             % Valor_inicial
                                   Val_fin,             % Valor_final
                                   Fun,                 % Funcion
                                   Tipo_Va              % Tipo de dato
                            )
                  ),
                  accion(
                            _,                          % Accion | Saludo | Salida | Ayuda
                            _,                          % Descripcion de la accion
                            _,                          % Objeto
                            _,                          % Orden
                            _                           % Periferico
                  ),
                  [
                   asoc(
                         traza(
                                _                             %Origen
                         ),
                         token(
                               'BAS0',               % Area Asociacion
                               'AS',                 % Categoria Asociacion
                               'tiene valor'         % Id Asoc
                         ),
                         elemento(
                                  asociacion(token(Area_At,'EL',Id_At),token(Area_At,'EL',Id_At),subordinada),
                                  _,                    % Tipo UML
                                  _,                    % Tipo de la Asociacion
                                  '-> valor',           % Descripcion de la Asociacion
                                  _,                    % Naturaleza de la asociacion
                                  _,                    % Cardinalidad
                                  valor(
                                         _,              % Valor inicial Asociacion
                                         _,              % Valor inicial Asociacion
                                         _,              % Valor inicial Asociacion                  
                                         _               % Valor inicial Asociacion                
                                   )
                         ),
                         cjto_sem(
                                   traza(
                                          original                     %Origen
                                   ),
                                   token(
                                          Area_Va,                     % Area
                                          'VA',                        % Categoria
                                          Id_Va                        % Identificador
                                   ),
                                    elemento(
                                              valor(token(Area_At,'EL',Id_At)),
                                              valor(token(Area_Va,'VA',Id_Va),
                                                    token(Area_At,'EL',Id_At),
                                                    token(Area_Elem,Cat_Elem,Id_Elem)),
                                              _,                          % Cuantificador
                                              _,                          % Polaridad
                                              Desc_Va,                    % Descripcion
                                              Nat_Va,                     % Naturaleza
                                              valor(
                                                     Val_ini,              % Valor_inicial
                                                     Val_fin,              % Valor_final
                                                     Fun,                  % Funcion
                                                     Tipo_Va               % Tipo de dato
                                               )
                                     ),
                                     accion(
                                             _,                          % Accion | Saludo | Salida | Ayuda
                                             _,                          % Descripcion de la accion
                                             _,                          % Objeto
                                             _,                          % Orden
                                             _                           % Periferico
                                      ),
                                      []
                            ) % fin cjto_sem
                      ) % fin asoc
                 ]
          ) % fin cjto_sem
        ):-
    concepto(Area_Va, 'VA', Id_Va, Desc_Va, _, _, Nat_Va, _, _),
    valor(Area_Va, 'VA', Id_Va, Area_At, 'EL', Id_At, _, _, _, _, _, _, Tipo_Va),
    concepto(Area_At, 'EL', Id_At, Desc_At, _, _, Nat_At, _, _),
    asociacion( _, _, _, Area_Elem, Cat_Elem, Id_Elem, Area_At, 'EL', Id_At, _, _,_,_,_,_,_, _,_,_).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Texto Codigo  ==>
convert(token(_, _, 'GE', 'TXCO', _, _, _),falta).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Texto Fecha ==> 
convert(token(_, _, 'GE', 'TXFX', _, _, _),falta).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Texto Numero ==> 
convert(token(_, _, 'GE', 'TXNU', _, _, _),falta).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Texto Hora ==>
convert(token(_, _, 'GE', 'TXHO', _, _, _),falta).
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fecha ==> 
convert(token(_, _, 'GE', 'VAFX', Val_ini, Val_fin, Fun),
        cjto_sem(
                  traza(
                        _                            %Origen
                       ),
                  token(
                        Area_At,                     % Area
                        'EL',                        % Categoria
                        Id_At                        % Identificador
                  ),
                  elemento(
                            atributo(token(Area_Elem, Cat_Elem, Id_Elem)),
                            valor(token(Area_Va,'VA',Id_Va),
                                  token(Area_At,'EL',Id_At),
                                  token(Area_Elem,Cat_Elem,Id_Elem)),
                            _,                          % Cuantificador
                            _,                          % Polaridad
                            Desc_At,                    % Descripcion
                            Nat_At,                     % Naturaleza
                            valor(
                                   Val_ini,             % Valor_inicial
                                   Val_fin,             % Valor_final
                                   Fun,                 % Funcion
                                   'FX'                 % Tipo de dato
                            )
                  ),
                  accion(
                            _,                          % Accion | Saludo | Salida | Ayuda
                            _,                          % Descripcion de la accion
                            _,                          % Objeto
                            _,                          % Orden
                            _                           % Periferico
                  ),
                  [
                   asoc(
                         traza(
                                _                             %Origen
                         ),
                         token(
                               'BAS0',               % Area Asociacion
                               'AS',                 % Categoria Asociacion
                               'tiene valor'         % Id Asoc
                         ),
                         elemento(
                                  asociacion(token(Area_At,'EL',Id_At),token(Area_At,'EL',Id_At),subordinada),
                                  _,                    % Tipo UML
                                  _,                    % Tipo de la Asociacion
                                  '-> valor',           % Descripcion de la Asociacion
                                  _,                    % Naturaleza de la asociacion
                                  _,                    % Cardinalidad
                                  valor(
                                         _,              % Valor inicial Asociacion
                                         _,              % Valor inicial Asociacion
                                         _,              % Valor inicial Asociacion                  
                                         _               % Valor inicial Asociacion                
                                   )
                         ),
                         cjto_sem(
                                   traza(
                                          original                     %Origen
                                   ),
                                   token(
                                          Area_Va,                     % Area
                                          'VA',                        % Categoria
                                          Id_Va                        % Identificador
                                   ),
                                    elemento(
                                              valor(token(Area_At,'EL',Id_At)),
                                              valor(token(Area_Va,'VA',Id_Va),
                                                    token(Area_At,'EL',Id_At),
                                                    token(Area_Elem,Cat_Elem,Id_Elem)),
                                              _,                          % Cuantificador
                                              _,                          % Polaridad
                                              Desc_Va,                    % Descripcion
                                              Nat_Va,                     % Naturaleza
                                              valor(
                                                     Val_ini,              % Valor_inicial
                                                     Val_fin,              % Valor_final
                                                     Fun,                  % Funcion
                                                     'FX'                  % Tipo de dato
                                               )
                                     ),
                                     accion(
                                             _,                          % Accion | Saludo | Salida | Ayuda
                                             _,                          % Descripcion de la accion
                                             _,                          % Objeto
                                             _,                          % Orden
                                             _                           % Periferico
                                      ),
                                      []
                            ) % fin cjto_sem
                      ) % fin asoc
                 ]
          ) % fin cjto_sem
        ):-
    concepto(Area_Va, 'VA', Id_Va, Desc_Va, _, _, Nat_Va, _, _),
    valor(Area_Va, 'VA', Id_Va, Area_At, 'EL', Id_At, _, _, _, _, _, _, 'FX'),
    concepto(Area_At, 'EL', Id_At, Desc_At, _, _, Nat_At, _, _),
    asociacion( _, _, _, Area_Elem, Cat_Elem, Id_Elem, Area_At, 'EL', Id_At, _, _,_,_,_,_,_, _,_,_).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hora  ==> 
convert(token(_, _, 'GE', 'VAHO', Val_ini, Val_fin, Fun),
        cjto_sem(
                  traza(
                        _                            %Origen
                       ),
                  token(
                        Area_At,                     % Area
                        'EL',                        % Categoria
                        Id_At                        % Identificador
                  ),
                  elemento(
                            atributo(token(Area_Elem, Cat_Elem, Id_Elem)),
                            valor(token(Area_Va,'VA',Id_Va),
                                  token(Area_At,'EL',Id_At),
                                  token(Area_Elem,Cat_Elem,Id_Elem)),
                            _,                          % Cuantificador
                            _,                          % Polaridad
                            Desc_At,                    % Descripcion
                            Nat_At,                     % Naturaleza
                            valor(
                                   Val_ini,             % Valor_inicial
                                   Val_fin,             % Valor_final
                                   Fun,                 % Funcion
                                   'HO'                 % Tipo de dato
                            )
                  ),
                  accion(
                            _,                          % Accion | Saludo | Salida | Ayuda
                            _,                          % Descripcion de la accion
                            _,                          % Objeto
                            _,                          % Orden
                            _                           % Periferico
                  ),
                  [
                   asoc(
                         traza(
                                _                             %Origen
                         ),
                         token(
                               'BAS0',               % Area Asociacion
                               'AS',                 % Categoria Asociacion
                               'tiene valor'         % Id Asoc
                         ),
                         elemento(
                                  asociacion(token(Area_At,'EL',Id_At),token(Area_At,'EL',Id_At),subordinada),
                                  _,                    % Tipo UML
                                  _,                    % Tipo de la Asociacion
                                  '-> valor',           % Descripcion de la Asociacion
                                  _,                    % Naturaleza de la asociacion
                                  _,                    % Cardinalidad
                                  valor(
                                         _,              % Valor inicial Asociacion
                                         _,              % Valor inicial Asociacion
                                         _,              % Valor inicial Asociacion                  
                                         _               % Valor inicial Asociacion                
                                   )
                         ),
                         cjto_sem(
                                   traza(
                                          original                     %Origen
                                   ),
                                   token(
                                          Area_Va,                     % Area
                                          'VA',                        % Categoria
                                          Id_Va                        % Identificador
                                   ),
                                    elemento(
                                              valor(token(Area_At,'EL',Id_At)),
                                              valor(token(Area_Va,'VA',Id_Va),
                                                    token(Area_At,'EL',Id_At),
                                                    token(Area_Elem,Cat_Elem,Id_Elem)),
                                              _,                          % Cuantificador
                                              _,                          % Polaridad
                                              Desc_Va,                    % Descripcion
                                              Nat_Va,                     % Naturaleza
                                              valor(
                                                     Val_ini,              % Valor_inicial
                                                     Val_fin,              % Valor_final
                                                     Fun,                  % Funcion
                                                     'HO'                  % Tipo de dato
                                               )
                                     ),
                                     accion(
                                             _,                          % Accion | Saludo | Salida | Ayuda
                                             _,                          % Descripcion de la accion
                                             _,                          % Objeto
                                             _,                          % Orden
                                             _                           % Periferico
                                      ),
                                      []
                            ) % fin cjto_sem
                      ) % fin asoc
                 ]
          ) % fin cjto_sem
        ):-
    concepto(Area_Va, 'VA', Id_Va, Desc_Va, _, _, Nat_Va, _, _),
    valor(Area_Va, 'VA', Id_Va, Area_At, 'EL', Id_At, _, _, _, _, _, _, 'HO'),
    concepto(Area_At, 'EL', Id_At, Desc_At, _, _, Nat_At, _, _),
    asociacion( _, _, _, Area_Elem, Cat_Elem, Id_Elem, Area_At, 'EL', Id_At, _, _,_,_,_,_,_, _,_,_).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Entrecomillado ==> 
convert(token(_, _, 'GE', 'VAQU', Val_ini, Val_fin, Fun),
        cjto_sem(
                  traza(
                        _                            %Origen
                       ),
                  token(
                        Area_At,                     % Area
                        'EL',                        % Categoria
                        Id_At                        % Identificador
                  ),
                  elemento(
                            atributo(token(Area_Elem, Cat_Elem, Id_Elem)),
                            valor(token(Area_Va,'VA',Id_Va),
                                  token(Area_At,'EL',Id_At),
                                  token(Area_Elem,Cat_Elem,Id_Elem)),
                            _,                          % Cuantificador
                            _,                          % Polaridad
                            Desc_At,                    % Descripcion
                            Nat_At,                     % Naturaleza
                            valor(
                                   Val_ini,             % Valor_inicial
                                   Val_fin,             % Valor_final
                                   Fun,                 % Funcion
                                   'CO'                 % Tipo de dato
                            )
                  ),
                  accion(
                            _,                          % Accion | Saludo | Salida | Ayuda
                            _,                          % Descripcion de la accion
                            _,                          % Objeto
                            _,                          % Orden
                            _                           % Periferico
                  ),
                  [
                   asoc(
                         traza(
                                _                             %Origen
                         ),
                         token(
                               'BAS0',               % Area Asociacion
                               'AS',                 % Categoria Asociacion
                               'tiene valor'         % Id Asoc
                         ),
                         elemento(
                                  asociacion(token(Area_At,'EL',Id_At),token(Area_At,'EL',Id_At),subordinada),
                                  _,                    % Tipo UML
                                  _,                    % Tipo de la Asociacion
                                  '-> valor',           % Descripcion de la Asociacion
                                  _,                    % Naturaleza de la asociacion
                                  _,                    % Cardinalidad
                                  valor(
                                         _,              % Valor inicial Asociacion
                                         _,              % Valor inicial Asociacion
                                         _,              % Valor inicial Asociacion                  
                                         _               % Valor inicial Asociacion                
                                   )
                         ),
                         cjto_sem(
                                   traza(
                                          original                     %Origen
                                   ),
                                   token(
                                          Area_Va,                     % Area
                                          'VA',                        % Categoria
                                          Id_Va                        % Identificador
                                   ),
                                    elemento(
                                              valor(token(Area_At,'EL',Id_At)),
                                              valor(token(Area_Va,'VA',Id_Va),
                                                    token(Area_At,'EL',Id_At),
                                                    token(Area_Elem,Cat_Elem,Id_Elem)),
                                              _,                          % Cuantificador
                                              _,                          % Polaridad
                                              Desc_Va,                    % Descripcion
                                              Nat_Va,                     % Naturaleza
                                              valor(
                                                     Val_ini,              % Valor_inicial
                                                     Val_fin,              % Valor_final
                                                     Fun,                  % Funcion
                                                     'CO'                  % Tipo de dato
                                               )
                                     ),
                                     accion(
                                             _,                          % Accion | Saludo | Salida | Ayuda
                                             _,                          % Descripcion de la accion
                                             _,                          % Objeto
                                             _,                          % Orden
                                             _                           % Periferico
                                      ),
                                      []
                            ) % fin cjto_sem
                      ) % fin asoc
                 ]
          ) % fin cjto_sem
        ):-
    concepto(Area_Va, 'VA', Id_Va, Desc_Va, _, _, Nat_Va, _, _),
    valor(Area_Va, 'VA', Id_Va, Area_At, 'EL', Id_At, _, _, _, _, _, _, 'CO'),
    concepto(Area_At, 'EL', Id_At, Desc_At, _, _, Nat_At, _, _),
    asociacion( _, _, _, Area_Elem, Cat_Elem, Id_Elem, Area_At, 'EL', Id_At, _, _,_,_,_,_,_, _,_,_).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Signo puntuacion ==> 
convert(token(_, Area_Conj, 'GE', 'SIGN', ',', Val_fin, Fun),
        cjto_sem(
                 traza(
                      _                             %Origen
                 ),
                 token(
                       Area_Elem,                   % Area
                       Cat_Elem,                    % Categoria
                       Id_Elem                      % Identificador
                 ),
                 elemento(
                        Cat_Sem_1,                  % Cat Sem
                        _,                          % Id Semantico                       
                        _,                          % Cuantificador
                        _,                          % Polaridad
                        Desc_Elem,                  % Descripcion
                        Nat_Elem,                   % Naturaleza
                        valor(
                              _,                    % Valor_inicial
                              _,                    % Valor_final
                              _,                    % Funcion
                              _                     % Tipo de dato
                        )
                 ),
                 accion(
                        _,                          % Accion | Saludo | Salida | Ayuda
                        _,                          % Descripcion de la accion
                        _,                          % Objeto
                        _,                          % Orden
                        _                           % Periferico
                 ),
                 [
                          asoc(
                               traza(
                                     original              %Origen
                                ),
                               token(
                                     Area_Conj,            % Area Asociacion
                                     'GE',                 % Categoria Asociacion
                                     'SIGN'                % Id Asoc
                                ),
                                elemento(
                                     asociacion(Cat_Sem_1,Cat_Sem_2,coordinada), 
                                     _,                    % Tipo UML
                                     _,                    % Tipo de la Asociacion
                                     Desc_Conj,            % Descripcion de la Asociacion
                                     Nat_Conj,             % Naturaleza de la asociacion
                                     _,                    % Cardinalidad
                                     valor(
                                           ',',        % Valor inicial Asociacion
                                           Val_fin,        % Valor inicial Asociacion
                                           Fun,            % Valor inicial Asociacion                  
                                           _               % Valor inicial Asociacion                
                                     )
                                 ),
                                 cjto_sem(
                                          traza(
                                                _                             %Origen
                                          ),
                                          token(
                                                Area_Elem,                  % Area
                                                Cat_Elem,                   % Categoria
                                                Id_Elem                     % Identificador
                                          ),
                                          elemento(
                                                Cat_Sem_2,                  % Cat Sem
                                                _,                          % Id Semantico
                                                _,                          % Cuantificador
                                                _,                          % Polaridad
                                                Desc_Elem,                  % Descripcion
                                                Nat_Elem,                   % Naturaleza
                                                valor(
                                                      _,                    % Valor_inicial
                                                      _,                    % Valor_final
                                                      _,                    % Funcion
                                                      _                     % Tipo de dato
                                                )
                                          ),
                                          accion(
                                                _,                          % Accion | Saludo | Salida | Ayuda
                                                _,                          % Descripcion de la accion
                                                _,                          % Objeto
                                                _,                          % Orden
                                                _                           % Periferico
                                          ),
                                          []
                                 ) % fin cjto_sem
                          ) % fin asoc
                  ]
        )):-
     concepto(Area_Conj, 'GE', 'SIGN', Desc_Conj, _, _, Nat_Conj, _, _),
     !.


convert(token(_, _Area_Conj, 'GE', 'SIGN', _, _Val_fin, _Fun),nada).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reduccion ==> 
convert(token(_, _, 'RE', _, _, _, _),nada).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Orden ==> 
convert(token(_, Area, 'OR', Id, _, _, _),
        cjto_sem(
                 traza(
                      _                             %Origen
                 ),
                 token(
                       Area,                        % Area
                       'OR',                        % Categoria
                       Id                           % Identificador
                 ),
                 elemento(
                        _,                          % Cat Sem
                        _,                          % Id Semantico
                        _,                          % Cuantificador
                        _,                          % Polaridad
                        _,                          % Descripcion
                        _,                          % Naturaleza
                        valor(
                              _,                    % Valor_inicial
                              _,                    % Valor_final
                              _,                    % Funcion
                              _                     % Tipo de dato
                        )
                 ),
                 accion(
                        _,                          % Accion | Saludo | Salida | Ayuda
                        _,                          % Descripcion de la accion
                        _,                          % Objeto
                        Id,                         % Orden
                        _                           % Periferico
                 ),
                []
        )):-
   concepto(Area,'OR',Id,_,_,_,_,_,_).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Periferico ==> 
convert(token(_, Area, 'PE', Id, _, _, _),
        cjto_sem(
                 traza(
                      _                             %Origen
                 ),
                 token(
                       Area,                        % Area
                       'PE',                        % Categoria
                       Id                           % Identificador
                 ),
                 elemento(
                        _,                          % Cat Sem
                        _,                          % Id Semantico
                        _,                          % Cuantificador
                        _,                          % Polaridad
                        _,                          % Descripcion
                        _,                          % Naturaleza
                        valor(
                              _,                    % Valor_inicial
                              _,                    % Valor_final
                              _,                    % Funcion
                              _                     % Tipo de dato
                        )
                 ),
                 accion(
                        _,                          % Accion | Saludo | Salida | Ayuda
                        _,                          % Descripcion de la accion
                        _,                          % Objeto
                        _,                          % Orden
                        Id                          % Periferico
                 ),
                []
        )):-
   concepto(Area,'PE',Id,_,_,_,_,_,_).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Objeto ==> 
convert(token(_, Area, 'OB', Id, _, _, _),
        cjto_sem(
                 traza(
                      _                             %Origen
                 ),
                 token(
                       Area,                        % Area
                       'OB',                        % Categoria
                       Id                           % Identificador
                 ),
                 elemento(
                        _,                          % Cat Sem
                        _,                          % Id Semantico
                        _,                          % Cuantificador
                        _,                          % Polaridad
                        _,                          % Descripcion
                        _,                          % Naturaleza
                        valor(
                              _,                    % Valor_inicial
                              _,                    % Valor_final
                              _,                    % Funcion
                              _                     % Tipo de dato
                        )
                 ),
                 accion(
                        _,                          % Accion | Saludo | Salida | Ayuda
                        _,                          % Descripcion de la accion
                        Id,                         % Objeto
                        _,                          % Orden
                        _                           % Periferico
                 ),
                []
        )):-
   concepto(Area,'OB',Id,_,_,_,_,_,_).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Fallo ==> Fallo
convert(Token,fallo(Token)):-
%   format("[Debug]  ERROR:No se ha podido convertir: ~w~n",[Token]),
   fail.


