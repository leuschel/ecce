:-module(unificar,[es_elemento/1,
                   es_atributo/1,
                   unifica_lista_fase_1/2, 
	           unifica_lista_fase_2/2, 
		   unifica_lista_fase_3/3,
                   unifica_lista_fase_4/3]).

:-use_module(library(lists)).
:-use_module(library(sort)).
:-use_module(library(format)).

:-use_module(salida).
:-use_module(con_concepto).
:-use_module(val_valor).
:-use_module(aso_asociacion).
:-use_module(ele_elemento).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        unifica_lista
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       unifica[_lista]_fase_1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% hace unificacion simple: completa sem_sets, nada mas
% 
% 

unifica_lista_fase_1([], []).
unifica_lista_fase_1([E], [E]).
unifica_lista_fase_1([E_1, separador('fase 1',E_2)|Resto], [E_1,E_2|Resto_Unificado]):-
        !,
        unifica_lista_fase_1(Resto, Resto_Unificado).
unifica_lista_fase_1([separador('fase 1',E_1), E_2|Resto],[E_1|Resto_Unificado]):-
        !,
        unifica_lista_fase_1([E_2|Resto], Resto_Unificado).
unifica_lista_fase_1([E_1,E_2],[E_U]):-
        unifica_fase_1(E_1,E_2,E_U),
        !.
unifica_lista_fase_1([E_1,E_2],[E_1,E_2]):-
        !.
unifica_lista_fase_1([E_1|Resto], Lista_Unificada):-
        unifica_lista_fase_1(Resto, Resto_Unificado),
        Resto_Unificado = [E_2|Resto_Resto_Unificado],
        (unifica_fase_1(E_1, E_2, E_U)->
              Lista_Unificada = [E_U|Resto_Resto_Unificado]
         ;
              Lista_Unificada = [E_1,E_2|Resto_Resto_Unificado]
        ).

unifica_fase_1(falta, Cjto_Sem, Cjto_Sem).
unifica_fase_1(Cjto_Sem, falta, Cjto_Sem).
unifica_fase_1(nada, Cjto_Sem, Cjto_Sem).
unifica_fase_1(Cjto_Sem, nada, Cjto_Sem).

unifica_fase_1(Cjto_Sem_1, Cjto_Sem_2, Cjto_Sem_U):-
        Cjto_Sem_1 = cjto_sem(Traza_1, token(A1,C1,I1), Elem_1, Acc_1, []),
        Cjto_Sem_2 = cjto_sem(Traza_1, token(A2,C2,I2), Elem_1, Acc_1, Lista_Asoc_2),
        Cjto_Sem_U = cjto_sem(Traza_1, token([A1,A2],[C1,C2],[I1,I2]), Elem_1, Acc_1, Lista_Asoc_2).
                               
unifica_fase_1(Cjto_Sem_1, Cjto_Sem_2, Cjto_Sem_U):-
        Cjto_Sem_1 = cjto_sem(Traza_1, token(A1,C1,I1), Elem_1, Acc_1, Lista_Asoc_1),
        select(asoc(Tz_Asoc,Tk_Asoc,El_Asoc,Cjto_Sem_Sub), Lista_Asoc_1, Lista_Asoc_Resto_1),
        unifica_fase_1(Cjto_Sem_Sub,Cjto_Sem_2,Cjto_Sem_Sub_U),   
        Cjto_Sem_U = cjto_sem(Traza_1, token(A1,C1,I1), Elem_1, Acc_1, 
                              [asoc(Tz_Asoc,Tk_Asoc,El_Asoc,Cjto_Sem_Sub_U)|Lista_Asoc_Resto_1]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       unifica[_lista]_fase_2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% agrupa sem_sets de igual tipo en ....
%   si puede...eh! (si no puede, lo deja tal cual para la siguiente fase.
% Esta fase viene desde la dcha

unifica_lista_fase_2([],[]):-
        !.
unifica_lista_fase_2(L,[C_Elevada|Resto]):-
        unifica_lista_fase_2_aux(L,[C|Resto]),
        eleva(C,C_Elevada).

unifica_lista_fase_2_aux([], []).
unifica_lista_fase_2_aux([E], [E_Elevado]):-
        eleva(E,E_Elevado).
unifica_lista_fase_2_aux([E_1, separador('fase 2',E_2)|Resto], [E_1_Elevado,E_2_Elevado|Resto_Unificado]):-
        !,
        eleva(E_1,E_1_Elevado),
        eleva(E_2,E_2_Elevado),
        unifica_lista_fase_2_aux(Resto, Resto_Unificado).
unifica_lista_fase_2_aux([separador('fase 2',E_1), E_2|Resto],[E_1_Elevado|Resto_Unificado]):-
        !,
        eleva(E_1,E_1_Elevado),
        unifica_lista_fase_2_aux([E_2|Resto], Resto_Unificado).
unifica_lista_fase_2_aux([E_1,E_2],[E_U]):-
        unifica_fase_2(E_1,E_2,E_U),
        !.
unifica_lista_fase_2_aux([E_1,E_2],[E_1,E_2_Elevado]):-
        eleva(E_2,E_2_Elevado),
        !.
unifica_lista_fase_2_aux([E_1|Resto], Lista_Unificada):-
        unifica_lista_fase_2_aux(Resto, Resto_Unificado),
        Resto_Unificado = [E_2|Resto_Resto_Unificado],
        (unifica_fase_2(E_1, E_2, E_U)->
              Lista_Unificada = [E_U|Resto_Resto_Unificado]
         ;
              eleva(E_2,E_2_Elevado),
              Lista_Unificada = [E_1,E_2_Elevado|Resto_Resto_Unificado]
        ).

unifica_fase_2(falta, Cjto_Sem, Cjto_Sem).
unifica_fase_2(Cjto_Sem, falta, Cjto_Sem).
unifica_fase_2(nada, Cjto_Sem, Cjto_Sem).
unifica_fase_2(Cjto_Sem, nada, Cjto_Sem).

unifica_fase_2(Cjto_Sem_1, Cjto_Sem_2, Cjto_Sem_U):-
       Cjto_Sem_1 = cjto_sem(Traza_1, token(A1,C1,I1), Elem_1, Acc_1, Lista_Asoc_1),
       select(asoc(Tz_Asoc,Tk_Asoc,El_Asoc,Cjto_Sem_Sub),Lista_Asoc_1,Resto_Asoc_1),
       unifica_fase_2(Cjto_Sem_Sub,Cjto_Sem_2,Cjto_Sem_Sub_U),   
       !,
       Cjto_Sem_U = cjto_sem(Traza_1, token(A1,C1,I1), Elem_1, Acc_1, 
                              [asoc(Tz_Asoc,Tk_Asoc,El_Asoc,Cjto_Sem_Sub_U)|Resto_Asoc_1]).
         
unifica_fase_2(Cjto_Sem_1, Cjto_Sem_2, Cjto_Sem_U):-
       Cjto_Sem_1 = cjto_sem(Traza_1, token(A1,C1,I1), Elem_1, Acc_1, Lista_Asoc_1),
       Cjto_Sem_2 = cjto_sem(Traza_1, token(A2,C2,I2), Elem_1, Acc_1, Lista_Asoc_2),
       append(Lista_Asoc_1,Lista_Asoc_2,Lista_Asoc_U),
       Cjto_Sem_U = cjto_sem(Traza_1, token([A1,A2],[C1,C2],[I1,I2]), Elem_1, Acc_1, Lista_Asoc_U).
                          
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         unifica[_lista]_fase_3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

unifica_lista_fase_3([], [], 0).
unifica_lista_fase_3([E], [E], 0).
unifica_lista_fase_3([E_1, separador('fase 3',E_2)|Resto], [E_1,E_2|Resto_Unificado], Coste):-
        !,
        unifica_lista_fase_3(Resto, Resto_Unificado, Coste).
unifica_lista_fase_3([separador('fase 3',E_1), E_2|Resto],[E_1|Resto_Unificado], Coste):-
        !,
        unifica_lista_fase_3([E_2|Resto], Resto_Unificado, Coste).


%%%%%%%%%%%%%% De Dcha a Izda

unifica_lista_fase_3([E_1,E_2],[E_U], Coste):-
        unifica_fase_3_subordinada(E_1,E_2,E_U,Coste),
        !.

unifica_lista_fase_3([E_1|Resto], Lista_Unificada, Coste_Total):-
        unifica_lista_fase_3(Resto, Resto_Unificado, Coste_Parcial),
        Resto_Unificado = [E_2|Resto_Resto_Unificado],
        unifica_fase_3_subordinada(E_1,E_2,E_U,Coste_Unitario),
        !,
        Coste_Total is Coste_Unitario + Coste_Parcial,
        Lista_Unificada = [E_U|Resto_Resto_Unificado].

unifica_lista_fase_3([E_1|Resto], Lista_Unificada, Coste):-
        unifica_lista_fase_3(Resto, Resto_Unificado, Coste),
        Lista_Unificada = [E_1|Resto_Unificado].


%%%%%%%%%%%%%% De Izda a Dcha
/*
unifica_lista_fase_3([E_1,E_2|Resto],Lista_Unificada, Coste_Total):-
        unifica_fase_3_subordinada(E_1,E_2,E_U, Coste_Parcial),
        !,
        unifica_lista_fase_3([E_U|Resto], Lista_Unificada, Coste_Resto),
        Coste_Total is Coste_Parcial + Coste_Resto.

unifica_lista_fase_3([E_1,E_2|Resto], [E_1|Lista_Unificada], Coste):-
        unifica_lista_fase_3([E_2|Resto],Lista_Unificada, Coste).

*/
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       unifica_fase_3_subordinada
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
unifica_fase_3_subordinada(Cjto_Sem_1, Cjto_Sem_2, Cjto_Sem_U,Coste_Fin):-
%       format("[Debug] (sub)   Peticion de unificacion subordinada~n",[]),
%       write_sem_set(Cjto_Sem_1,7),
%       write_sem_set(Cjto_Sem_2,7),
       unifica_fase_3(Cjto_Sem_1,Cjto_Sem_2,Cjto_Sem_Directo,Coste),
%       format("[Debug] (sub)   Coste + Resultado (previo) Unificacion directa:~w~n",[Coste]),
%       write_sem_set(Cjto_Sem_Directo,8),
       Cjto_Sem_1 = cjto_sem(Tr_1,Tk_1,El_1,Acc_1,Lista_Asoc_1),
       (Coste=1 ->
%            format("[Debug] (sub)   Coste 1: unificacion directa~n",[]),
            Coste_Fin = 1,
            Cjto_Sem_U = Cjto_Sem_Directo
%            ,format("[Debug] (sub)   RESULTADO:~n",[]),
%             write_sem_set(Cjto_Sem_U,8)
        ;
            (Lista_Asoc_1 = [] ->
%                   format("[Debug] (sub)   Sin subordinadas: unificacion directa~n",[]),
                   Coste_Fin = Coste,
                   Cjto_Sem_U = Cjto_Sem_Directo
%                    ,format("[Debug] (sub)   RESULTADO:~n",[]),
%                    write_sem_set(Cjto_Sem_U,8)
            ;     
                   map_fase_3(Lista_Asoc_1,Cjto_Sem_2,Lista_Asoc_Coste),
%		   format("[Debug] SORT: unifica fase 3 subordinada:~w~n",[Lista_Asoc_Coste]),
                   sort(Lista_Asoc_Coste,[(Coste_Sub,asoc(Tr_A,Tk_A,El_A,Cjto_Sem_Sub))|_]),
                   (Coste_Sub < Coste ->
%                              format("[Debug] (sub)   Mapeo: unificacion subordinada~n",[]), 
                              select(asoc(Tr_A,Tk_A,El_A,Cjto_Sem_Sub),Lista_Asoc_1,Resto_Asoc),
%                              format("[Debug] (sub)        : asociacion elegida ~w~n",[Tk_A]),
                              unifica_fase_3_subordinada(Cjto_Sem_Sub,Cjto_Sem_2,Cjto_Sem_Sub_U,Coste_Sub),
                              Coste_Fin = Coste_Sub,
                              Cjto_Sem_U = cjto_sem(Tr_1,Tk_1,El_1,Acc_1,[asoc(Tr_A,Tk_A,El_A,Cjto_Sem_Sub_U)|Resto_Asoc])
%                               ,format("[Debug] (sub)   RESULTADO:~n",[]),
%                              write_sem_set(Cjto_Sem_U,8)
                    ;
%                              format("[Debug] (sub)   Mapeo: unificacion con el padre (Coste)~n",[]),
                              Coste_Fin = Coste,
                              Cjto_Sem_U =  Cjto_Sem_Directo
%                               ,format("[Debug] (sub)   RESULTADO:~n",[]),
%                              write_sem_set(Cjto_Sem_U,8)
                    )
             )
       ).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         unifica_fase_3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
unifica_fase_3(falta, Cjto_Sem, Cjto_Sem,0).
unifica_fase_3(Cjto_Sem, falta, Cjto_Sem,0).
unifica_fase_3(nada, Cjto_Sem, Cjto_Sem,0).
unifica_fase_3(Cjto_Sem, nada, Cjto_Sem,0).
         
%    id_1 ground & id_2 ground
unifica_fase_3(Cjto_Sem_1, Cjto_Sem_2, Cjto_Sem_U,Coste):-
       id_semantica(Cjto_Sem_1,elemento(Tk_1)),
       id_semantica(Cjto_Sem_2,elemento(Tk_2)),
       ground(Tk_1),
       ground(Tk_2),
       !,
       caminos_minimos(Tk_1,Tk_2,Caminos,Coste),
       select(Camino,Caminos,_),
       forma_camino(Cjto_Sem_1,Cjto_Sem_2,Camino,Cjto_Sem_U).

%    id_1 ground & id_2 var
unifica_fase_3(Cjto_Sem_1, Cjto_Sem_2, Cjto_Sem_U,Coste):-
       id_semantica(Cjto_Sem_1,elemento(Tk_1)),
       categoria_semantica(Cjto_Sem_2,elemento(Tk_2)),
       ground(Tk_1),
       ground(Tk_2),
       Cjto_Sem_2 = cjto_sem( _, _, _, _,[asoc(Tr_A,Tk_A,El_A,Cjto_Sem_Coord)]),
       !,
       fail,
       id_semantica(Cjto_Sem_Coord, elemento(Tk_S)),
       caminos_minimos(Tk_1, Tk_S, Caminos, Coste),
       select(Camino, Caminos, _),
       Cjto_Sem_1 = cjto_sem(Tr_1, Token_1, El_1, Acc_1, Lista_Asoc_1),
       Cjto_Sem_1_Coord = cjto_sem(Tr_1, Token_1, El_1, Acc_1, []),
%       format("[Debug]    Formando camino entre:~n",[]),
%       write_sem_set(Cjto_Sem_1_Coord,8),
%       write_sem_set(Cjto_Sem_Coord,8),
       forma_camino( Cjto_Sem_1_Coord, Cjto_Sem_Coord, Camino, Cjto_Sem_Coord_U),
%       format("[Debug]    Camino Formado:~n",[]),
%       write_sem_set(Cjto_Sem_Coord_U,8),
       Cjto_Sem_U = cjto_sem(Tr_1, Token_1, El_1, Acc_1, [asoc(Tr_A, Tk_A, El_A, Cjto_Sem_Coord_U)|Lista_Asoc_1]).

unifica_fase_3(_Cjto_Sem_1, _Cjto_Sem_2, _Cjto_Sem_U,9999).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         map_fase_3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
map_fase_3([],_,[]).
map_fase_3([asoc(Tr,Tk,El,Cjto_Sem)|Resto],Cjto_Sem_2,[(Coste,asoc(Tr,Tk,El,Cjto_Sem))|Resto_Map]):-
       unifica_fase_3(Cjto_Sem,Cjto_Sem_2,_,Coste),
%       format("[Debug] mapeando coste: ~w~n",[Coste]),
       map_fase_3(Resto, Cjto_Sem_2, Resto_Map).



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         unifica[_lista]_fase_4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

unifica_lista_fase_4([], [], 0).
unifica_lista_fase_4([E], [E], 0).
unifica_lista_fase_4([E_1, separador('fase 3',E_2)|Resto], [E_1,E_2|Resto_Unificado], Coste):-
        !,
        unifica_lista_fase_4(Resto, Resto_Unificado,Coste).
unifica_lista_fase_4([separador('fase 3',E_1), E_2|Resto], [E_1|Resto_Unificado], Coste):-
        !,
        unifica_lista_fase_4([E_2|Resto], Resto_Unificado, Coste).


%%%%%%%%%%%%%% De Dcha a Izda
unifica_lista_fase_4([E_1,E_2], [E_U], Coste):-
        unifica_fase_4_subordinada(E_1, E_2, E_U, Coste),
        !.

unifica_lista_fase_4([E_1|Resto], Lista_Unificada, Coste_Total):-
        unifica_lista_fase_4(Resto, Resto_Unificado, Coste_Parcial),
        Resto_Unificado = [E_2|Resto_Resto_Unificado],
        unifica_fase_4_subordinada(E_1,E_2,E_U, Coste_Unitario),
        !,
        Coste_Total is Coste_Parcial + Coste_Unitario,
        Lista_Unificada = [E_U|Resto_Resto_Unificado].

unifica_lista_fase_4([E_1|Resto], Lista_Unificada, Coste):-
        unifica_lista_fase_4(Resto, Resto_Unificado, Coste),
        Lista_Unificada = [E_1|Resto_Unificado].

/*
%%%%%%%%%%%%%% De Izda a Dcha
unifica_lista_fase_4([E_1,E_2|Resto],Lista_Unificada):-
        unifica_fase_4_subordinada(E_1,E_2,E_U, _Coste),
        !,
        unifica_lista_fase_4([E_U|Resto], Lista_Unificada).

unifica_lista_fase_4([E_1,E_2|Resto], [E_1|Lista_Unificada]):-
        unifica_lista_fase_4([E_2|Resto],Lista_Unificada).
*/

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%       unifica_fase_4_subordinada
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
unifica_fase_4_subordinada(Cjto_Sem_1, Cjto_Sem_2, Cjto_Sem_U, Coste_Final):-
%       format("[Debug] (sub)   Peticion de unificacion subordinada~n",[]),
%       write_sem_set(Cjto_Sem_1,7),
%       write_sem_set(Cjto_Sem_2,7),
       unifica_fase_4(Cjto_Sem_1,Cjto_Sem_2,Cjto_Sem_Directo,Coste),
%       format("[Debug] (sub)   Coste + Resultado (previo) Unificacion directa:~w~n",[Coste]),
%       write_sem_set(Cjto_Sem_Directo,8),
       Cjto_Sem_1 = cjto_sem(Tr_1,Tk_1,El_1,Acc_1,Lista_Asoc_1),
       (Coste=1 ->
%            format("[Debug] (sub)   Coste 1: unificacion directa~n",[]),
            Coste_Final = 1,
            Cjto_Sem_U = Cjto_Sem_Directo
%            ,format("[Debug] (sub)   RESULTADO:~n",[]),
%             write_sem_set(Cjto_Sem_U,8)
        ;
            (Lista_Asoc_1 = [] ->
%                   format("[Debug] (sub)   Sin subordinadas: unificacion directa~n",[]),          
                   Coste_Final = Coste,
                   Cjto_Sem_U = Cjto_Sem_Directo
%                    ,format("[Debug] (sub)   RESULTADO:~n",[]),
%                    write_sem_set(Cjto_Sem_U,8)
            ;     
                   map_fase_4(Lista_Asoc_1,Cjto_Sem_2,Lista_Asoc_Coste),
%		   format("[Debug] SORT: unifica fase 4 subordinada:~w~n",[Lista_Asoc_Coste]),
                   sort(Lista_Asoc_Coste,[(Coste_Sub,asoc(Tr_A,Tk_A,El_A,Cjto_Sem_Sub))|_]),
                   (Coste_Sub < Coste ->
%                              format("[Debug] (sub)   Mapeo: unificacion subordinada~n",[]), 
                              select(asoc(Tr_A,Tk_A,El_A,Cjto_Sem_Sub),Lista_Asoc_1,Resto_Asoc),
%                              format("[Debug] (sub)        : asociacion elegida ~w~n",[Tk_A]),
                              unifica_fase_4_subordinada(Cjto_Sem_Sub,Cjto_Sem_2,Cjto_Sem_Sub_U, Coste_Sub),
                              Coste_Final = Coste_Sub,
                              Cjto_Sem_U = cjto_sem(Tr_1,Tk_1,El_1,Acc_1,[asoc(Tr_A,Tk_A,El_A,Cjto_Sem_Sub_U)|Resto_Asoc])
%                               ,format("[Debug] (sub)   RESULTADO:~n",[]),
%                              write_sem_set(Cjto_Sem_U,8)
                    ;
%                              format("[Debug] (sub)   Mapeo: unificacion con el padre (Coste)~n",[]),
                              Coste_Final = Coste,
                              Cjto_Sem_U =  Cjto_Sem_Directo
%                               ,format("[Debug] (sub)   RESULTADO:~n",[]),
%                              write_sem_set(Cjto_Sem_U,8)
                    )
             )
       ).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         unifica_fase_4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
unifica_fase_4(falta, Cjto_Sem, Cjto_Sem,0).
unifica_fase_4(Cjto_Sem, falta, Cjto_Sem,0).
unifica_fase_4(nada, Cjto_Sem, Cjto_Sem,0).
unifica_fase_4(Cjto_Sem, nada, Cjto_Sem,0).
         
%    id_1 ground & id_2 ground

unifica_fase_4(Cjto_Sem_1, Cjto_Sem_2, Cjto_Sem_U, Coste):-
       id_semantica(Cjto_Sem_1,elemento(Tk_1)),
       id_semantica(Cjto_Sem_2,elemento(Tk_2)),
       ground(Tk_1),
       ground(Tk_2),
       !,
       caminos_minimos(Tk_1,Tk_2,Caminos,Coste),
       select(Camino,Caminos,_),
       forma_camino(Cjto_Sem_1,Cjto_Sem_2,Camino,Cjto_Sem_U).

%    id_1 ground & id_2 var
unifica_fase_4(Cjto_Sem_1, Cjto_Sem_2, Cjto_Sem_U, Coste):-
       id_semantica(Cjto_Sem_1,elemento(Tk_1)),
       categoria_semantica(Cjto_Sem_2,elemento(Tk_2)),
       ground(Tk_1),
       ground(Tk_2),
       Cjto_Sem_2 = cjto_sem( _, _, _, _,[asoc(Tr_A,Tk_A,El_A,Cjto_Sem_Coord)]),
       !,
       id_semantica(Cjto_Sem_Coord, elemento(Tk_S)),
       caminos_minimos(Tk_1, Tk_S, Caminos, Coste),
       select(Camino, Caminos, _),
       Cjto_Sem_1 = cjto_sem(Tr_1, Token_1, El_1, Acc_1, Lista_Asoc_1),
       Cjto_Sem_1_Coord = cjto_sem(Tr_1, Token_1, El_1, Acc_1, []),
%       format("[Debug]    Formando camino entre:~n",[]),
%       write_sem_set(Cjto_Sem_1_Coord,8),
%       write_sem_set(Cjto_Sem_Coord,8),
       forma_camino( Cjto_Sem_1_Coord, Cjto_Sem_Coord, Camino, Cjto_Sem_Coord_U),
%       format("[Debug]    Camino Formado:~n",[]),
%       write_sem_set(Cjto_Sem_Coord_U,8),
       Cjto_Sem_U = cjto_sem(Tr_1, Token_1, El_1, Acc_1, [asoc(Tr_A, Tk_A, El_A, Cjto_Sem_Coord_U)|Lista_Asoc_1]).

unifica_fase_4(_Cjto_Sem_1, _Cjto_Sem_2, _Cjto_Sem_U,9999).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         map_fase_4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
map_fase_4([],_,[]).
map_fase_4([asoc(Tr,Tk,El,Cjto_Sem)|Resto],Cjto_Sem_2,[(Coste,asoc(Tr,Tk,El,Cjto_Sem))|Resto_Map]):-
       unifica_fase_4(Cjto_Sem,Cjto_Sem_2,_,Coste),
       map_fase_4(Resto, Cjto_Sem_2, Resto_Map).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         forma_camino
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

forma_camino(Cjto_Sem_O, _, [], Cjto_Sem_O):-
       !.
forma_camino( Cjto_Sem_O, Cjto_Sem_D, [_], Cjto_Sem_U):-
       Cjto_Sem_O = cjto_sem(_,_,El,Acc,Lista_Asoc_O),
       Cjto_Sem_D = cjto_sem(Tr,Tk,El,Acc,Lista_Asoc_D),
       append(Lista_Asoc_O, Lista_Asoc_D, Lista_Asoc_U),
       Cjto_Sem_U = cjto_sem(Tr,Tk,El,Acc,Lista_Asoc_U), 
       !.
forma_camino(_Cjto_Sem_O, Cjto_Sem_D, [_,_], Cjto_Sem_D):-
       !.
forma_camino(Cjto_Sem_O, Cjto_Sem_Des, [Tk_O,Tk_As,Tk_D|Resto],Cjto_Sem_Cam):-
       Cjto_Sem_O = cjto_sem(Tr_O, 
                             Token_O,
                             elemento(Cat_Sem_O,elemento(Tk_O),Cuan_O,Pol_O,Desc_O,Nat_O,Val_O),
                             Acc_O, 
                             Lista_Asoc_O),
       Cjto_Sem_D = cjto_sem(traza(_),Tk_D,elemento(elemento(Tk_D),elemento(Tk_D),_,_,Desc_D,Nat_D,_),_,[]),
       forma_camino(Cjto_Sem_D,Cjto_Sem_Des,[Tk_D|Resto], Cjto_Sem_Cam_Resto),   
       Tk_As = token(Area_As,Cat_As,Id_As),
       asociacion(Area_As,Cat_As,Id_As,Area_O,Cat_O,Id_O,Area_D,Cat_D,Id_D,Card,_,_,_,_,_,_,UML,Tipo,_),
       concepto(Area_As,Cat_As,Id_As,Desc_As,_,_,Nat_As,_,_),
       concepto(Area_O,Cat_O,Id_O,_Desc_O,_,_,_Nat_O,_,_),
       concepto(Area_D,Cat_D,Id_D,Desc_D,_,_,Nat_D,_,_),
       Cjto_Sem_Cam = cjto_sem(Tr_O, 
                               Token_O,
                               elemento(Cat_Sem_O,elemento(Tk_O),Cuan_O,Pol_O,Desc_O,Nat_O,Val_O), 
                               Acc_O, 
                 [asoc(traza(_),
                       Tk_As, 
                       elemento(asociacion(Tk_O,Tk_D,subordinada),UML,Tipo,Desc_As,Nat_As,Card,_),
                       Cjto_Sem_Cam_Resto)
                  |Lista_Asoc_O]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         eleva
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eleva(Elemento,Elemento):-
        id_semantica(Elemento,IdS),
        ground(IdS),
        IdS = elemento(_).
       
eleva(Elemento,Elemento_Elevado):-
        id_semantica(Elemento,Id_Semantica),
        ground(Id_Semantica),
        Id_Semantica = valor(_,token(Area_At,Cat_At,Id_At),token(Area_El,Cat_El,Id_El)),
        !,
        asociacion(Area_As,Cat_As,Id_As,Area_El,Cat_El,Id_El,Area_At,Cat_At,Id_At,Card,_,_,_, _,_,_, Tipo_UML,Tipo,_),
        concepto(Area_As,Cat_As,Id_As,Desc_As,_,_,Nat_As,_,_),
        concepto(Area_El,Cat_El,Id_El,Desc_El,_,_,Nat_El,_,_),
        Elemento = cjto_sem(_,_,_,Accion_El,_),
        Elemento_Elevado = cjto_sem(
                                    traza(_),
                                    token(Area_El,Cat_El,Id_El),
                                    elemento(elemento(token(Area_El,Cat_El,Id_El)),
                                             elemento(token(Area_El,Cat_El,Id_El)),_,_,Desc_El,Nat_El,Valor),
                                    Accion_El,
                                    [asoc(
                                          traza(_),
                                          token(Area_As,Cat_As,Id_As),
                                          elemento(asoc(token(Area_El,Cat_El,Id_El),token(Area_At,Cat_At,Id_At),subordinada),
                                                   Tipo_UML,Tipo,Desc_As,Nat_As,Card,Valor),
                                          Elemento)]).
eleva(Elemento,Elemento_Elevado):-
        id_semantica(Elemento,Id_Semantica),
        ground(Id_Semantica),
        Id_Semantica = atributo(token(Area_At,Cat_At,Id_At),token(Area_El,Cat_El,Id_El)),
        !,
        asociacion(Area_As,Cat_As,Id_As,Area_El,Cat_El,Id_El,Area_At,Cat_At,Id_At,Card,_,_,_,_,_,_,Tipo_UML,Tipo,_),
        concepto(Area_As,Cat_As,Id_As,Desc_As,_,_,Nat_As,_,_),
        concepto(Area_El,Cat_El,Id_El,Desc_El,_,_,Nat_El,_,_),
        Elemento_Elevado = cjto_sem(
                                    traza(_),
                                    token(Area_El,Cat_El,Id_El),
                                    elemento(elemento(token(Area_El,Cat_El,Id_El)),
                                             elemento(token(Area_El,Cat_El,Id_El)),_,_,Desc_El,Nat_El,Valor),
                                    accion(_,_,_,_,_),
                                    [asoc(
                                          traza(_),
                                          token(Area_As,Cat_As,Id_As),
                                          elemento(asoc(token(Area_El,Cat_El,Id_El),token(Area_At,Cat_At,Id_At),subordinada),
                                                   Tipo_UML,Tipo,Desc_As,Nat_As,Card,Valor),
                                          Elemento)]).

eleva(Elemento,Elemento_Elevado):-
        categoria_semantica(Elemento,Cat_Semantica),
        ground(Cat_Semantica),
        Cat_Semantica = atributo(_),
        Elemento = cjto_sem(_,_,elemento(_,_,_,_,_,_,Valor),_,[asoc(Tr_A,Tk_A,El_A,Cjto_Sem_Coord)]),
        !,
        eleva(Cjto_Sem_Coord, Cjto_Sem_Coord_Elevado),
        categoria_semantica(Cjto_Sem_Coord_Elevado, Cat_Semantica_Elevada),
        Cjto_Sem_Coord_Elevado = cjto_sem(_,_,elemento(_,_,_,_,_,_,Valor),_,_),
        Elemento_Elevado = cjto_sem(
                                    traza(_),
                                    token(_,_,_),
                                    elemento(Cat_Semantica_Elevada,_,_,_,_,_,Valor),
                                    accion(_,_,_,_,_),
                                    [asoc(Tr_A, Tk_A, El_A, Cjto_Sem_Coord_Elevado)]).
                                                                      
eleva(Elemento,Elemento).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%      es_elemento | es_atributo (token | cjto_sem)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
es_elemento(token(Area,Categoria,Id)):-
   asociacion(_,_,_,Area,Categoria,Id,_,_,_,_,_,_,_,_,_,_, _,_,_).

es_elemento(cjto_sem(_,token(Area,Categoria,Id),_,_,_)):-
   asociacion(_,_,_,Area,Categoria,Id,_,_,_,_,_,_,_,_,_,_, _,_,_).

es_elemento(token(Area,Categoria,Id)):-
   \+asociacion(_,_,_,Area,Categoria,Id,_,_,_,_,_,_,_,_,_,_,_,_,_),
   \+asociacion(_,_,_,_,_,_,Area,Categoria,Id,_,_,_,_,_,_,_,_,_,_).

es_elemento(cjto_sem(_,token(Area,Categoria,Id),_,_,_)):-
   \+asociacion(_,_,_,Area,Categoria,Id,_,_,_,_,_,_,_,_,_,_,_,_,_),
   \+asociacion(_,_,_,_,_,_,Area,Categoria,Id,_,_,_,_,_,_,_,_,_,_).

es_atributo(token(Area,Categoria,Id)):-
   \+asociacion(_,_,_,Area,Categoria,Id,_,_,_,_,_,_,_,_,_,_,_,_,_).

es_atributo(cjto_sem(_,token(Area,Categoria,Id),_,_,_)):-
   \+asociacion(_,_,_,Area,Categoria,Id,_,_,_,_,_,_,_,_,_,_,_,_,_).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    categoria_semantica / id_semantica
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
categoria_semantica(cjto_sem(_,_,elemento(CS,_,_,_,_,_,_),_,_),CS).
id_semantica(cjto_sem(_,_,elemento(_,IdS,_,_,_,_,_),_,_),IdS).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        caminos_minimos
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

caminos_minimos(Elemento_O, Elemento_D, Caminos_Minimos,Coste):-
    todos_caminos(Elemento_O, Elemento_D, Todos_Caminos),
    minima_longitud(Todos_Caminos, 9999, Minima_Long),
    filtra_long(Todos_Caminos, Minima_Long, Caminos_Minimos),
    Coste = Minima_Long.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
filtra_long([],_,[]).
filtra_long([Camino|Resto],Long,[Camino|Resto_Filtro]):-
    calcula_coste(Camino,Long),
    !,
    filtra_long(Resto,Long,Resto_Filtro).
filtra_long([_Camino|Resto],Long,Resto_Filtro):-
    filtra_long(Resto,Long,Resto_Filtro).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
minima_longitud([],Min,Min).
minima_longitud([Camino|Resto],Min_Prev,Min):-
    calcula_coste(Camino, Long),
    %format("[Debug] Calculando minima longitud de: ~w [~w]~n",[Camino, Long]),
    Long < Min_Prev,
    !,
    minima_longitud(Resto,Long,Min).
minima_longitud([_Camino|Resto],Min_Prev,Min):-
     minima_longitud(Resto,Min_Prev,Min).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
calcula_coste([],0):-
	!.

calcula_coste([token(Area,'AS',Id)|Resto],Coste):-
        asociacion(Area,'AS',Id,Area_O,Cat_O,Id_O,Area_D,Cat_D,Id_D,    _, _,_,_, _,_,_, _,_,_),
        asociacion(   _,  _,  _,Area_D,Cat_D,Id_D,Area_O,Cat_O,Id_O, Card, _,_,_, _,_,_, UML,_,_),
        ground(Card),
        ground(UML),
        Card = '01',
        UML = 'C',
        !,
        calcula_coste(Resto, Coste). 

calcula_coste([token(Area,'AS',Id)|Resto],Coste):-
        asociacion(Area,'AS',Id,Area_O,Cat_O,Id_O,Area_D,Cat_D,Id_D,    _, _,_,_, _,_,_, _,_,_),
        asociacion(   _,  _,  _,Area_D,Cat_D,Id_D,Area_O,Cat_O,Id_O, Card, _,_,_, _,_,_, UML,_,_),
        ground(Card),
        ground(UML),
        Card = '11',
        UML = 'C',
        !,
        calcula_coste(Resto, Coste). 

calcula_coste([_|Resto],Coste):-
        calcula_coste(Resto, Coste_Parcial),
        Coste is Coste_Parcial + 1.


todos_caminos(Elemento_O, Elemento_D, Todos_Caminos):-
    findall(Camino,camino(Elemento_O,Elemento_D,Camino),Todos_Caminos).

camino(Elemento_O, Elemento_D, [Elemento_O|Camino]):-
    camino_aux(Elemento_O,Elemento_D,[Elemento_O],Camino).

camino_aux(Elemento, Elemento, _,[]):-
    !.
camino_aux(Elemento_Origen, Elemento_Destino, Lista_Visitados, [Asoc,Elemento_Adyacente|Resto_Camino]):-
    adyacente(Elemento_Origen, Elemento_Adyacente,Asoc),
    \+member(Elemento_Adyacente, Lista_Visitados),
    camino_aux(Elemento_Adyacente, Elemento_Destino, [Elemento_Adyacente|Lista_Visitados], Resto_Camino).
    
adyacente(token(Area_O,Cat_O,Id_O),token(Area_A,Cat_A,Id_A),token(Area_As,Cat_As,Id_As)):-
    asociacion(Area_As,Cat_As,Id_As,Area_O,Cat_O,Id_O,Area_A,Cat_A,Id_A,_,_,_,_,_,_,_, _,_,_).
    


