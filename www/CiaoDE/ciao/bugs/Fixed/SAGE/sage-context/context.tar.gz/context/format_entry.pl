

:-use_module(library(lists)).
:-use_module(library(format)).

:-ensure_loaded('frases/entry.pl').

convierte_entry_num(Num):-
        entry(Num, Frase, Lista_Tokens),
        name('frases/frase', L_frase),
        name(Num, L_Num),
        append(L_frase, L_Num, L_Nombre),
        name(Nombre, L_Nombre),
        open(Nombre, write, S),
        set_output(S),
        convierte_entry(Frase, Lista_Tokens),
        close(S).

convierte_entry(Frase, Lista_Tokens):-
         format("frase(\"~w\").~n",[Frase]),
         map_biff(Lista_Tokens, Lista_Arcos, Lista_Nodos, 0),
         format("arcos([(ini:0,asoc([0:0]))|~w]).~n",[Lista_Arcos]),
	 format("nodos(~w).~n",[Lista_Nodos]).


map_biff([(Tk,Vi,Vf,F)],[(asoc([N:N]),fin:0)],[(asoc([N:N]),[(Tk_Q_String,Vi,Vf,F)],
									  _,_,_,_,_,_,_,_,
									  _,
									  _)],N):-
         wrap_to_atom(Tk,'"',Tk_Q_String),
	 !.

	
map_biff([(Tk,Vi,Vf,F)|Resto], [(asoc([N:N]),asoc([N1:N1]))|Resto_Arcos],[(asoc([N:N]),
	                                                                 [(Tk_Q_String,Vi,Vf,F)],
									  _,_,_,_,_,_,_,_,
									  _,
									  _)|Resto_Nodos],N):-
         N1 is N +1,
         wrap_to_atom(Tk,'"',Tk_Q_String),
	 map_biff(Resto,Resto_Arcos,Resto_Nodos,N1).
	 

wrap_to_atom(List,Atom,W_Atom):-
	name(Atom,Atom_List),
        append(Atom_List,List,Prefix_List),
        append(Prefix_List,Atom_List,Whole_List),
        name(W_Atom,Whole_List).
























