:-module(acc_accion,[accion/7]).

accion('BAS0','AC','0001','EL',_,_,_).
accion('BAS0','AC','0002','EL',_,_,_).
accion('BAS0','AC','0003','EL',_,_,_).
accion('BAS0','AC','0004','EL',_,_,_).
accion('BAS0','AC','0005','EL',_,_,_).
accion('BAS0','AC','0006','EL',_,_,_).
accion('BAS0','AC','0007','EL',_,_,_).
accion('BAS0','AC','EXIT',_,'BAS0','GE','GNBD').
accion('BAS0','AC','HELP','EL','BAS0','GE','GNBD').
accion('BAS0','AC','SALU',_,'BAS0','GE','GNBD').
