
:-module(contexto,[
	           run_contexto/0, 
		   main/0, 
		   mainf/1,
		   mainff/1,
            	   leer_entradas/3, 
		   map_entradas/2,
		   convert_list_fich/3
		  ]).

:-use_module(library(lists)).
:-use_module(library(prolog_sys)).
:-use_module(library(system)).

:-use_module(library(format)).
:-use_module(library(sort)).

:-use_module(salida).
:-use_module(unificar).
:-use_module(convertir).
:-use_module(con_concepto).
:-use_module(val_valor).
:-use_module(aso_asociacion).
:-use_module(ele_elemento).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%         run_conexto  (Para llamarlo desde un programa prolog)
%                       con frase(...), nodos(....) arcos(...) asertados
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
run_contexto:-
	leer_entradas_ass(Frase, Lista_Entradas),
        length(Lista_Entradas,Num_Entradas),
        format("Numero total de entradas: ~w~n",[Num_Entradas]),
        map_entradas(Lista_Entradas, Lista_Coste_Salida), 
        length(Lista_Coste_Salida, Num_Salida),
        format("Numero total de soluciones: ~w~n",[Num_Salida]),
        sort(Lista_Coste_Salida, Lista_S),
        (Lista_S = [] ->
                map_write_token_list(Lista_Entradas),
                format("No hay solucion ~n",[])
         ;
                primeras_N(Lista_S,10,Lista_S_N),
                length(Lista_S_N,Num_Red),
                format("Ensenyando ~w primeras soluciones: ~n",[Num_Red]),
                map_write_solution(Frase,9999,  Lista_S_N)
        ).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%           main  (Para llamarlo desde fuera con ficheros)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
main:-
       open('context_output.txt',write,S),
       set_output(S),
       mainf('context_input.txt'),
       close(S),
       halt.
   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%          mainf
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mainf(Fichero):-
        leer_entradas(Fichero, Frase, Lista_Entradas),
        length(Lista_Entradas,Num_Entradas),
        format("Numero total de entradas: ~w~n",[Num_Entradas]),
        map_entradas(Lista_Entradas, Lista_Coste_Salida), 
        length(Lista_Coste_Salida, Num_Salida),
        format("Numero total de soluciones: ~w~n",[Num_Salida]),
        sort(Lista_Coste_Salida, Lista_S),
        (Lista_Coste_Salida = [] ->
                map_write_token_list(Lista_Entradas),
                format("No hay solucion ~n",[])
         ;
                primeras_N(Lista_S,10,Lista_S_N),
                length(Lista_S_N,Num_Red),
                format("Ensenyando ~w primeras soluciones: ~n",[Num_Red]),
                map_write_solution(Frase,9999,  Lista_S_N)
        ).
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%          mainff
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mainff(Fichero_Entrada):-
	atom_codes(Fichero_Entrada, Lista_Fichero_Entrada),
        atom_codes('.out', Lista_Extension),
        append(Lista_Fichero_Entrada, Lista_Extension, Lista_Fichero_Salida),
        atom_codes(Fichero_Salida, Lista_Fichero_Salida),
	open(Fichero_Salida, write, S),
        set_output(S),
        leer_entradas(Fichero_Entrada, Frase, Lista_Entradas),
        length(Lista_Entradas,Num_Entradas),
        format("Numero total de entradas: ~w~n",[Num_Entradas]),
        map_entradas(Lista_Entradas, Lista_Coste_Salida), 
        length(Lista_Coste_Salida, Num_Salida),
        format("Numero total de soluciones: ~w~n",[Num_Salida]),
        sort(Lista_Coste_Salida, Lista_S),
        (Lista_Coste_Salida = [] ->
                map_write_token_list(Lista_Entradas),
                format("No hay solucion ~n",[]),
		close(S)
         ;
                primeras_N(Lista_S,10,Lista_S_N),
                length(Lista_S_N,Num_Red),
                format("Ensenyando ~w primeras soluciones: ~n",[Num_Red]),
                map_write_solution(Frase,9999,  Lista_S_N),
                close(S)
        ).
   

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        map_entradas
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
map_entradas([],[]).
map_entradas([Entrada|Resto], Lista_Salida):-
	findall((Entrada,LU_0),
                convert_list_fich(0,Entrada,LU_0),
                Lista_Entrada_LU_0),
        %map_write_list(Lista_Entrada_LU_0),
        length(Lista_Entrada_LU_0, Numero_Entradas),
        format("Numero conversiones por entrada: ~w~n",[Numero_Entradas]),
        map_contexto(Lista_Entrada_LU_0, Lista_C_S_E),
        !,
        map_entradas(Resto, Resto_M),
        append(Lista_C_S_E,Resto_M,Lista_Salida).

map_entradas([_|Resto],Resto_M):-
        map_entradas(Resto, Resto_M).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        CONTEXTO
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

map_contexto([],[]).

map_contexto([(Tokens,Entrada)|Resto],Lista_Contexto):-
	contexto(Entrada,Salida,Coste),
	map_contexto(Resto,Resto_Contexto),
	Lista_Contexto = [(Coste, Salida, Entrada, Tokens)| Resto_Contexto].

/*        (Coste < 9999 -> 
              Lista_Contexto = [(Coste, Salida, Entrada, Tokens)|Resto_Con],
              map_contexto(Resto, Resto_Con)
         ;
              Lista_Contexto = Resto_Con,
              map_contexto(Resto,Resto_Con)
        ).
*/

contexto(L_Entrada, L_Salida, Coste):-
        unifica_lista_fase_1(L_Entrada,LU_1),
        unifica_lista_fase_2(LU_1,LU_2),
        unifica_lista_fase_3(LU_2,LU_3, Coste_Fase_3),
        unifica_lista_fase_4(LU_3,L_Salida, Coste_Fase_4),
        length(L_Salida, Num_Sem_Sets),
        (Num_Sem_Sets = 1 ->
                 Coste is Coste_Fase_3 + Coste_Fase_4
         ;
                 Coste = 9999
        ).
        

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        convert_list
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
convert_list(_,[],[]).

convert_list(Index,[Token|Tail_Token],[Elem|Tail_Elem]):-
	parse(Index,Token,Token_Parsed),
	convert(Token_Parsed,Elem),
        Index1 is Index + 1,
	convert_list(Index1,Tail_Token,Tail_Elem).

convert_list_fich(_,[],[]).

convert_list_fich(Index,[Token|Tail_Token],[Elem|Tail_Elem]):-
	parse_fich(Index,Token,Token_Parsed),
	convert(Token_Parsed,Elem),
        Index1 is Index + 1,
	convert_list_fich(Index1,Tail_Token,Tail_Elem).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        parse     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
parse_fich(Index,Tupla,
		token(Index,Area,Concepto,Identificador,Val_ini_P,Val_fin_P,Fun_P)):-
        nonvar(Tupla),
        !,
        Tupla = ([A1,A2,A3,A4,C1,C2,Id1,Id2,Id3,Id4],Val_ini,Val_fin,Fun),
        parse_val(Val_ini, Val_ini_P),
        parse_val(Val_fin, Val_fin_P),
        parse_val(Fun, Fun_P),
	atom_codes(Area,[A1,A2,A3,A4]),
	atom_codes(Concepto,[C1,C2]),
	atom_codes(Identificador,[Id1,Id2,Id3,Id4]).

parse_fich(_,_,_):-
        format("[Debug]    ERROR en el fichero de entrada: Asociacion como variable libre!!!",[]),
        fail.

parse(Index,([A1,A2,A3,A4,C1,C2,Id1,Id2,Id3,Id4],Val_ini,Val_fin,Fun),
		token(Index,Area,Concepto,Identificador,Val_ini,Val_fin,Fun)):-
	atom_codes(Area,[A1,A2,A3,A4]),
	atom_codes(Concepto,[C1,C2]),
	atom_codes(Identificador,[Id1,Id2,Id3,Id4]).

parse_val(null,_):-
        !.
parse_val(E,E_P):-
       ground(E),
       list(E),
       !,
       atom_codes(E_P,E).

parse_val(E,E).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        leer_entrada
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

leer_entradas_ass(LaFrase, Lista_Entradas):-
        frase(Frase),
        arcos(Arcos),
        nodos(Nodos),
        atom_codes(LaFrase, Frase),
        findall(Entrada, forma_entrada(Arcos, Nodos, Entrada), Lista_Entradas).
        
leer_entradas(Fichero, LaFrase, Lista_Entradas):-
        format("[Debug]  Leyendo entrada: ~w~n",[Fichero]),
        open(Fichero, read, Stream),
        read(Stream,frase(Frase)),
        read(Stream,arcos(Arcos)),
        read(Stream,nodos(Nodos)),
        close(Stream),
        atom_codes(LaFrase,Frase),
        format("         Frase: ~w~n",[LaFrase]),
        findall(Entrada, forma_entrada(Arcos, Nodos, Entrada), Lista_Entradas),
        format("         [Hecho] Entradas Leidas !~n",[]).


forma_entrada(Lista_Arcos, Lista_Nodos, Entrada):-
        select((ini:0,Asoc_Ini), Lista_Arcos, Lista_Arcos_1),
        select((Asoc_Fin,fin:0), Lista_Arcos_1, Lista_Arcos_2),
        camino_entrada(Asoc_Ini,Asoc_Fin,Lista_Arcos_2, Camino_Entrada),
%        format("[Debug]         Lista Nodos : ~w~n",[Camino_Entrada]),
        forma_camino_entrada(Lista_Nodos, Camino_Entrada, Entrada).
%        format(" Camino [Formados]~n",[]).

camino_entrada(Asoc, Asoc, _, [Asoc]).
camino_entrada(Asoc_Ini, Asoc_Fin, Lista_Arcos, [Asoc_Ini|Resto]):-
        select( (Asoc_Ini, Asoc_Sig), Lista_Arcos, Lista_Arcos_1),
        camino_entrada(Asoc_Sig, Asoc_Fin, Lista_Arcos_1, Resto).

forma_camino_entrada(_, [], []):-
        !.
forma_camino_entrada(Lista_Nodos, [Id_Asoc|Resto_Asoc], Lista_Tuplas):-
	member((Id_Asoc,Lista_Tuplas_Asoc,_,_,_,_,_,_,_,_,_,_),Lista_Nodos),
        list(Lista_Tuplas_Asoc),
        !,
        forma_camino_entrada(Lista_Nodos, Resto_Asoc, Resto_Tuplas),
        append(Lista_Tuplas_Asoc, Resto_Tuplas, Lista_Tuplas).

forma_camino_entrada(_Lista_Nodos, [Id_Asoc|_Resto_Asoc], _Lista_Tuplas):-
        format("[Debug]   ERROR:Imposible expandir: ~w~n",[Id_Asoc]),
        fail.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%        primeras_N
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
primeras_N([],_,[]):-
        !.
primeras_N(_,0,[]):-
	!.
primeras_N([H|T],N,[H|TN]):-
        N1 is N - 1,
        primeras_N(T,N1,TN).




