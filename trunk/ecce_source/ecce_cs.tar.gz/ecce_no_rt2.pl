:- load_compilation_module( '../ecce_no_rt_mod' ).
:- add_goal_trans( remove_prepost/2 ).

:- use_package( default ).

