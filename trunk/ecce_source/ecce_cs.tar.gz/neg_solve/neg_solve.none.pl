:- module('neg_solve.none',[neg_solve/2]).

:- set_prolog_flag(single_var_warnings,off).


:- dynamic neg_solve/2.

neg_solve(Goal,unknown).
