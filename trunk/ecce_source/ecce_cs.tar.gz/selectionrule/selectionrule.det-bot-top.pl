/* file: selectionrule.det-bot-top.pro */

:- dynamic select_positive_literal/5.

not(Goal) :- \+(Goal).


/* A simple determinate unfolding rule w/o a depth bound */

select_positive_literal(Goal,TopGoalVarlist,UnfHist,NrOfSel,SelLiteral) :-
	/* Try to find determinate literals */
	member_nr(SelLiteral,Goal,NrOfSel),
	not(is_negative_literal(SelLiteral,Atom)),
	not(is_built_in_literal(SelLiteral)),
	ok_to_unfold(Goal,NrOfSel,UnfHist),
	not(embedded_covering_ancestor(SelLiteral,NrOfSel,UnfHist)),
	debug_print(unfold(SelLiteral)),debug_nl.
select_positive_literal(Goal,TopGoalVarlist,UnfHist,NrOfSel,SelLiteral) :-
	/* Try to find determinate literals */
	member_nr(SelLiteral,Goal,NrOfSel),
	not(is_negative_literal(SelLiteral,Atom)),
	not(is_built_in_literal(SelLiteral)),
	not(find_unimposed_variant([SelLiteral],VariantID)),
	ok_to_unfold2(Goal,NrOfSel,UnfHist),
	not(embedded_covering_ancestor(SelLiteral,NrOfSel,UnfHist)),
	debug_print(unfold2(SelLiteral)),debug_nl.

ok_to_unfold(Goal,NrOfSel,[]) :- !.
ok_to_unfold(Goal,NrOfSel,UnfHist) :-
	not(undeterminate(Goal,NrOfSel)),
	not(find_unimposed_variant([SelLiteral],VariantID)),
	( not(pp_cll(contains_non_determinate_step(UnfHist)))
	   /* ;
	 not(pp_cll(goal_increasing_selection(Goal,NrOfSel)))  */
	).

ok_to_unfold2(Goal,1,UnfHist) :-
	not(pp_cll(contains_non_determinate_step(UnfHist))),
	length(Goal,L),
	L>1.
ok_to_unfold2(Goal,NrOfSel,UnfHist) :-
	not(undeterminate(Goal,NrOfSel)),
	pp_cll(contains_non_determinate_step_at_top(UnfHist)),
	length(Goal,L),
	L>1.

embedded_covering_ancestor(SelLiteral,NrOfSel,UnfHist) :-
	covering_ancestor(NrOfSel,UnfHist,CovAncestor),
	homeomorphic_embedded(CovAncestor,SelLiteral),
	debug_print(embed(CovAncestor,SelLiteral)),debug_nl.
