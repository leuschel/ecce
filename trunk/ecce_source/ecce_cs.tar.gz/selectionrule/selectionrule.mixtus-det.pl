:- module('selectionrule.mixtus-det',[select_positive_literal/5]).

:- dynamic select_positive_literal/5.

:- set_prolog_flag(multi_arity_warnings,off).
:- set_prolog_flag(discontiguous_warnings,off).
:- set_prolog_flag(single_var_warnings,off).

:- use_module(library(lists)).

:- use_module('../bimtools').
:- use_module('../calc_chtree').
:- use_module('../unfold_history').
:- use_module('../main_functions').
:- use_module('../homeomorphic').
:- use_module('../static_dynamic_functors').


/* An unfolding rule based on homeomorphic embedding */

select_positive_literal(Goal,TopGoalVarlist,UnfHist,NrOfSel,SelLiteral) :-
	member_nr(SelLiteral,Goal,NrOfSel),
	((NrOfSel=1) ; (UnfHist=[])),
/* allow non-leftmost undeterminate steps at top (for conjunctive PD) */
	not(is_negative_literal(SelLiteral,Atom)),
	not(is_built_in_literal(SelLiteral)),
	(not(find_any_unimposed_variant([SelLiteral],VariantID))
	 ; (UnfHist=[])),
		/* stop if variant exists at the global level */
	(not(unfolding_leads_to_loop(SelLiteral)) ; (UnfHist=[])),
	ok_to_unfold(SelLiteral,NrOfSel,UnfHist),!.
select_positive_literal(Goal,TopGoalVarlist,UnfHist,NrOfSel,SelLiteral) :-
	/* Try to find determinate literals */
	member_nr(SelLiteral,Goal,NrOfSel),
	NrOfSel > 1,
	not(is_negative_literal(SelLiteral,Atom)),
	not(is_built_in_literal(SelLiteral)),
	not(undeterminate(Goal,NrOfSel)),
	not(unfolding_leads_to_loop(SelLiteral)),
	ok_to_unfold(SelLiteral,NrOfSel,UnfHist).

ok_to_unfold(SelLiteral,NrOfSel,UnfHist) :-
	not(loop_prevention(SelLiteral,NrOfSel,UnfHist)),
	debug_print(ok_to_unfold(SelLiteral,NrOfSel)),debug_nl.


loop_prevention(SelLiteral,NrOfSel,UnfHist) :-
	/* findall(mayloop,
		may_loop_covering_ancestor(SelLiteral,NrOfSel,UnfHist),
		Sols),
	length(Sols,NrML),
	NrML >= 2,   ===> max_rec = 2 */
	may_loop_covering_ancestor(SelLiteral,NrOfSel,UnfHist),!,
	debug_print(loop_prevention(SelLiteral,NrOfSel)),debug_nl.

may_loop_covering_ancestor(SelLiteral,NrOfSel,UnfHist) :-
	covering_ancestor(NrOfSel,UnfHist,CovAncestor),
	may_loop(CovAncestor,SelLiteral),
	assertz(unfolding_leads_to_loop(CovAncestor)).


may_loop(T,S) :-
	may_loop2(T,S,2). /* max_depth = 2 */

may_loop2(T,S,Depth) :-
	stop_may_loop(T,S,Depth),!,
	mixtus_term_size(T,TS),
	mixtus_term_size(S,SS),
	TS =< SS.
may_loop2(T,S,Depth) :-
	nonvar(T),
	nonvar(S),
	atoms_have_same_predicate(T,S,Predicate),
	D1 is Depth - 1,
	T =.. [Pred|TA],
	S =.. [Pred|TS],
	all_may_loop2(TA,TS,D1).

stop_may_loop(T,S,Depth) :- Depth < 1.
stop_may_loop(T,S,Depth) :- var(S),!.
stop_may_loop(T,S,Depth) :- dynamic_term(S),not(number(S)).
stop_may_loop(T,S,Depth) :- inf_number(S).

inf_number(T) :-
	number(T),
	AT is abs(T),
	AT >= 7. /* maxfinite = 7 */

all_may_loop2([],[],D).
all_may_loop2([H|T],[SH|ST],D) :-
	may_loop2(H,SH,D),
	all_may_loop2(T,ST,D).
