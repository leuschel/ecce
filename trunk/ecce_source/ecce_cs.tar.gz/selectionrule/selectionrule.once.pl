:- module('selectionrule.once',[select_positive_literal/5]).

:- dynamic select_positive_literal/5.

:- set_prolog_flag(single_var_warnings,off).

:- use_module('../bimtools').
:- use_module('../calc_chtree').


select_positive_literal(Goal,TopGoalVarlist,UnfHist,NrOfSel,SelLiteral) :-
	goal_can_be_unfolded(Goal,UnfHist),
	member_nr(SelLiteral,Goal,NrOfSel),
	not(is_negative_literal(SelLiteral,Atom)),
	not(is_built_in_literal(SelLiteral)),
	debug_print(ok(SelLiteral)),debug_nl.

goal_can_be_unfolded(Goal,[]).

