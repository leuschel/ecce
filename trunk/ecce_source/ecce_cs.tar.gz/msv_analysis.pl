:- module(msv_analysis,
	[
	    msv_change/0, 
%	    msv_entry/1,
	    calc_and_store_msv_result/0,
	    msv_of_goal/1,
	    run_msv_anlysis/0,
	    calc_msv_clauses/0,
	    assert_msv_change/0,
	    retract_msv_change/0,
	    bup/0,
	    propagation_step/0,
	    take_msg/2,
	    propagate_tuple/1,
	    unify_body/1,
	    is_a_fact/1,
	    same_predicate/2
        ]).

/* --------------------------------------------- */
/* (C) COPYRIGHT MICHAEL LEUSCHEL 1995,1996,1997 */
/* --------------------------------------------- */

/* TO GET THE LATEST VERSION OF THE ECCE SYSTEM GO TO:
	http://www.cs.kuleuven.ac.be/~michael */
/* BUG REPORTS, QUESTIONS AND COMMENTS CAN BE SENT TO:
	michael@cs.kuleuven.ac.be */

:- set_prolog_flag(multi_arity_warnings,off).
:- set_prolog_flag(discontiguous_warnings,off).
:- set_prolog_flag(single_var_warnings,off).

:- use_module(bimtools).
:- use_module(code_generator).
:- use_module(static_dynamic_functors).
:- use_module(calc_chtree).

:- use_module(dynpreds).

not(Goal) :- \+(Goal).


/* file: msv_analysis.pro */


:- dynamic msv_change/0.
msv_change.

:- dynamic msv_entry/1.
msv_entry([]).


calc_and_store_msv_result :-
	retract(msv_entry(_X)),fail.
calc_and_store_msv_result :-
	bup.

msv_of_goal(Goal) :-
	unify_body(Goal).



run_msv_anlysis :-
	reset_spec_prog,
	reset_static_functors,
	print('-> calculating static functors'),nl,
	calculate_static_functors,
	print('-> starting bup propagation'),nl,
	bup,nl,
	retractall(msv_change),
	calc_msv_clauses.

calc_msv_clauses :-
	claus(_Nr,Head,Body),
	copy(clause(Head,Body),CopyOfClause),
	((unify_body(Body),
	  unify_body([Head])
	 )
	 -> (assert_spec_clause(Head,Body),
	     (variant_of(clause(Head,Body),CopyOfClause)
		-> true
		;  (assert_msv_change,
		    debug_print(change(clause(Head,Body),CopyOfClause)),
			debug_nl)
	    ))
	 ; (assert_msv_change,
	    debug_print(change(clause(Head,[fail]))),debug_nl,
	    assert_unsimplified_spec_clause(Head,[fail]) )
	),
	fail.
calc_msv_clauses.


assert_msv_change :-
	(msv_change -> true ; assert(msv_change)).

retract_msv_change :- retract(msv_change),fail.
retract_msv_change.

bup :-
	debug_print(bup(OldT)),debug_nl,
	retract_msv_change,
	propagation_step,
	(msv_change
	-> (print('.'),bup)
	;  (true)
	).

propagation_step :-
	defined_predicate(P,Arity),
	get_predicate(G,pred(P,Arity)),
	findall(G,propagate_tuple(G),NewGs), 
	take_msg(NewGs,NewMsg),
	(retract(msv_entry(G)) -> OldG=G ; OldG=[fail]),
	assert(msv_entry(NewMsg)),
	(variant_of(OldG,NewMsg)-> true ;
	  assert_msv_change,debug_print(msv_chg(OldG,NewMsg)),debug_nl),
	fail.
propagation_step.


take_msg([H|T],Res) :-
	takemsg2(T,H,Res).

takemsg2([],R,R).
takemsg2([H|T],A,R) :-
	msg(H,A,MsgHA),!,
	takemsg2(T,MsgHA,R).


propagate_tuple(Head) :-
	claus(_Nr,Head,Body),
	unify_body(Body),
	debug_print(prop(Head)).



unify_body([]).
unify_body([not(B1)|R]) :- !,
	\+(is_a_fact(B1)), /* then assume negation succeeds */
	unify_body(R).
unify_body([\+(B1)|R]) :- !, 
	\+(is_a_fact(B1)), /* then assume negation succeeds */
	unify_body(R).
unify_body([BI|R]) :-
	is_callable_built_in_literal(BI),!,
	call_built_in(BI),
	unify_body(R).
unify_body([BI|R]) :-
	is_built_in_literal(BI),!,  /* suppose other built-ins succeed */
	unify_body(R).
unify_body([B1|R]) :-
	msv_entry(B1),!,
	unify_body(R).

is_a_fact(B) :-
	copy(B,BC),
	claus(_Nr,BC,[]),
	variant_of(B,BC).


same_predicate(X,Y) :-
	X =.. [P|ArgsX],
	Y =.. [P|ArgsY],
	same_length(ArgsX,ArgsY).

/* already defined in Sicstus:
same_length([],[]).
same_length([_|XT],[_|YT]) :- same_length(XT,YT).
*/

