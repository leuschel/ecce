:- module('more_specific.simple-msv',[more_specific_transformation/1]).

:- dynamic more_specific_transformation/1.

:- set_prolog_flag(multi_arity_warnings,off).
:- set_prolog_flag(discontiguous_warnings,off).
:- set_prolog_flag(single_var_warnings,off).

:- use_module(library(lists)).

:- use_module('../bimtools').
:- use_module('../calc_chtree').
:- use_module('../msv_analysis').

/* instantiates goals during the unfolding process to more specific versions */

more_specific_transformation(Goal) :-
	msv_of_goal(Goal),
	more_specific_transformation2(Goal).

more_specific_transformation2([]).
more_specific_transformation2([CH|T]) :-
	peel_off_calls(CH,H),
	mst_instantiate_atom(H),!,
	more_specific_transformation2(T).

mst_instantiate_atom(Atom) :-
	mst_matching_heads(Atom,Heads),!,
	((Heads = [])
	 -> (true)  /* do nothing, dead literals will be detected anyway, and the atom could be a built-in or a negative literal */
	;  (mst_msg_of_list(Heads,MsgOfHeads),
	    Atom=MsgOfHeads)
	).

mst_matching_heads(Atom,Heads) :-
	bd_findall(Atom, (claus(Nr,Atom,Body),msv_of_goal(Body)),Heads).

mst_msg_of_list([Atom1|Tail],MSG) :-
	mst_l_msg(Atom1,Tail,MSG).
mst_l_msg(Atom,[],Atom).
mst_l_msg(Atom,[Atom2|T],MSG) :-
	msg(Atom,Atom2,IntMSG),!,
	mst_l_msg(IntMSG,T,MSG).
