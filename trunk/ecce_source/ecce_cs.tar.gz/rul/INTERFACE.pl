:- module('INTERFACE',_).

%%%%%%%%%% INTERFACE BETWEEN ECCE AND RUL %%%%%%%%%%

:- use_module(ecceRUL).
:- use_module(unfold2).
:- use_module(analyticFold).
:- use_module(instance_entails).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
