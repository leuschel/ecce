:- module('whistle.none',[whistle/4]).

:- set_prolog_flag(single_var_warnings,off).

:- dynamic whistle/4.

whistle(GoalID,Goal,Chtree,WhistlGoalID) :-
	fail.
