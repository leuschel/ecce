:- module('whistle.karp',[whistle/4]).

:- dynamic whistle/4.

:- set_prolog_flag(multi_arity_warnings,off).
:- set_prolog_flag(discontiguous_warnings,off).
:- set_prolog_flag(single_var_warnings,off).

:- use_module('../bimtools').
:- use_module('../global_tree').
:- use_module('../homeomorphic').
:- use_module('../calc_chtree').


whistle(GoalID,Goal,Chtree,WhistlGoalID) :-
	node_is_an_abstraction(GoalID),print('KM '),!,fail.
	/* whistle should only blow for not yet	abstracted nodes */
whistle(GoalID,Goal,Chtree,WhistlGoalID) :-
	gt_node_descends_from(GoalID,ParID,_LeafLocalID),
	find_growing_among_ancestors(ParID,Goal,Chtree,WhistlGoalID).


find_growing_among_ancestors(ParID,Goal,Chtree,ParID) :-
	gt_node_pe_status(ParID,pe(ImpStat)),
		/* only test with non-abstracted ancestors */
	gt_node_goal(ParID,ParGoal),
	pp_cll(msg_can_be_taken(Goal,ParGoal)),
	not(strict_instance_of(ParGoal,Goal)),
	goal_naive_homeo(ParGoal,Goal).
find_growing_among_ancestors(ParID,Goal,Chtree,WhistlGoalID) :-
	gt_node_descends_from(ParID,ParID2,_LeafLocalID),
	find_growing_among_ancestors(ParID2,Goal,Chtree,WhistlGoalID).
	

goal_naive_homeo([],[]) :- !.
goal_naive_homeo([X|XA],[Y|YA]) :- !,
	naive_homeo(X,Y),
	goal_naive_homeo(XA,YA).
goal_naive_homeo(X,Y) :- naive_homeo(X,Y).

naive_homeo(X,Y) :-
	X=..[Func|XA],
	Y=..[Func|YA],
	l_naive_homeo(XA,YA).

l_naive_homeo([],[]).
l_naive_homeo([X|XA],[Y|YA]) :-
	(var(Y); homeomorphic_embedded(X,Y)),!,l_naive_homeo(XA,YA).
