X="ciao_specific.pl".
:- import(X).

print(not(true)).
