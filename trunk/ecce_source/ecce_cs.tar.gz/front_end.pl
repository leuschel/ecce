/* file: front_end.pro */

% :- set_prolog_flag(multi_arity_warnings,off).
% :- set_prolog_flag(discontiguous_warnings,off).
% :- set_prolog_flag(single_var_warnings,off).

:- use_module(code_generator,
	[
	    copy_specialised_program_to_input/0,
	    print_clause_with_nl/2,
	    print_specialised_program/0
	]).
:- use_module(msv_analysis,
	[
	    run_msv_anlysis/0,
	    msv_change/0
	]).
:- use_module(benchmark,
	[
	    execute_benchmark/1,
	    execute_benchmark_set/1
	]).
:- use_module(static_dynamic_functors,
	[
	    toggle_treatment_of_open_predicates/0
	]).
:- use_module(global_tree,
	[
	    print_gt_nodes/0
	]).
:- use_module(ic_gen,
	[
	    gen_ic_code/0
	]).
:- use_module(raf_analysis,
	[
	    perform_raf_analysis/0,
	    perform_andprint_far_analysis/0
	]).

/* --------- */
/* FRONT-END */
/* --------- */

:- data last_pd_query/1.
last_pd_query(true).
:- data last_read_file/1.
last_read_file('$ECCE_SYSTEM_PATH/append-test').

main(Inputs) :-
	perform_self_check,
	initialise_parameters,
        ((Inputs=[])->set_exec_mode(interactive);set_exec_mode(compiled)),
        (
         (exec_mode(interactive)->ecce_interactive);
         (exec_mode(compiled)->ecce_compiled(Inputs))
        ).

ecce :- main([]).

ecce_interactive :-
        please(tw,off),
	init_bd_findall,
	seen,
	see(user),
	told,
	tell(user),
	print('-------------------'),nl,
	print('Welcome to ECCE'),print_ecce_version,nl,
	print('-------------------'),nl,
	print_ecce_release,nl,
	print('Implemented by Michael Leuschel'),nl,
	print('Based on work by Michael Leuschel, Bern Martens, Jesper Jorgensen,'),nl,
	print('Danny De Schreye, Robert Glueck, Morten Heine Sorensen, Andre de Waal,'),nl,
        print('and Mauricio Varea.'),nl,
	print('(C) 1995-97'),nl,nl,
	print('type h or ? for help'),nl,
	print('type o to turn off run-time type checking (10x speedup)'),nl,
	front_end([]),
	seen,
	told.

ecce_compiled(Inputs) :-
        please(tw,off),
	init_bd_findall,
	seen,
	see(user),
	told,
	tell(user),
        front_end(Inputs),
        seen,
        told.


front_end([]) :- !,
	prompt(_OldPrompt,''),
	print('=> '),
	ecce_get(AsciiChar),
 	(action(AsciiChar)
	-> (true)
	;  (print('Unknown command, type h or ? for help'),nl,front_end([]))
	).

front_end([A|P]) :-
        char_code(A,Action),debug_print('::'),debug_print(action(Action)),debug_nl,
 	(action(Action,P)
	-> (true)
	;  (print('Unknown command, try "ecce h" or "ecce ?" for help'),nl)
	).


list_database :-
	claus(Nr,Head,Body),
	print(Nr),print(': '),
	print_clause_with_nl(Head,Body),fail.
list_database :-
	next_free_mode_nr(MNr),
	((MNr > 1)
	-> (MT is MNr - 1,
	    print('number of mode declarations: '),print(MT),nl)
	; (true)
	).

:- set_prolog_flag(multi_arity_warnings,off).

action(X):- action(X,[]).

action(98,P):- 
	(exec_mode(compiled) -> P=[RR|PP] ; P=PP),
	execute_benchmark(RR),  /* b for Benchmark */
	front_end(PP).
action(99,P):- /* c for clear clause database */
	clear_database,
	set_make_iff_definitions_read_in(no),
	front_end(P).
action(100,P):- /* d for determinate post-unfolding */
	perform_determinate_post_unfolding, front_end(P).
action(101,P):- /* e for dEbugging */
	(exec_mode(compiled) -> (P=[F|RR],RR=[S|PP]) ; P=PP),
	set_debug_printing_value(F), set_trace_printing_value(S), front_end(PP).
action(102,P) :- /* f */
	(exec_mode(compiled) -> P=[RR|PP] ; P=PP),
	set_output_to_file_int(RR),front_end(PP).
action(103,P):- /* g for print global tree */
	print('Global Tree:'),nl,print_gt_nodes, front_end(P).
action(105,P):- /* i for insert specialised program into clause db */
	copy_specialised_program_to_input,
	print_claus_database_status,
	front_end(P).
action(106,P):- /* j create ic-checking clauses */
	gen_ic_code,
	front_end(P).
action(107,P) :- /* k for benchmarkset */
	(exec_mode(compiled) -> P=[RR|PP] ; P=PP),
	execute_benchmark_set(RR), front_end(PP).
action(108,P) :- /* l for listing */
	print(' Clauses in database:'),nl,
	list_database,
	front_end(P).
action(109,P) :- /* m for msv analysis */
	run_msv_anlysis,
	print('More Specific Version of Program:'),nl,
	print_specialised_program,
	(msv_change
		-> print('New information was derived.')
		;  print('No new information !')
	),nl,
	front_end(P).
action(110,P) :- /* n: enable abstract partial deduction */
	set_standard_config(97),
	front_end(P).
action(97,P) :- /* a: toggle treatment of open predicates */
	toggle_treatment_of_open_predicates,
	front_end(P).
action(112,P):- /* p: partially evaluate an atom */
	last_pd_query(Last),
	(exec_mode(interactive) 
	-> (beginner_print('Use list notation for goals: [G1,G2].'),beginner_nl,
	    beginner_print('Type a dot (.) and hit return at the end.'),beginner_nl,
	    print('atom or goal (l for '),print(Last),print(') =>'))
	; true ),
	((P=[])->(read(R),PP=[]);(P=[RR|PP],read_atom(RR,R))),
	((R=l) -> (Atom = Last)
	       ;  (Atom = R,retract_fact(last_pd_query(_)),
	           assertz_fact(last_pd_query(Atom))
		  )
	),
	time(pe(Atom),T),nl,
	print('Full transformation time (with code generation): '), print(T),
	print(' ms'),nl,
	front_end(PP).
action(111,P) :-  /* NOT WORKING YET! needs the implementation of a dispatcher for 
	             bimtools:prepost (also allocating each part of bimtools into 
                     separate modules would be a good idea!)*/
	%ecce_reconsult('bimtools/prepost.nocheck.pro'),
	front_end(P).
action(113,_). /* q for quit */
action(114,P):- /* r for read in file into clause database */
	last_read_file(Last),
	(exec_mode(interactive) 
	->(beginner_print('Type a dot (.) and hit return at the end.'),beginner_nl,
	   print('filename (l for '),print(Last),print(') =>'))
	; true ),
	((P=[])->(read(R),PP=[]);(P=[R|PP])),
	((R=l) -> (Filename = Last)
	       ;  (Filename = R,retract_fact(last_read_file(_)),
	           assertz_fact(last_read_file(Filename))
		  )
	),
	read_in_file(Filename),
	front_end(PP).
action(115,P):- /* s for set parameters */
	set_parameters, front_end(P).
action(116,P):- /* t  */
	set_make_iff_when_reading_clauses, front_end(P).
action(117,P):- /* u  */
	manual_unfold, front_end(P).
action(118,P):- /* v  */
	toggle_user_expert, front_end(P).
action(119,P) :- /* w for Write to file */
	print_specialised_program_to_file,
	front_end(P).
action(121,P):- /* y  */
	perform_raf_analysis, front_end(P).
action(122,P):- /* z  */
	perform_andprint_far_analysis, front_end(P).

action(120,_) :- stop. /* x for exit */

action(63,_P) :- action(104). /* ? for help  */
action(104,P) :- /* h for help */
	print(' ECCE 2.0'),nl,
	print(' The Partial Evaluator based on Characteristic Atoms and Global Trees'),nl,nl, print('  '),
	print_claus_database_status,nl,
	print(' Command Summary:'),nl,
	expert_print('  b: execute Benchmark (from special file)'),expert_nl,
	print('  c: Clear clause database'),nl,
	print('  e: set dEbugging on/off'),nl,
	print('  f: choose File for output'),nl,
	print('  h: Help (also ?)'),nl,
	print('  i: Insert specialised program into clause database'),nl,
	expert_print('  k: execute benchmarK Set(from special file)'),expert_nl,
	print('  l: List clause database'),nl,
	print('  o: turn type checking Off'),nl,
	print('  p: Partially evaluate an atom or goal'),nl,
	print('  r: Read clauses into database'),nl,
	print('  s: Set Parameters'),nl,
	print('  v: set user expert leVel on/off'),nl,
	print('  w: Write specialised program to file'),nl,
	print('  x: eXit (also a and q)'),nl,
	print('  ----------------------------------- '),nl,
	expert_print('  a: toggle treatment of open predicates'),expert_nl,
	print('  d: Determinate (post-)unfolding'),nl,
	expert_print('  g: print Global tree'),expert_nl,
	expert_print('  j: generate ic-checking code'),expert_nl,
	print('  m: Msv analysis'),nl,
	print('  n: eNable abstract partial deduction'),nl,
	expert_print('  t: iff clause Transformation'),expert_nl,
	expert_print('  u: manual Unfold'),expert_nl,
	expert_print('  y: redundant argument filtering (RAF) analYsis'),expert_nl,
	expert_print('  z: FAR (reversed RAF) analysis'),expert_nl,
	(exec_mode(interactive)->front_end(P);true).

:- set_prolog_flag(multi_arity_warnings,on).


