:- module('check_instance_of.rul',[get_instance_of/4]).

:- include('header.pl').

%:- use_module('../rul/INTERFACE').

%%%:- ecce_use_module('rul/ecceRUL').
%%%:- ecce_use_module('rul/instance_entails').

%:- initialization(retractall(rul_active(_)),assert(rul_active(yes))).

:- dynamic get_instance_of/4.

:- set_prolog_flag(single_var_warnings,off).

:- use_module(library(lists)).

:- use_module('../bimtools').
:- use_module('../calc_chtree').
:- use_module('../global_tree').

:- multifile gt_node/1,gt_node_goal/2,gt_node_constraint/2,
             gt_node_bup_cas/3,gt_node_descends_from/3,
             gt_node_instance_of/2,gt_node_chtree/2,gt_node_pe_status/2,
	     gt_node_user_info/2.             

:- dynamic gt_node/1.
:- dynamic gt_node_goal/2.
:- dynamic gt_node_constraint/2.
:- dynamic gt_node_bup_cas/3.
:- dynamic gt_node_descends_from/3.
:- dynamic gt_node_instance_of/2.
:- dynamic gt_node_chtree/2.
:- dynamic gt_node_pe_status/2.
:- dynamic gt_node_user_info/2.

/* must be instance of something with same chtree */

get_instance_of(GoalID,Goal,Chtree,MoreGeneralID) :-
	Chtree \== stop, /* this will happen for goals like [X] */
        divide_constraint_rul_goal(Goal,OrdGoal,ConstrGoal),
	copy(OrdGoal,COrdGoal),
	numbervars(COrdGoal,1,_),
	gt_node_goal(MoreGeneralID,MGoal),
	GoalID \== MoreGeneralID,
	gt_node_pe_status(MoreGeneralID,PEStatus),
	PEStatus \== no, \+(PEStatus = abstracted(_)),
	divide_constraint_rul_goal(MGoal,COrdGoal,MCGoal),
	 /* above checks whether ordinary part is an instance */
	/* could be pre-processed */
	instance_is_ok(MoreGeneralID,PEStatus,Chtree),
	/* now check constraint entailment */
	debug_print(check_instance_of(GoalID,MoreGeneralID)),debug_nl,
	gt_node_goal(MoreGeneralID,MoreGeneralGoal),
	divide_constraint_rul_goal(MoreGeneralGoal,MOG,MCG),
	debug_print('instance_of_entails'(OrdGoal,ConstrGoal,MOG,MCG)),
	debug_nl,
	/*entails(OrdGoal,ConstrGoal,MOG,MCG),*/
	instance_of_entails(OrdGoal,ConstrGoal,MOG,MCG),
	debug_print('instance_of_entails succeeds'),debug_nl. 

instance_is_ok(_MoreGeneralID,PEStat,_Chtree) :-
	PEStat \== pe(imposed), PEStat \== abstracted(imposed).
		/* otherwise chtree might be incorrect */
instance_is_ok(MoreGeneralID,_PEStat,Chtree) :-
	gt_node_chtree(MoreGeneralID,Chtree).




/* --------- For Abstract Partial Deduction: -------------- */


get_cinstance_of(GoalID,Goal,Constraint,Chtree,MoreGeneralID) :-
	Chtree \== stop, /* this will happen for goals like [X] */
	copy(Goal,CGoal),
	numbervars(CGoal,1,_),
	gt_node_goal(MoreGeneralID,CGoal),
	GoalID \== MoreGeneralID,
	gt_node_pe_status(MoreGeneralID,PEStatus),
	PEStatus \== no,
	instance_is_ok(MoreGeneralID,PEStatus,Chtree),
	gt_node_constraint(MoreGeneralID,(MG,MGC)),
        constraint_instance_of(Goal,Constraint,MG,MGC). 
