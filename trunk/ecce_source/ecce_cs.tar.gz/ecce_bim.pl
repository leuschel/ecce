
multifile.

transform_dcg_term(RTerm,DTerm) :-
	dcg$system(RTerm,DTerm).


:- consult('$ECCE_SYSTEM_PATH/ecce_main.pro').
