:- module('partition.standardpd',[partition_goal/3]).

:- dynamic partition_goal/3.

:- set_prolog_flag(multi_arity_warnings,off).
:- set_prolog_flag(discontiguous_warnings,off).
:- set_prolog_flag(single_var_warnings,off).

:- use_module(library(lists)).

:- use_module('../bimtools').
:- use_module('../calc_chtree').


partition_goal([],_Nrs,[]).
partition_goal([Lit|T],[SelNr|TN],[split_goal([PosAtom],built_in(SelNr))|ST]) :-
	is_built_in_literal(Lit),
	extract_positive_atom_from_literal(Lit,PosAtom),!,
	partition_goal(T,TN,ST).
partition_goal([Lit|T],[SelNr|TN],[split_goal([PosAtom],neg(SelNr))|ST]) :-
	is_negative_literal(Lit,_),
	extract_positive_atom_from_literal(Lit,PosAtom),!,
	partition_goal(T,TN,ST).
partition_goal([Lit|T],[SelNr|TN],[split_goal([Lit],[SelNr])|ST]) :-
	not(is_built_in_literal(Lit)),
	not(is_negative_literal(Lit,Atom)),!,
	partition_goal(T,TN,ST).
partition_goal([Lit|T],[SelNr|TN],ST) :-
	partition_goal(T,TN,ST).

