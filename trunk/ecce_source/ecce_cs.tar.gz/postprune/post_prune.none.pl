:- module('post_prune.none',[post_prune_chtree/3]).

:- set_prolog_flag(single_var_warnings,off).

:- dynamic post_prune_chtree/3.


post_prune_chtree(_Goal,Chtree,Chtree).
