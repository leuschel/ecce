/* ---------------------------------- */
/* (c) Michael Leuschel, Jan/Feb 2001 */
/* ---------------------------------- */

% :- module(ecce_tcltk ,
% 	[
% 	    main/0,
% 	    go/0,
% 	    tcltk_initialise/0,	    
% 	    tcltk_turn_type_checking_off/0,
% 	    tcltk_open/1,
% 	    tcltk_set_specfile/1,
% 	    tcltk_specialise/1,
% 	    tcltk_turn_rul_on/0,
% 	    tcltk_turn_rul_bup_on/0
% 	]).
/* load all necessary modules */
:- use_module(library(tcltk)).
:- use_module(library(random)).
%JMGP :- use_module(library(system),[]),system:working_directory(_,'$ECCE_SOURCE').
%JMGP :- use_module(library(system)).

%JMGP
:- ensure_loaded('bimtools/ciao_specific.pl').

%JMGP:- ['ecce_sicstus.pl'].
:- ensure_loaded(ecce_ciao).

:- use_module(dynpreds).
:- use_module(bimtools).
:- use_module(main_functions).
:- use_module(parametric_files).

/* main program 
 * ============
 */

main :- go.

go :-
	tk_new([name('ecce')], X),
	tcl_eval(X, 'source ecce_tcltk.tcl',_),
%JMGP	tk_main_loop,
	tk_main_loop(X),
	tcl_delete(X).

/* -------------------------------------------------------------------- */

/* for Tcl/Tk Interface */


tcltk_initialise :-
	display('ecce_tcltk:Initialising!'), nl,
	set_user_expert(yes),
	display('ecce_tcltk:Initialised!'), nl.
        /*tcltk_turn_type_checking_off.*/

tcltk_turn_type_checking_off :-
	display('ecce_tcltk:tcltk_turn_type_checking_off'), nl,
% NOTE: Not working yet!	
%	ecce_reconsult('bimtools/prepost.nocheck.pl'),
	display('ecce_tcltk:tcltk_turn_type_checking_off done'), nl.
   
tcltk_open(Filename) :-
	display('ecce_tcltk:Opening filename'(Filename)), nl,
	clear_database,
	read_in_file(Filename).
   
tcltk_set_specfile(FileName) :-
	display('ecce_tcltk:Setting specfile'(FileName)), nl,
	set_output_to_file(FileName).

tcltk_specialise(Goal) :-
	display('ecce_tcltk:Specializing'(Goal)),nl,
	copy_term(Goal,G),
	pe(G).

tcltk_turn_rul_on :-
	display('ecce_tcltk:tcltk_turn_rul_on entering'), nl,
	set_user_expert(yes),
	set_standard_config(110), /* minimal post-processing */
        set_standard_config(114), /* enable rul */
        display('ecce_tcltk:tcltk_turn_rul_on exiting'), nl.
      
tcltk_turn_rul_bup_on :-
	display('ecce_tcltk:tcltk_turn_rul_bup_on entering'), nl,
	tcltk_turn_rul_on,
	ensure_loaded('$ECCE_SOURCE/bottomUp/adhoc_bup'),
	display('ecce_tcltk:tcltk_turn_rul_bup_on exiting'), nl.

/* :- nl,print('Type go.<return> to start the animator'),nl,nl. */

%JMGP:- nl,print('Starting ECCE'),nl, go.

kk(yes).
