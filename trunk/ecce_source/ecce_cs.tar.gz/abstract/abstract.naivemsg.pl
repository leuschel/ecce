:- module('abstract.naivemsg',[abstract_parent/6,abstract_leaf/6]).

/* for reproducing Petri net algorithms by Finkel, Karp-Miller */

:- dynamic abstract_parent/6.
:- dynamic abstract_leaf/6.

:- set_prolog_flag(multi_arity_warnings,off).
:- set_prolog_flag(discontiguous_warnings,off).
:- set_prolog_flag(single_var_warnings,off).

:- use_module(library(lists)).

:- use_module('../bimtools').
:- use_module('../calc_chtree').
:- use_module('../global_tree').

/*
:- multifile gt_node/1,gt_node_goal/2,gt_node_constraint/2,
             gt_node_bup_cas/3,gt_node_descends_from/3,
             gt_node_instance_of/2,gt_node_chtree/2,gt_node_pe_status/2,
	     gt_node_user_info/2.             

:- dynamic gt_node/1.
:- dynamic gt_node_goal/2.
:- dynamic gt_node_constraint/2.
:- dynamic gt_node_bup_cas/3.
:- dynamic gt_node_descends_from/3.
:- dynamic gt_node_instance_of/2.
:- dynamic gt_node_chtree/2.
:- dynamic gt_node_pe_status/2.
:- dynamic gt_node_user_info/2.
*/

abstract_parent(GoalID,Goal,Chtree,WhistleGoalID,
		NewWhistleGoals,NewWhistleChtrees) :- 
	gt_node_goal(WhistleGoalID,WhistleGoal),
	goal_naivemsg(Goal,WhistleGoal,MSG),
	(variant_of(MSG,WhistleGoal)
	 -> (debug_print('abstract_parent unsuccessful'),debug_nl,fail)
	 ;  (debug_print(abstract_parent(wg(WhistleGoal),nmsg(MSG))),debug_nl)
	),
	NewWhistleGoals = [split_goal(MSG,FSI)],
	get_full_split_indicator(MSG,1,FSI),
	NewWhistleChtrees = [none].

abstract_leaf(GoalID,Goal,Chtree,WhistleGoalID,NewGoals,NewChtrees) :-
	gt_node_goal(WhistleGoalID,WhistleGoal),
	goal_naivemsg(Goal,WhistleGoal,MSG),
	NewGoals = [split_goal(MSG,FSI)],
	get_full_split_indicator(MSG,1,FSI),
	NewChtrees = [none].

get_full_split_indicator([],Nr,[]).
get_full_split_indicator([H|T],Nr,[Nr|FST]) :-
	Nr1 is Nr + 1,
	get_full_split_indicator(T,Nr1,FST).


goal_naivemsg([],[],[]) :- !.
goal_naivemsg([X|XA],[Y|YA],[Z|ZA]) :- !,
	naivemsg(X,Y,Z), debug_print(naivemsg(X,Y,Z)),debug_nl,
	goal_naivemsg(XA,YA,ZA).
goal_naivemsg(X,Y,Z) :- naivemsg(X,Y,Z).

naivemsg(X,Y,Z) :-
	X=..[Func|XA],
	Y=..[Func|YA],
	l_naivemsg(XA,YA,ZA),!,
	Z=..[Func|ZA].
naivemsg(X,Y,_Z) :- print('*** error naivemsg failed'),nl.

l_naivemsg([],[],[]).
l_naivemsg([X|XA],[Y|YA],[X|ZA]) :-
	variant_of(X,Y),!,l_naivemsg(XA,YA,ZA).
l_naivemsg([X|XA],[Y|YA],[_|ZA]) :-
	l_naivemsg(XA,YA,ZA).