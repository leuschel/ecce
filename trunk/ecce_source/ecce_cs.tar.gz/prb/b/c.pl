:- module( c  , _ ).

c( a ).
