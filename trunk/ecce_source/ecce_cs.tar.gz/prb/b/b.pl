:- module( b , _ ).

b( 1 ).


:- use_module( c ).
