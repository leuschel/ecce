:- module( a , _ ).


:- include( 'b/b' ).

main :-
	display( hello ).
